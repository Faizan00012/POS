<?php
// Start the session
session_start();
$_SESSION["username"]="";
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Login | C-POS</title>

    <!-- Bootstrap -->
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- Animate.css -->
    <link href="../vendors/animate.css/animate.min.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
  </head>

  <body class="login">
    <div>
      <a class="hiddenanchor" id="signup"></a>
      <a class="hiddenanchor" id="signin"></a>

      <div class="login_wrapper">
        <div class="animate form login_form">
          <section class="login_content">
            <form action="" method="post">
              <h1>Login Form</h1>
              <div class="form-group">
                <input type="text" name="username" class="form-control" placeholder="Username" required=""/>
				  
              </div>
              <div class="form-group">
                <input type="password" name="password"  class="form-control" placeholder="Password" required="" />
				
              </div>
              <div>
                <input style="margin-left: 120px;width: 120px;" type="submit" name="submit" value="Log in" class="btn btn-app" >
                 
              </div>

              <div class="clearfix"></div>

              <div class="separator">
              
                <div class="clearfix"></div>
                <br />

                <div>
                  <h1><i class="fa fa-laptop"></i> C-POS</h1>
              
                </div>
              </div>
            </form>
			  
			  <?php
			   if(isset($_POST['submit'])){
			 
							include_once 'con_file.php';
			  $conn;
                         
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * FROM users";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		
		
		if ($row["username"]==$_POST["username"] && $row["password"]==$_POST["password"])
		{
             echo "<script>alert('".$row["username"]."' , '".$row["password"]."');</script>";
			
			$_SESSION["username"] = $row["username"];
			if ($row["access"]=="Client")
			{
				header('Location: client_dashboard.php');
			}
			else if ($row["access"]=="admin")
			{
                
				header('Location: dashboard.php');
			}
			
		}
        
    }
} else {
    echo "0 results";
}
$conn->close();	   
				   
				   
				   
				   
			   }
			  
			  
			  ?>
          </section>
        </div>

      </div>
    </div>
  </body>
</html>
