<?php
header("Expires: Thu, 19 Nov 1981 08:52:00 GMT"); //Date in the past
header("Cache-Control: no-store, no-cache, must-revalidate"); //HTTP/1.1

?>

<!DOCTYPE html>
<html lang="en">
  <head>
	  
	  <script src="jquery-1.12.4.min.js"></script>

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Attendance Staff - C-POS </title>

    <!-- Bootstrap -->
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- bootstrap-wysiwyg -->
    <link href="../vendors/google-code-prettify/bin/prettify.min.css" rel="stylesheet">
    <!-- Select2 -->
    <link href="../vendors/select2/dist/css/select2.min.css" rel="stylesheet">
    <!-- Switchery -->
    <link href="../vendors/switchery/dist/switchery.min.css" rel="stylesheet">
    <!-- starrr -->
    <link href="../vendors/starrr/dist/starrr.css" rel="stylesheet">
    <!-- bootstrap-daterangepicker -->
    <link href="../vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
           <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            <div class="navbar nav_title" style="border: 0;">
              <a href="dashboard.php" class="site_title"><i class="fa fa-laptop"></i> <span>Mehmood Iron</span></a>
            </div>

            <div class="clearfix"></div>

            <!-- menu profile quick info -->
            
            <!-- /menu profile quick info -->

            <br />

            <!-- sidebar menu -->
       <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                <h3>General</h3>
                <ul class="nav side-menu">
                 <li><a href="dashboard.php"><i class="fa fa-home"></i> Home </a></li>
                  <li><a href="Sale.php"><i class="fa fa-shopping-cart"></i>Sale</a>  </li>
					
	              <li><a href="Purchase.php"><i class="fa fa-money"></i>Purchase</a>
                    
                  </li>
					<li><a><i class="fa fa-users"></i> Customers <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
					  <li><a href="customer.php">Add Customer</a></li>
                      <li><a href="CustomerView.php">View Customers</a></li>
						
                     
                       
                    </ul>
                  </li>
                   
                   
               <li><a><i class="fa fa-user"></i> Suppliers <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
					  <li><a href="supplier.php">Add Supplier</a></li>
                      <li><a href="supplierview.php">View Suppliers</a></li>
                     
                       
                    </ul>
                  </li>
                   
            
                  <li><a><i class="fa fa-cubes"></i> Stock <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
					  <li><a href="items.php">Items</a></li>
                      <li><a href="additem.php">Add Items</a></li>
                      <li><a href="changeItem.php">Update Items</a></li>
                      <li><a href="P_items.php">Purchase Stock</a></li>
                      <li><a href="S_items.php">Sale Stock</a></li>
                       
                    </ul>
                  </li>
					
					<li><a><i class="fa fa-bar-chart"></i> Accounts <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
						
					  <li><a href="Receavable.php">Recevable</a></li>
                      <li><a href="payable.php">Payable</a></li>
						<li><a href="Reports.php">Reports</a></li>
                     
                       
                    </ul>
                  </li>
					
                  <li><a><i class="fa fa-newspaper-o"></i> Invoice Report <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="invoiceShow.php">Invoice Number</a></li>
                      
                    </ul>
                  </li>
				  </ul>
              </div>
          
            </div>       <!-- /sidebar menu -->

            <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
            <div class="sidebar-footer hidden-small">
              <a data-toggle="tooltip" data-placement="top" title="Settings">
                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="FullScreen">
                <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Lock">
                <span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Logout" href="login.php">
                <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
              </a>
            </div>
            <!-- /menu footer buttons -->
          </div>
        </div>

        <!-- top navigation -->
        <div class="top_nav">
          <div class="nav_menu">
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>
              <nav class="nav navbar-nav">
              <ul class=" navbar-right">
                <li class="nav-item dropdown open" style="padding-left: 15px;">
                  <a href="javascript:;" class="user-profile dropdown-toggle" aria-haspopup="true" id="navbarDropdown" data-toggle="dropdown" aria-expanded="false">
                    Mehmood Iron
                  </a>
                  <div class="dropdown-menu dropdown-usermenu pull-right" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item"  href="setting.php"><i class="fa fa-gear pull-right"></i> Settings</a>  
                    <a class="dropdown-item"  href="login.php"><i class="fa fa-sign-out pull-right"></i> Log Out</a>
                  </div>
                </li>

              </ul>
            </nav>
          </div>
        </div>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Sale Screen</h3>
				  
              </div>
					
           
            </div>

            <div class="clearfix"></div>
			  

			
						
			
  <div  class="col-md-14 col-sm-12;width:100%">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Order List </h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                     
                      
                    </ul>
                    <div class="clearfix"></div>
                  </div>

                  <div class="x_content">

                    <div class="table-responsive">
                      <table class="table table-striped jambo_table bulk_action">
                        <thead>
                          <tr class="headings">
                            
                            <th class="column-title">Item Name </th>
                            <th class="column-title">Kilogram / Quantity </th>
                            <th class="column-title">Price </th>
                            <th class="column-title">Discount </th>
                            <th class="column-title">Date </th>
                            <th class="column-title">Total </th>
                            <th class="column-title no-link last"><span class="nobr">Action</span>
                            </th>
                            <th class="bulk-actions" colspan="7">
                              <a class="antoo" style="color:#fff; font-weight:500;">Bulk Actions ( <span class="action-cnt"> </span> ) <i class="fa fa-chevron-down"></i></a>
                            </th>
                          </tr>
                        </thead>

                        <tbody>
							<?php
							
	$servername = "localhost";
							$username = "root";
							$password = "";
							$dbname = "pos";
                         
							$conn = new mysqli($servername, $username, $password, $dbname);

							if ($conn->connect_error) {
    						die("Connection failed: " . $conn->connect_error);
							} 
						
 
 
$sql = "SELECT Sale_id, Price, Item_Name, detail,Discount,Qty,Sub_Total FROM sale";
$result = $conn->query($sql);
$total=0;
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["Item_Name"]. "</td>";
		echo "<td>" . $row["Qty"]. "</td>";
		echo "<td>" . $row["Price"]. "</td>";
		echo "<td>" . $row["Discount"]. "</td>";
		echo "<td>20/March/2020</td>";
		$total=$total+$row["Sub_Total"];
		//
		echo "<td>" . $row["Sub_Total"]. "</td>
		
		                  <td class='last'><a style='color:red;' href='RemoveSale.php?id=".$row["Sale_id"]."'>Remove</a></td>
						 
		</tr>";
		 
    }
} else {
    
}
$conn->close();
  echo "<tr>
                          <th>Total</th>
                          <th colspan='6'>Rs.".$total."</th>
                        
                        </tr>
                      ";
						
					  ?>
                          
                        
                        </tbody>
                      </table>
                    </div>
							
						
                  </div>
                </div>
              </div>
        	  
          </div>
			  <div class="clearfix"></div>
        </div>
        <!-- /page content -->
		  

        <!-- footer content -->
      <footer>
          <div class="pull-right">
             <a href="https://centromonics.com">Centromonics - Point of Sale</a>
          </div>
          <div class="clearfix"></div>
        </footer>
          <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
   <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    
    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>
  </body>
</html>
