<?php
// Start the session
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
<style>
    .Class
    </style>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Student Attendance</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

  <!-- Page level plugin CSS-->
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">

</head>

<body id="page-top">

  
  <div id="wrapper">

   

    <div id="content-wrapper">

      <div class="container-fluid">

        <!-- Breadcrumbs-->
        

        <!-- DataTables Example -->
          <form method="post">
        <div class="card mb-3">
         
          <div class="card-header">
               <div style="font-size:19px;border-style:double;padding:5px;width:100%;"><center><label>Attendance Report</label></center></div><br>
              
              <label>Date &nbsp;&nbsp;&nbsp;</label><input type="date" name="date_input" data-date-inline-picker="true" value="<?php echo date('Y-m-d'); ?>" style="width:150px;"/>&nbsp;
              <input type="submit"  name="submit"  style="border-style:none;padding-left:15px;padding-right:15px;padding-bottom:5px;padding-top:5px;background-color:#85a7e6;color:white;border-radius:5px;">&nbsp;
     </div>
            
                <div class="card-body">
            <div class="table-responsive">
               
              <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                  <tr>
                 <th>Name</th>
                    <th>Date</th>
                    <th>Attendance</th>
                       <th>Remarks</th>
                  </tr>
                </thead>
                <tfoot>
                  <tr>
                  
                      <th>Name</th>
                    <th>Date</th>
                    <th>Attendance</th>
                      <th>Remarks</th>
                  </tr>
                </tfoot>
                <tbody>
                  
                      
                                         <?php 
 include_once 'con_file.php';
			  $conn;

$reg=1;
$selected_Date="";
$query = "SELECT * FROM staff_attend";
    
                    
if(isset($_POST['submit'])){

$selected_Date = $_POST['date_input'];
    
  /*  if ($selected_val=="ssc2"){
        $query = "SELECT * FROM ssc2_attend where Date='".$D_formate."'";
       
    }
    else if ($selected_val=="hssc2"){
         $query = "SELECT * FROM hssc2_attend where Date='".$D_formate."'";
       
    }
    else if ($selected_val=="hssc1"){
          $query = "SELECT * FROM hssc1_attend where Date='".$D_formate."'";
        
    }
    else{
        $query = "SELECT * FROM ssc1_attend where Date='".$D_formate."'";
      
    }*/
       // $query = "SELECT * FROM ".$selected_val."_attend where Date='".$D_formate."'";
  
    $query = "SELECT  * FROM staff_attend where date='".$selected_Date."'";
  
}

                 

if ($result = $conn->query($query)) {
    
    while ($row = $result->fetch_assoc()) {
    if ($selected_Date="")
    {
        $selected_Date= date("Y/m/d");
    }
        $field1name = $row["name"];
        $field2name = $row["date"];
        $field3name = $row["attend"];
        $field4name = $row["status"];
        
             echo'   
             <tr>
           
                    <td>'.$field1name.'</td>
                    <td>'.$field2name.'</td>
                    <td>'.$field3name.'</td>
                    <td>'.$field4name.'</td>
               
                                 </tr>
             ';
        
        $reg+=1;
        
        $_SESSION["index"] = $reg;
                     }
    $result->free();
} 
?>
                      
                                   
                   
                </tbody>
              </table>
            </div>
          </div>
                
       
        
        </div>

  </form>
      </div>
      <!-- /.container-fluid -->

    </div>
    <!-- /.content-wrapper -->

  </div>
  <!-- /#wrapper -->

  <!-- Scroll to Top Button-->
  
  <!-- Logout Modal-->
  

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Page level plugin JavaScript-->
  <script src="vendor/datatables/jquery.dataTables.js"></script>
  <script src="vendor/datatables/dataTables.bootstrap4.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin.min.js"></script>

  <!-- Demo scripts for this page-->
  <script src="js/demo/datatables-demo.js"></script>

</body>

</html>
