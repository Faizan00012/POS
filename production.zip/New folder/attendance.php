<?php
// Start the session
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>

 <style>
     td,th{padding: 10px;text-align: center;font-size: 20px;}
     label{font-size: 20px;}
     input[type=text]{width: 150px;}
    </style>

  <title>Student Attendance</title>

 

</head>

<body>

  
  
          <div ><form method="post" >
              <label> Class SSC-I</label> 
              &nbsp;&nbsp;<br><br>Group: &nbsp;&nbsp;<select style="width:150px;padding:4px;" name="groups">
              <option value="G1">Group1</option>
              <option value="G2">Group2</option>
              <option value="G3">Group3</option>
              <option value="G4">Group4</option>
              <option value="G5">Group5</option>
              <option value="G6">Group6</option>
              </select> 
              &nbsp;&nbsp;Date: &nbsp;&nbsp;&nbsp;&nbsp;<input style="width:150px;padding:4px;" type="date" value="<?php echo date('Y-m-d'); ?>" name="Date">&nbsp;&nbsp;&nbsp;
              <input type="submit"  style="width:150px;padding:4px;" name="fetch" value="Fetch">
              </form><br>
              
            
     </div>
            <form action="AdminSys_SSC1(Attend).php" method="post" enctype="multipart/form-data">
          <div>
            <div>
              <table border="1" width="100%" cellspacing="0">
                <thead>
                  <tr>
                    <th>Index</th>
                    <th>Reg No</th>
                      <th>Name</th>
                    <th>Date</th>
                    <th>Attendance</th>
                       <th>Remarks</th>
                  </tr>
                </thead>
                <tfoot>
                  <tr>
                     <th>Index</th>
                    <th>Reg No</th>
                      <th>Name</th>
                    <th>Date</th>
                    <th>Attendance</th>
                      <th>Remarks</th>
                  </tr>
                </tfoot>
                <tbody>
                  
                      
                                         <?php 
                      $host = "localhost"; /* Host name */
$user = "root"; /* User */
$password = ""; /* Password */
$dbname = "scholaracademydb"; /* Database name */
$con = mysqli_connect($host, $user, $password,$dbname);
$reg=1;
$query="";       
                    
 if(isset($_POST['fetch'])){
$selected_val = $_POST['groups']; 
$c_Date=$_POST['Date'];      

    $query = "SELECT * FROM ssc1 where _Group='".$selected_val."'";
   
     if ($result = $con->query($query)) {
    while ($row = $result->fetch_assoc()) {
        
        $field1name = $row["Name"];
        $field2name = $row["F_Name"];
        $field3name = $row["Reg_No"];
        
             echo'   
             <tr>
                    <td><input type="hidden" name="GP'.$reg.'"value="'.$selected_val.'">'.$reg.'</td>
                    
                    <td><input type="hidden" name="Reg'.$reg.'"value="'.$row["Reg_No"].'">'.$field3name.'</td>
                    
                    <td><input type="hidden" name="Name'.$reg.'" value="'.$row["Name"].'">'.$field1name.'</td>
           
                    <td><input type="hidden" name="Date'.$reg.'" value="'.$c_Date.'">'.$c_Date.'</td>
                    <td><input name="a'.$reg.'" type="checkbox" checked/> Present</td>
                    <td><input name="R'.$reg.'" type="text" /></td>
             </tr>
             ';
        
        $reg+=1;
        
        $_SESSION["index"] = $reg;
                     }
    $result->free();
} 
 
}

   


?>
                      
                                   
                   
                </tbody>
              </table>
            </div>
          </div>
                <br>
          <div class=""></div>
           <center> 
               <input style="color:white;background-color:blue;border-radius:5px;padding:5px;height:35px;width:150px;border-style:none;" type="submit" name="submit" value="Save Record"></center><br>
             </form>
  

  

</body>

</html>
