<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Update Proudcts</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div id="wrapper">
        <div id="header">
            <h1>Update Proudcts</h1>
        </div>
        <div id="menu">
            <ul>
                <li>
                    <a href="items.php">Back</a>
                </li>
                
            </ul>
        </div>


<div id="main-content">
    <h2>Update Record</h2>
    <?php
    include_once 'con_file.php';
			  $conn;

    $sc_id = $_GET['id'];

    $sql = "SELECT * FROM tblproduct WHERE product_id = {$sc_id}";
    $result = mysqli_query($conn, $sql) or die("Query Unsuccessful.");

    if(mysqli_num_rows($result) > 0)  {
      while($row = mysqli_fetch_assoc($result)){
    ?>
    <form class="post-form" action="updatedata_item.php" method="post">
      <div class="form-group">
          <label>Product Name</label>
         
          <input type="text" name="product_name" value="<?php echo $row['product_name']; ?>"/>
          <input type="hidden" name="product_id" value="<?php echo $row['product_id']; ?>"/>
      </div>
        <div class="form-group">
          <label>Product Barcode</label>
          <input type="text" name="produce_code" value="<?php echo $row['produce_code']; ?>"/>
      </div>
      <div class="form-group">
          <label>Product Detail</label>
          <input type="text" name="product_detail" value="<?php echo $row['product_detail']; ?>"/>
      </div>
      
      <div class="form-group">
          <label>Sale Price</label>
          <input type="text" name="sale_price" value="<?php echo $row['sale_price']; ?>"/>
      </div>
        <div class="form-group">
          <label>Purchase Price</label>
          <input type="text" name="unit_price" value="<?php echo $row['unit_price']; ?>"/>
      </div>
        <div class="form-group">
          <label>Stock</label>
          <input type="text" name="unit_in_stock" value="<?php echo $row['unit_in_stock']; ?>"/>
      </div>
         
      <input class="submit" type="submit" value="Update"/>
    </form>
    <?php
      }
    }
    ?>
</div>
</div>
</body>
</html>
