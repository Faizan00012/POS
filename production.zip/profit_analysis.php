<?php
 session_start();
 
if(empty($_SESSION['username']) || $_SESSION['username'] == ''){
    header("Location: login.php");
    die();
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
	  
	  
	  
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	  <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
 
    <title>Reports | POS</title>
	  
	  <script type="text/javascript" src="jquery.min.js"></script>
<script type="text/javascript" src="moment.min.js"></script>
<script type="text/javascript" src="daterangepicker.min.js"></script>
<link rel="stylesheet" type="text/css" href="daterangepicker.css" />
<script type="text/javascript">
		 
$(function() {

    var start = moment().subtract(29, 'days');
    var end = moment();

    function cb(start, end) {
        $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
    }

    $('#reportrange').daterangepicker({
        startDate: start,
        endDate: end,
        ranges: {
           'Today': [moment(), moment()],
           'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
           'Last 7 Days': [moment().subtract(6, 'days'), moment()],
           'Last 30 Days': [moment().subtract(29, 'days'), moment()],
           'This Month': [moment().startOf('month'), moment().endOf('month')],
           'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        }
    }, cb);

    cb(start, end);

});
	
    function cbs() {
        var startDate = $('#reportrange').data('daterangepicker').startDate._d;
		var endDate = $('#reportrange').data('daterangepicker').endDate._d;
		 
	            var a = startDate; 
                var Smonth = ("0" + (a.getMonth() + 1)).slice(-2); 
                var Sdate = ("0" + a.getDate()).slice(-2); 
                var b = endDate; 
                var emonth = ("0" + (b.getMonth() + 1)).slice(-2); 
                var edate = ("0" + b.getDate()).slice(-2); 
       
	 
		
		//alert(Sdate+"/"+Smonth+"/20");
		//alert(edate+"/"+emonth+"/20");
				
	// 	document.getElementById("SDate").value=Smonth+"/"+Sdate+"/21";
	// 	document.getElementById("EDate").value=emonth+"/"+edate+"/21";
       var d = new Date();
  var n = d.getFullYear();
      document.getElementById("SDate").value=Smonth+"/"+Sdate+"/"+n;
 	document.getElementById("EDate").value=emonth+"/"+edate+"/"+n;
		
		
    }

   
		 
		 
		 
	  </script>
	   <link href="cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- Datatables -->
    
    <link href="../vendors/datatables.net-bs/css/dataTables.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-buttons-bs/css/buttons.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-fixedheader-bs/css/fixedHeader.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-responsive-bs/css/responsive.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-scroller-bs/css/scroller.bootstrap.min.css" rel="stylesheet">
   <link rel="stylesheet" type="text/css" href="demo_screen.css">
  <link rel="stylesheet" type="text/css" href="demo_print.css" media="print">
    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
    <!-- Bootstrap -->
    <link href="cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- Datatables -->
    
    <link href="../vendors/datatables.net-bs/css/dataTables.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-buttons-bs/css/buttons.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-fixedheader-bs/css/fixedHeader.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-responsive-bs/css/responsive.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-scroller-bs/css/scroller.bootstrap.min.css" rel="stylesheet">

	     <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
	  <link href="../vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
	   <link href="../vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">
	  
    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
      <style>
      @media print {
  * {
    display: none;
  }
  #printableTable {
    display:block;
  }
}
      </style>
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
         <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
      <?php include_once 'menu.php';?>   
			  <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
            <div class="sidebar-footer hidden-small">
              <a data-toggle="tooltip" data-placement="top" title="Settings">
                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="FullScreen">
                <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Lock">
                <span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Logout" href="login.php">
                <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
              </a>
            </div>
            <!-- /menu footer buttons -->
          </div>
        </div>

        <!-- top navigation -->
         <div class="top_nav">
          <div class="nav_menu">
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>
              <nav class="nav navbar-nav">
              <ul class=" navbar-right">
                <li class="nav-item dropdown open" style="padding-left: 15px;">
                  <a href="javascript:;" class="user-profile dropdown-toggle" aria-haspopup="true" id="navbarDropdown" data-toggle="dropdown" aria-expanded="false">
                    <?php echo $_SESSION["username"]; ?>
                  </a>
                  <div class="dropdown-menu dropdown-usermenu pull-right" aria-labelledby="navbarDropdown">
					  <?php
					  include_once 'con_file.php';
			  $conn;

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
					  $sql = "SELECT username, access FROM users";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		if ($_SESSION["username"]==$row["username"])
		{
			
			$access=$row["access"];
			if ($access=="admin"){
				echo "<a class='dropdown-item'  href='setting.php'><i class='fa fa-gear pull-right'></i> Settings</a>";
			}
			
			
					 
		}
       
    }
} else {
    
}
$conn->close();
?> 
					  
                    
                    <a class="dropdown-item"  href="login.php"><i class="fa fa-sign-out pull-right"></i> Log Out</a>
                  </div>
                </li>

              </ul>
            </nav>
          </div>
        </div>
       <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
			  
			  <form method="post">
                
              <div class="col-md-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Profitability Analysis Report</h2>
                    <div class="filter">
						  
                      <div id="reportrange" class="pull-right" style="background: #fff; cursor: pointer; padding: 5px 10px; border: 1px solid #ccc">
                        <i class="fa fa-calendar">&nbsp;&nbsp;</i>
                        <span>January 05, 2020 - January 01, 2026</span> <b class="caret"></b>
                      </div>
						
                    </div>
                    <div class="clearfix"></div>
					  
                  </div><input type="hidden" name="date_R" id="SDate"/><input type="hidden" name="date_E" id="EDate"/>
					<center><input style="width: 120px;height:50px;" onclick="cbs()" type="submit" value="Show Record" class="btn btn-app" ></center>
                </div>
				  
              </div>
            
</form>

            <div class="clearfix"></div>
			  <div class="row">
    		  
			  
			 		  
           
             
                     <?php 
					        include_once 'con_file.php';
			  $conn;
                         $newDate="";
				         $newDateE="";
				  		 $S_Day="";
				  		 $E_Day="";
							$conn = new mysqli($servername, $username, $password, $dbname);

							if ($conn->connect_error) {
    						die("Connection failed: " . $conn->connect_error);
							} 
						  
					  
		              
				    if(isset($_POST['date_R'])){
					  $origDate = $_POST["date_R"];
						   $newDate = date("Y-m-d", strtotime($origDate));
						$S_Day = substr($newDate, 0, -6);
						
						 
				  		 
						$origDateE = $_POST["date_E"];
						   $newDateE = date("Y-m-d", strtotime($origDateE));
$E_Day = substr($newDateE, 0, -6);
						$dd=$newDate.", ".$newDateE;
						// echo "<script type='text/javascript'>alert('$dd');</script>";
				  }
				  else{
					   
						   $newDate = date("Y-m-d");
				  }
					  
				
?>
			  

              
            </div>
			 <div class="clearfix"></div>
			   
				   			 
	 
	<div class="clearfix"></div>
			  <?php
              if (isset($origDate)){
              ?>
				   	<div class="col-md-12 col-sm-4 ">
              <div class="x_panel tile">
                <div class="x_title">
             <h2>Date: <?php
						/*if ($newDate==$newDateE||$newDateE==""){
						echo date("d-m-Y", strtotime($newDate));
					 
					}else{
							echo date("d-m-Y", strtotime($newDate))." To ".date("d-m-Y", strtotime($newDateE)); 
						}
                         */
                echo $origDate;
               ?></h2><br><br>
                 
              
                 
                </div>
				  
				  
                <div class="x_content">
               <button onclick="selectElementContents( document.getElementById('table1') );" style="border-radius:4px;background-color:gray;padding:6px;border-style:none;color:white;"><i class="fa fa-copy"></i> Copy </button>
                     <button onclick="exportTableToExcel('table1', 'profitanalysis')" style="border-radius:4px;background-color:#4287f5;padding:6px;border-style:none;color:white;"><i class="fa fa-file-excel-o"></i> Export</button>
                    <button onclick="printDiv()" style="border-radius:4px;background-color:#1ea66b;padding:6px;border-style:none;color:white;"><i class="fa fa-print"></i> Print</button>
                    <div id="printableTable">
					<table id="table1" class="table1" style="width:100%;border-style:solid;border-color:black;color:black;">
                        <tr>
                            <th style="text-align:center;border-bottom-style:double;padding:5px;color:black;" colspan="10"><h2>Profitability Analysis Report</h2></th></tr>
					<tr>
						<th style="border-bottom-style:solid;width:10%;padding:5px;color:black;">S-NO</th>
						<th style="border-bottom-style:solid;width:10%;padding:7px;color:black;">Invoice NO</th>
                        <th style="border-bottom-style:solid;width:15%;padding:7px;color:black;">Product</th>
                        <th style="border-bottom-style:solid;width:5%;padding:7px;color:black;">Qty</th>
                        <th style="border-bottom-style:solid;width:10%;padding:7px;color:black;">Sale Price</th>
                        <th style="border-bottom-style:solid;width:10%;padding:15px;color:black;">Date</th>
						<th style="border-bottom-style:solid;width:15%;padding:5px;color:black;">Customer Name</th>
						<th style="border-bottom-style:solid;width:15%;padding:5px;color:black;">Address</th>
						<th style="border-bottom-style:solid;width:10%;padding:5px;color:black;">Proft</th>
						<th style="border-bottom-style:solid;width:10%;padding:5px;color:black;">Loss</th>
					 
						</tr>
						
						 
							<?php
						
						   
						$Profit=0;
				      $total_profit=0;
				  	$total_loss=0;
					  $rowdate=0;
					  $name=0;
					  $address=0;
						
				                  
	 $sql = "SELECT * FROM tblinvoice invoice INNER JOIN tblsale sale ON sale.invoice_id=invoice.invoice_id INNER JOIN tblcustomer customer ON invoice.customer_id=customer.customer_id INNER JOIN tblproduct product ON sale.product_id=product.product_id  WHERE invoice.invoice_date BETWEEN  '".$newDate."' And '".$newDateE."'"; 
 	 
				 $s_no=0;
			  
$result = $conn->query($sql);
		  if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {

		$Profit=($row["sale_price"]-$row["unit_price"])*$row["quantity"];
		$rowdate=$row["invoice_date"];
		$name=$row["customer_name"];
		$address=$row["customer_contact"];
		$s_no=$s_no+1;
		echo "<tr><td style='padding:5px;'>".$s_no."</td>";
		echo "<td style='padding:5px;'>".$row["invoice_id"]."</td>";
        echo "<td style='padding:5px;'>".$row["product_name"]." (".$row["product_detail"].")</td>";
       echo "<td style='padding:5px;'>".$row["quantity"]."</td>";
        echo "<td style='padding:5px;'><b>".$row["sale_price"].".00</b></td>";
		echo "<td style='padding:5px;'>".$rowdate."</td>";
		echo "<td style='padding:5px;'>".$name."</td>";
		echo "<td style='padding:5px;'>".$address."</td>";
		if ($Profit>=0){
			echo "<td style='padding:5px;'><b>".$Profit.".00</b></td>";
			echo "<td style='padding:5px;'><b>0.00</b></td>";
			$total_profit=$total_profit+$Profit;
			
		}
		else{
			echo "<td style='padding:5px;'><b>0.00</b></td>";
			echo "<td style='padding:5px;'>".abs($Profit).".00</td></tr>";
			$total_loss=$total_loss+abs($Profit);
		}
 
    
	}
}
		echo "<tr><td colspan='8' style='padding:5px;border-top-style:solid'><b>Total</b></td>";
				echo "<td style='padding:5px;border-top-style:solid'><b>".$total_profit.".00</b></td>";
					echo "<td  style='padding:5px;border-top-style:solid'><b>".$total_loss.".00</b></td></tr>";
						
						?>
					 
					 
						
					
					</table>
                    </div>
                     <iframe name="print_frame" width="0" height="0" frameborder="0" src="about:blank"></iframe>

                </div>
              </div>
            </div>
			 
			<?php	
              }
			    ?>
	
			 
			  <div class="clearfix"></div> 
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
       <footer>
          <div class="pull-right">
             <a href="https://centromonics.com">Centromonics - Point of Sale</a>
          </div>
          <div class="clearfix"></div>
        </footer>
         <!-- /footer content -->
      </div>
    </div>
<script>
              function printDiv() {
         window.frames["print_frame"].document.body.innerHTML = document.getElementById("printableTable").innerHTML;
         window.frames["print_frame"].window.focus();
         window.frames["print_frame"].window.print();
       }
    function selectElementContents(el) {
	var body = document.body, range, sel;
	if (document.createRange && window.getSelection) {
		range = document.createRange();
		sel = window.getSelection();
		sel.removeAllRanges();
		try {
			range.selectNodeContents(el);
			sel.addRange(range);
		} catch (e) {
			range.selectNode(el);
			sel.addRange(range);
		}
	} else if (body.createTextRange) {
		range = body.createTextRange();
		range.moveToElementText(el);
		range.select();
	}
}
    function exportTableToExcel(tableID, filename = ''){
    var downloadLink;
    var dataType = 'application/vnd.ms-excel';
    var tableSelect = document.getElementById(tableID);
    var tableHTML = tableSelect.outerHTML.replace(/ /g, '%20');
    
    // Specify file name
    filename = filename?filename+'.xls':'excel_data.xls';
    
    // Create download link element
    downloadLink = document.createElement("a");
    
    document.body.appendChild(downloadLink);
    
    if(navigator.msSaveOrOpenBlob){
        var blob = new Blob(['\ufeff', tableHTML], {
            type: dataType
        });
        navigator.msSaveOrOpenBlob( blob, filename);
    }else{
        // Create a link to the file
        downloadLink.href = 'data:' + dataType + ', ' + tableHTML;
    
        // Setting the file name
        downloadLink.download = filename;
        
        //triggering the function
        downloadLink.click();
    }
}
   
      </script>
    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
   <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    
    <!-- iCheck -->
    <script src="../vendors/iCheck/icheck.min.js"></script>
    <!-- Datatables -->
    <script src="../vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="../vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="../vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="../vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
    <script src="../vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
    <script src="../vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="../vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
    <script src="../vendors/datatables.net-scroller/js/dataTables.scroller.min.js"></script>
    <script src="../vendors/jszip/dist/jszip.min.js"></script>
    <script src="../vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="../vendors/pdfmake/build/vfs_fonts.js"></script>
	  
	   <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
   <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- iCheck -->
    <script src="../vendors/iCheck/icheck.min.js"></script>
    <!-- Datatables -->
    <script src="../vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="../vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="../vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="../vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
    <script src="../vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
    <script src="../vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="../vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
    <script src="../vendors/datatables.net-scroller/js/dataTables.scroller.min.js"></script>
    <script src="../vendors/jszip/dist/jszip.min.js"></script>
    <script src="../vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="../vendors/pdfmake/build/vfs_fonts.js"></script>

    <!-- Custom Theme Scripts -->
	  
	  
	   <script src="../vendors/nprogress/nprogress.js"></script>
	  <script src="../vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
	  
	   <script src="../vendors/moment/min/moment.min.js"></script>
    <script src="../vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
	  

    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>

  </body>
</html>
