<?php
session_start();
?>
<?php
include_once 'con_file.php';
			  $conn;
                         
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
$var_index=0;

$sql="";
$insertTrig=true;
$Dupl=false;
$invoice="";
$status="";
$net="";
$profit="";
$due="";
$paid="";
$I_qty="";
$item="";
$U_price="";
						$I_price="";
						$I_detail="";
						$I_discount="";
						$I_total="";
						$I_qty="";
						$name="";
						$contact="";
						$email="";
						$address="";
						$date="";
$remove_item=array();
$remove_qty=array();
$remove_price=array();
$remove_Uprice=array();
$remove_detail=array();
$remove_discount=array();
$remove_total=array();
$remove_index=0;



if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

  
						
if(isset($_POST["submit"])) {
      
	 $invoice=$_POST["invoice"];
	$status=$_POST["status"];
 $sql="";
    if ($status=="Customer"){
		$sql = "SELECT date,items, I_Qty, I_Price,I_UPrice,  I_Detail, I_Discount, I_Stotal, Discount, total, profit, Paid, C_Name, C_Contact, C_Email, C_Address, C_Due FROM sale_client  WHERE invoiceNo='".$invoice."'";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
		 $profit=$row["profit"];
		 
		
		$name=$row["C_Name"];
						$contact=$row["C_Contact"];
						$email=$row["C_Email"];
						$address=$row["C_Address"];
						$date=$row["date"];
        
    }} else {}
	}
	else{
		$sql = "SELECT invoiceNo, date,items, I_Qty, I_Price, I_Detail, I_Discount, I_Stotal, Discount, total, Paid, S_Name, S_Contact, S_Email, S_Address, S_Due FROM purchase_seller WHERE invoiceNo='".$invoice."'";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $name=$row["S_Name"];
						$contact=$row["S_Contact"];
						$email=$row["S_Email"];
						$address=$row["S_Address"];
						$date=$row["date"];
    }} else {}
	}
	
	$var_index= $_SESSION["index"];
	$net=$_POST["Net"];
$due=$_POST["due"];
$paid=$_POST["paid"];

    for ($i = 0; $i <= $var_index; $i++) {
        $x1= $_POST["qty".$i];
         $x2= $_POST["item".$i];
         $x3= $_POST["price".$i];
		 $x4= $_POST["detail".$i];
		$x5= $_POST["discount".$i];
		 $x6= $_POST["sub".$i];
		$x7= $_POST["U_price".$i];
        
          //$x6= $_POST["return".$i];
        
    
     if (isset($_POST["return".$i])) {
	  $net=$net-(double)$_POST["sub".$i];
	 	  $paid=$paid-(double)$_POST["sub".$i];
		 
	 	$remove_item[$remove_index]=$_POST["item".$i];
     	$remove_qty[$remove_index]=$_POST["qty".$i];
     	$remove_price[$remove_index]=$_POST["price".$i];
		$remove_Uprice[$remove_index]=$_POST["U_price".$i];
     	$remove_detail[$remove_index]=$_POST["detail".$i];
	    $remove_discount[$remove_index]=$_POST["discount".$i];
		$remove_total[$remove_index]=$_POST["sub".$i];
	 	$profit=$profit-(((float)$remove_price[$remove_index]-(float)$remove_Uprice[$remove_index])*$remove_qty[$remove_index]);
	 
		 
		$remove_index=$remove_index+1;
		 
		
 
		  
		
	 
	 
	 
	 }
     if (!isset($_POST["return".$i])) {
       
	   
	   					$item=$item.$x2." |";
						$I_qty=$I_qty.$x1." |";
						$I_price=$I_price.$x3." |";
		 				$U_price=$U_price.$x7." |";
						$I_detail=$I_detail.$x4." |";
		 $I_discount=$I_discount.$x5." |";
						$I_total=$I_total.$x6." |";
		 
		 
	   
        }
        
       
    }
     
	 if ($status=="Customer"){
		 
	 	$sql = "DELETE FROM sale_client WHERE invoiceNo='".$invoice."'";
	 
	 if ($conn->query($sql) === TRUE) {
    echo "Record deleted successfully";
} else {
    echo "Error deleting record: " . $conn->error;
}
	 
		
		// insert to purchase_seller
	 	$sql = "INSERT INTO sale_client (invoiceNo, date, items,I_Qty,I_Price, I_UPrice,I_Detail,I_Discount, I_Stotal, total, profit, Paid, C_Name, C_Contact, C_Email, C_Address,C_Due)
							VALUES ('".$invoice."','".$date."','".$item."','".$I_qty."','".$I_price."','".$U_price."','".$I_detail."','".$I_discount."','".$I_total."','".$net."','".$profit."','".$paid."','".$name."','".$contact."','".$email."','".$address."','".$due."')";
							 
		if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
   //Amount Paid Due
		 $sql = "UPDATE customer SET Amount='".$net."', Paid='".$paid."' WHERE inoviceNo='".$invoice."'";

if ($conn->query($sql) === TRUE) {
 
} else {
    
}
	
		 
		 
		 
		
		
	for ($k=0;$k<$remove_index;$k++){
	
	 
		$sql = "DELETE FROM sale_item WHERE invoiceNo='".$invoice."' AND Name='".$remove_item[$k]."' AND detail='".$remove_detail[$k]."'";
	
if ($conn->query($sql) === TRUE) {
    echo "Record deleted successfully";
} else {
    echo "Error deleting record: " . $conn->error;
}
		
	 
		
		
		$sql = "SELECT P_Price, S_Price, Remain_Qty, Sale_Qty, Total_Purchase FROM items where name='".$remove_item[$k]."' AND detail='".$remove_detail[$k]."'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
       
		  
		$TP=(double)$row["Sale_Qty"];
		$RemainQ=(double)$row["Remain_Qty"];
		$RemoveQ=(double)$remove_qty[$k];
		
	 
		$TP=$TP-$RemoveQ;
	 
		$RemainQ=$RemainQ+$RemoveQ;
	 
	 	
	 	$sql = "UPDATE items SET Remain_Qty='".$RemainQ."' , Sale_Qty='".$TP."' WHERE  Name='".$remove_item[$k]."' AND detail='".$remove_detail[$k]."'";
 
		if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
} else {
    echo "Error updating record: " . $conn->error;
}
 
		
    }
} 
		
	}
		  
	}
	else{
		 
		$sql = "DELETE FROM purchase_seller WHERE invoiceNo='".$invoice."'";
		echo $invoice;
	 if ($conn->query($sql) === TRUE) {
    echo "Record deleted successfully";
} else {
    echo "Error deleting record: " . $conn->error;
}
		 
		
		// insert to purchase_seller
	 	$sql = "INSERT INTO purchase_seller (invoiceNo, date, items,I_Qty,I_Price,I_Detail,I_Discount, I_Stotal, total, Paid, S_Name, S_Contact, S_Email, S_Address)
							VALUES ('".$invoice."','".$date."','".$item."','".$I_qty."','".$I_price."','".$I_detail."','".$I_discount."','".$I_total."','".$net."','".$paid."','".$name."','".$contact."','".$email."','".$address."')";
							if ($conn->query($sql) === TRUE) {
    
} else {
    
}
	
		 
		
		
	for ($k=0;$k<$remove_index;$k++){
		echo ($k);
		echo "<br>".$remove_item[$k]."<br>";
     	echo $remove_qty[$k]."<br>";
     	echo $remove_price[$k]."<br>";
		echo $remove_detail[$k]."<br>";
	    echo $remove_discount[$k]."<br>";
		echo $remove_total[$k]."<br>";
	 
		$sql = "DELETE FROM purchase_item WHERE invoiceNo='".$invoice."' AND Name='".$remove_item[$k]."' AND detail='".$remove_detail[$k]."'";
	
if ($conn->query($sql) === TRUE) {

} else {
   
}  	
		
		
		$sql = "SELECT P_Price, S_Price, Remain_Qty, Total_Purchase FROM items where name='".$remove_item[$k]."' AND detail='".$remove_detail[$k]."'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
       
		  
		$TP=(double)$row["Total_Purchase"];
		$RemainQ=(double)$row["Remain_Qty"];
		$RemoveQ=(double)$remove_qty[$k];
		
	 
		$TP=$TP-$RemoveQ;
	 echo $TP;
		echo "<br>";
		$RemainQ=$RemainQ-$RemoveQ;
		 echo $RemainQ;
				echo "<br>";
	 	
	  
 
		
    }
} else {
    echo "0 results";
}
		
	}	
/*
 

detail
P_Price
S_Price
percentage
Sale_Qty
Remain_Qty
Sale_Product
Total_Purchase


//update items
        	
*/
	 
		}
 header("location: ReturnShow.php");


 $conn->close();
    
}
   
    
   
 
    
    

 

        
        






?> 