 <?php

 session_start();
 echo $_SESSION['username'];
if(empty($_SESSION['username']) || $_SESSION['username'] == ''){
    header("Location: login.php");
    die();
}
   include 'con_file.php';
  
  
                $url =  "//{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";
                $arr = array();
$arr=explode("=",$url);
    $sql = "DELETE FROM product_list WHERE product_id= {$arr[1]}";
  if ($conn->query($sql) === TRUE) {
    echo "Record deleted successfully";
} else {
    echo "Error deleting record: " . $conn->error;
}
header("Location: product_update.php");

    ?>
             