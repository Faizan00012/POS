<?php
 session_start();
 
if(empty($_SESSION['username']) || $_SESSION['username'] == ''){
    header("Location: login.php");
    die();
}
?> 
<?php
							  $trig=true;
							include_once 'con_file.php';
			  $conn;
							  	$name="";
								$contact="";
								$address="";
								$email="";
								$dup=0;
							  
                         
							$conn = new mysqli($servername, $username, $password, $dbname);

							
						
						   $sql = "SELECT Sale_id, Item_Name, Price,U_Price, detail, Discount, exp, Qty, C_Name,C_Contact,C_Email, C_Address, Sub_Total FROM Sale";
$result = $conn->query($sql);
$total=0;
							  $qty=0;
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		
		
		$qty=$qty+$row["Qty"];
								if ($row["C_Name"]!=""){
								$name=$row["C_Name"];
								$contact=$row["C_Contact"];
								$address=$row["C_Address"];
								$email=$row["C_Email"];
								}
							 	 
							
				}
								
					
					}
							 
							 
							 
							 $conn->close();
 
				
	include_once 'con_file.php';
			  $conn;
                         $Total_P="";
							$conn = new mysqli($servername, $username, $password, $dbname);

							if ($conn->connect_error) {
    						die("Connection failed: " . $conn->connect_error);
							} 
			
?>						 
						 
                       


<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="style.css">
        <title>Sale Invoice | C-POS</title>
    </head>
    <body>
        <div class="ticket">
            <img src="./logo.png" alt="Logo">
            <h2>C-POS Point Of Sale</h2>
            <p class="centered"><u>Invoice No.00
						<?php
                        $l_invoice=array();
                        $in_index=0;
						$last_id=1;
						$Item="";
						$I_qty="";
						$I_price="";
						$U_price="";
					 			$exp=0;
						$I_detail="";
						$I_discount="";
						$I_total="";
						$UN_Price=0;
						$Profit=0;
						 
					
						include_once 'con_file.php';
			  $conn;
                         
							$conn = new mysqli($servername, $username, $password, $dbname);

							if ($conn->connect_error) {
    						die("Connection failed: " . $conn->connect_error);
							} 
						 $sql = "SELECT invoiceNo  FROM sale_client;";
						
						
						$result = $conn->query($sql);
if ($result->num_rows > 0) {
	
    // output data of each row
    while($row = $result->fetch_assoc()) {
						
						   if ($row["invoiceNo"]!=""){
                             $l_invoice[$in_index]=number_format($row["invoiceNo"]);
                        $in_index=$in_index+1;
						  //  $last_id=$row["invoiceNo"];
							   }
		else{
			$last_id=1;
		}
	
		
	}
  $last_id = max($l_invoice);
	$last_id+=1;
						    echo($last_id);
}
							
							?></u></p>
            <table>
                <thead>
                    <tr>
                        <th class="quantity">Qty</th>
                        <th class="description">Description</th>
                        <th class="price">Amount</th>
                    </tr>
                </thead>
                <tbody>
					
					<?php
					$sql = "SELECT Sale_id, Price, U_Price, Item_Name, detail,Discount,Qty,Sub_Total,C_Name,C_Address,C_Contact,C_Email FROM sale";
$result = $conn->query($sql);
$total=0;
								
							
if ($result->num_rows > 0) {
	
    // output data of each row
    while($row = $result->fetch_assoc()) {
		
	                 
			
		$UN_Price=$UN_Price+($row["U_Price"]*$row["Qty"]);
		 
		 
        echo "<tr><td class='quantity'>" . $row["Qty"]. "</td>";
		echo "<td class='description'>" . $row["Item_Name"]." (".$row["detail"] ")</td>";
	 
		echo "<td class='price'>Rs. " . $row["Price"]. "</td></tr>";
	 
		
		$total=$total+$row["Sub_Total"];
	 
			$Item=$Item.$row["Item_Name"]." |";
						$I_qty=$I_qty.$row["Qty"]." |";
		                $U_price=$U_price.$row["U_Price"]." |";
						$I_price=$I_price.$row["Price"]." |";
						$I_detail=$I_detail.$row["detail"]." |";
						$I_discount=$I_discount.$row["Discount"]." |";
						$I_total=$I_total.$row["Sub_Total"]." |";
						
		 }
	 
 
	$profit=$total-$UN_Price;
 	 
} else {
    
}
					 $n=1;
							
	include_once 'con_file.php';
			  $conn;
                         
							$conn = new mysqli($servername, $username, $password, $dbname);

							if ($conn->connect_error) {
    						die("Connection failed: " . $conn->connect_error);
							} 
						
 
 			
						  	$sql = "SELECT Sale_id, Price, Item_Name, detail,Discount, exp, DC_Mode,Qty,Sub_Total FROM sale";	
						    $result = $conn->query($sql);
						    $total=0;
						  $Net_A=0;
						  $Net_D=0;
						  $Net_T=0;
						  	if ($result->num_rows > 0) {
    // output data of each row
								while($row = $result->fetch_assoc()) {
									if ($row["exp"]>0){
										$exp=$row["exp"];
									}
									 
									
									$sql = "UPDATE items SET Remain_Qty=Remain_Qty-'".$row["Qty"]."', Sale_Qty=Sale_Qty+'".$row["Qty"]."', Sale_Product=Sale_Product+'".$row["Qty"]."' WHERE Name='".$row["Item_Name"]."' AND detail='".$row["detail"]."' ";

									if ($conn->query($sql) === TRUE) {
  
									} else {

									}	 

									 
										$sql = "INSERT INTO sale_item (invoiceNo, Name, detail, Price,	P_Qty,P_Date, seller)
VALUES ('".$last_id."','".$row["Item_Name"]."','".$row["detail"]."','".$row["Price"]."','".$row["Qty"]."','".date("Y-m-d")."','".$_SESSION['username']."')";
if ($conn->query($sql) === TRUE) {
  
} else {

} 
							if ($row["DC_Mode"]=="net"){
										$Net_D+=$row["Discount"]*$row["Qty"];
									}
									else{
										$Net_D+=($row["Qty"]*$row["Price"])*$row["Discount"]/100;
									}
							    $Net_A+=$row["Qty"]*$row["Price"];
							 
									$Net_T+=$row["Sub_Total"];
									
									
									
									
								}
								
								$sql = "INSERT INTO customer (name, address, email, contact, inoviceNo, Date, Net , Amount,Paid, Due, exp, seller)
VALUES ('".$name."','".$contact."','".$email."','".$address."','".$last_id."','".date("Y-m-d")."','".$Net_A."','".$Net_T."','".$_POST["paid"]."','".$_POST["remain"]."','".$exp."','".$_SESSION['username']."')";
if ($conn->query($sql) === TRUE) {
    
} else {

}		
							}
 
						include_once 'con_file.php';
			  $conn;
                         
							$conn = new mysqli($servername, $username, $password, $dbname);

							if ($conn->connect_error) {
    						die("Connection failed: " . $conn->connect_error);
							} 
						
						$Netdiscount=0;
						$Nettotal=0;
						if(isset($_POST['submit'])){
						
						if ($name==""){
							$name="Walkin";
							$contact="03XXXX";
							$email="XXXX";
								$address="XXXX";
						}

							$sql = "INSERT INTO sale_client (invoiceNo, date, items,I_Qty,I_Price, I_UPrice, I_Detail, I_Discount, I_Stotal, Discount, total, profit,Unit_Price, Qty,Paid, C_Name, C_Contact, C_Email, C_Address, C_Due, exp, seller)
							VALUES ('".$last_id."','".date("Y-m-d") ."','".$Item."','".$I_qty."','".$I_price."','".$U_price."','".$I_detail."','".$I_discount."','".$I_total."','".$Net_D."','".$Net_T."','".$profit."','".$UN_Price."','".$row["Qty"]."','".$_POST["paid"]."','".$name."','".$contact."','".$email."','".$address."','".$_POST["remain"]."','".$exp."','".$_SESSION['username']."')";
						
							 

							if ($conn->query($sql) === TRUE) {
							} else {
    						echo "Error: " . $sql . "<br>" . $conn->error;
							}
								if ($exp!="0"){
										  $sql = "INSERT INTO expense (Date, detail, Cost,behaviour, seller)
VALUES ('".date("Y-m-d")."', 'Sale Item invoice: ".$last_id."', '".$exp."', 'Sale','".$_SESSION['username']."')";

if ($conn->query($sql) === TRUE) {
     
} else {
    
}
							}
							
							$sql = "delete from sale";
							 

							if ($conn->query($sql) === TRUE) {
							} else {
    						echo "Error: " . $sql . "<br>" . $conn->error;
							}

						
							
			  				  
						 }
						
						
$conn->close();
						
						
								
?>
					?>
                    
                    <tr>
                        <td class="quantity"></td>
                        <td class="description">TOTAL</td>
                        <td class="price"><?php echo $Net_T; ?></td>
                    </tr>
                </tbody>
            </table>
            <p class="centered">Thanks for your Sale!
             
        </div>
        <button id="btnPrint" class="hidden-print">Print</button>
        <script src="script.js"></script>
    </body>
</html>