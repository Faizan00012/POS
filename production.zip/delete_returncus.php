<?php
include_once 'con_file.php';
$conn;
$id=$_GET["id"];
$arr = explode("-", $id);
$sale_id=$arr[0];
$invoice_id=$arr[1];
$product_id=$arr[2];
$quantity=0;
$invoice_date="";
$sub=0;
$sql = "SELECT invoice_date FROM tblinvoice WHERE invoice_id = {$invoice_id}";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
       $invoice_date=$row["invoice_date"];
    }
} 
$sql = "SELECT quantity,sub_total FROM tblsale WHERE sale_id = {$sale_id}";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
       $quantity=$row["quantity"];
        $sub=$row["sub_total"];
    }
} 

 $sql = "DELETE FROM  tblsale WHERE sale_id = {$sale_id}";
 //echo $sql."<br>";
 $result = mysqli_query($conn, $sql) or die("1Query Unsuccessful.");

$sql = "UPDATE tblproduct SET unit_in_stock = (unit_in_stock-{$quantity})  WHERE product_id = {$product_id}";
// echo $sql."<br>";
 $result = mysqli_query($conn, $sql) or die("2Query Unsuccessful.");
 
$sql = "UPDATE tblinvoice SET invoice_date = '".date("Y-m-d") ."', revise='".$invoice_date."', total_amount = (total_amount-{$sub}) , paid_amount = (paid_amount-{$sub})  WHERE invoice_id = {$invoice_id}";
//echo $sql."<br>";
 $result = mysqli_query($conn, $sql) or die("3Query Unsuccessful.");
 

 header("Location: return.php?id=".$invoice_id);

mysqli_close($conn);

?>
