<?php
 session_start();
 $client_name="";
if(empty($_SESSION['username']) || $_SESSION['username'] == ''){
    header("Location: login.php");
  $client_name=$_SESSION['username'];
    die();
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
	  
	  
	  
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	  <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
 
    <title>Reports | C-POS</title>
	  
	  <script type="text/javascript" src="jquery.min.js"></script>
<script type="text/javascript" src="moment.min.js"></script>
<script type="text/javascript" src="daterangepicker.min.js"></script>
<link rel="stylesheet" type="text/css" href="daterangepicker.css" />
<script type="text/javascript">
		 
$(function() {

    var start = moment().subtract(29, 'days');
    var end = moment();

    function cb(start, end) {
        $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
    }

    $('#reportrange').daterangepicker({
        startDate: start,
        endDate: end,
        ranges: {
           'Today': [moment(), moment()],
           'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
           'Last 7 Days': [moment().subtract(6, 'days'), moment()],
           'Last 30 Days': [moment().subtract(29, 'days'), moment()],
           'This Month': [moment().startOf('month'), moment().endOf('month')],
           'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        }
    }, cb);

    cb(start, end);

});
	
    function cbs() {
        var startDate = $('#reportrange').data('daterangepicker').startDate._d;
		var endDate = $('#reportrange').data('daterangepicker').endDate._d;
		 
	            var a = startDate; 
                var Smonth = ("0" + (a.getMonth() + 1)).slice(-2); 
                var Sdate = ("0" + a.getDate()).slice(-2); 
                var b = endDate; 
                var emonth = ("0" + (b.getMonth() + 1)).slice(-2); 
                var edate = ("0" + b.getDate()).slice(-2); 
       
	 
		
		//alert(Sdate+"/"+Smonth+"/20");
		//alert(edate+"/"+emonth+"/20");
				
	//	document.getElementById("SDate").value=Smonth+"/"+Sdate+"/20";
	//	document.getElementById("EDate").value=emonth+"/"+edate+"/20";
       var d = new Date();
  var n = d.getFullYear();
      document.getElementById("SDate").value=Smonth+"/"+Sdate+"/"+n;
 	document.getElementById("EDate").value=emonth+"/"+edate+"/"+n;
		
		
    }

   
		 
		 
		 
	  </script>
	   <link href="cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- Datatables -->
    
    <link href="../vendors/datatables.net-bs/css/dataTables.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-buttons-bs/css/buttons.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-fixedheader-bs/css/fixedHeader.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-responsive-bs/css/responsive.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-scroller-bs/css/scroller.bootstrap.min.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
    <!-- Bootstrap -->
    <link href="cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- Datatables -->
    
    <link href="../vendors/datatables.net-bs/css/dataTables.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-buttons-bs/css/buttons.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-fixedheader-bs/css/fixedHeader.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-responsive-bs/css/responsive.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-scroller-bs/css/scroller.bootstrap.min.css" rel="stylesheet">

	     <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
	  <link href="../vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
	   <link href="../vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">
	  
    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
         <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
          <?php include_once 'client_menu.php';?>         <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
            <div class="sidebar-footer hidden-small">
              <a data-toggle="tooltip" data-placement="top" title="Settings">
                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="FullScreen">
                <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Lock">
                <span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Logout" href="login.php">
                <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
              </a>
            </div>
            <!-- /menu footer buttons -->
          </div>
        </div>

        <!-- top navigation -->
         <div class="top_nav">
          <div class="nav_menu">
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>
              <nav class="nav navbar-nav">
              <ul class=" navbar-right">
                <li class="nav-item dropdown open" style="padding-left: 15px;">
                  <a href="javascript:;" class="user-profile dropdown-toggle" aria-haspopup="true" id="navbarDropdown" data-toggle="dropdown" aria-expanded="false">
                    <?php echo $_SESSION["username"]; ?>
                  </a>
                  <div class="dropdown-menu dropdown-usermenu pull-right" aria-labelledby="navbarDropdown">
					  <?php
					  include_once 'con_file.php';
			  $conn;

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
					  $sql = "SELECT username, access FROM users";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		if ($_SESSION["username"]==$row["username"])
		{
          $client_name=$row["username"];
			
			$access=$row["access"];
			if ($access=="admin"){
				echo "<a class='dropdown-item'  href='setting.php'><i class='fa fa-gear pull-right'></i> Settings</a>";
			}
			
			
					 
		}
       
    }
} else {
    
}
$conn->close();
?> 
					  
                    
                    <a class="dropdown-item"  href="login.php"><i class="fa fa-sign-out pull-right"></i> Log Out</a>
                  </div>
                </li>

              </ul>
            </nav>
          </div>
        </div>
       <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
			  
			  <form method="post">
                
              <div class="col-md-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Accounts Summary</h2>
                    <div class="filter">
						  
                      <div id="reportrange" class="pull-right" style="background: #fff; cursor: pointer; padding: 5px 10px; border: 1px solid #ccc">
                        <i class="fa fa-calendar">&nbsp;&nbsp;</i>
                        <span>January 05, 2020 - January 01, 2026</span> <b class="caret"></b>
                      </div>
						
                    </div>
                    <div class="clearfix"></div>
					  
                  </div><input type="hidden" name="date_R" id="SDate"/><input type="hidden" name="date_E" id="EDate"/>
					<center><input style="width: 120px;height:50px;" onclick="cbs()" type="submit" value="Show Record" class="btn btn-app" ></center>
                </div>
				  
              </div>
            
</form>

            <div class="clearfix"></div>
			  <div class="row">
    		  
			  
			 		  
           
             
                     <?php 
					        include_once 'con_file.php';
			  $conn;
                         $newDate="";
				         $newDateE="";
				  		 $S_Day="";
				  		 $E_Day="";
							$conn = new mysqli($servername, $username, $password, $dbname);

							if ($conn->connect_error) {
    						die("Connection failed: " . $conn->connect_error);
							} 
						  
					  
		              
				    if(isset($_POST['date_R'])){
					  $origDate = $_POST["date_R"];
						   $newDate = date("Y-m-d", strtotime($origDate));
						$S_Day = substr($newDate, 0, -6);
						
						 
				  		 
						$origDateE = $_POST["date_E"];
						   $newDateE = date("Y-m-d", strtotime($origDateE));
$E_Day = substr($newDateE, 0, -6);
						$dd=$newDate.", ".$newDateE;
						// echo "<script type='text/javascript'>alert('$dd');</script>";
				  }
				  else{
					   
						   $newDate = date("Y-m-d");
				  }
					 
						
 

					  $Profit=0;
					  $sale=0;
					  $purchase=0;
					  $Payable=0;
					  $receavable=0;
				  	  $expense=0;
				  	  $material=0;
				      $tax=0;
				      $sale_exp=0;
				  	  $purchase_exp=0;
                $paid=0;
				  
				  
		 		                           
	 $sql = "SELECT * FROM sale_client WHERE date between '".$newDate."' And '".$newDateE."' AND C_Name='".$client_name."'"; 
		 
		
$result = $conn->query($sql);
		  if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {

		$Profit=$Profit+$row["profit"];
      $paid=$paid+$row["Paid"];
$sale=$sale+$row["total"];
$receavable=$receavable+$row["C_Due"];
$tax=$tax+$row["tax"];
		 
		//$T_Customers+=$row["SUM(name)"];
    
	}
}
				  

 
				  
 
?>
			  

              
            </div>
			 <div class="clearfix"></div>
			   
				   					<div class="col-md-12 col-sm-12 ">
              <div class="x_panel tile">
                <div>
					<h2>Summary of the Date: <?php
						if ($newDate==$newDateE||$newDateE==""){
						echo date("d-m-Y", strtotime($newDate));
					 
					}else{
							 
                           
			  
						}?></h2>
                </div>
			  </div>
            </div>
	 
	<div class="clearfix"></div>
			  
				   	<div class="col-md-12 col-sm-4 ">
              <div class="x_panel tile">
                <div class="x_title">
             <h2>Trial Balance Report</h2><br><br>
                  
                 
                </div>
				  
				  
                <div class="x_content">
                  <h4>Date: <?php
						if ($newDate==$newDateE||$newDateE==""){
						echo date("d-m-Y", strtotime($newDate));
					 
					}else{
							echo date("d-m-Y", strtotime($newDate))." To ".date("d-m-Y", strtotime($newDateE)); 
						}?></h4><br>
					<table style="width:100%;border-style:solid;">
					<tr>
						<th style="border-bottom-style:solid;width:70%;padding:5px;">Title</th>
						<th colspan="2" style="border-bottom-style:solid;padding:5px;">Amount</th>
						 
						</tr>
						
						 
							<?php
						$credit=0;
						$debit=0;
						$credit+=$sale;
				 
					 
						$debit+=$receavable;
					 
						
			 
					
   echo "<tr><td style='padding:5px;'>Total Sale</td>";
				echo "<td style='padding:5px;'>Rs. ".$sale."</td>";
					echo "<td  style='padding:5px;'></td></tr>";
						
					 
						
						echo "<tr><td style='padding:5px;'>Due Amount</td>";
				echo "<td style='padding:5px;'>Rs. ".$receavable."</td>";
					echo "<td  style='padding:5px;'></td></tr>";
                      
                      	echo "<tr><td style='padding:5px;'>Paid Amount</td>";
				echo "<td style='padding:5px;'>Rs. ".$paid."</td>";
					echo "<td  style='padding:5px;'></td></tr>";
						
					 
					
						
						echo "<tr><td style='padding:5px;border-top-style:solid'>Total</td>";
				echo "<td style='padding:5px;border-top-style:solid'>Rs. ".$debit."</td>";
					echo "<td  style='padding:5px;border-top-style:solid'>Rs. ".$credit."</td></tr>";
						
						?>
					 
					 
						
					
					</table>
                 

                </div>
              </div>
            </div>
			 
				   
	   
			 
 
              <div class="col-md-12 col-sm-12 ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Sale Report</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                      <div class="row">
                          <div class="col-sm-12">
                            <div class="card-box table-responsive">
                    
					
                    <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                           <tr>
                          <th>Invoice No</th>
                          <th >Invoice Date</th>
                          <th>Order</th>
							<th style="width: 29%">Order Details</th>
							<th>Price</th>
                          <th>Order Quantity</th>
							   <th>Order By</th>
                        </tr>
                        
                      </thead>
                      <tbody>
                      <?php
						  
						 
 


						  
							
						  
$sql1="SELECT invoiceNo, Name, detail, Price, P_Qty, P_Date, seller from sale_item WHERE P_Date between '".$newDate."' And '".$newDateE."'"; 
						 
						  
$result = $conn->query($sql1);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		
		echo "<tr><td>" . $row["invoiceNo"]. "</td>";
		echo "<td>" . $row["P_Date"]. "</td>";
		echo "<td>" . $row["Name"]. "</td>";	
		echo "<td>" . $row["detail"]. "</td>";	
		echo "<td>" . $row["Price"]. "</td>";	
		echo "<td>" . $row["P_Qty"]. "</td>";
		echo "<td>" . $row["seller"]. "</td></tr>";
		 
		
		 

		  }
} else {
    
     echo "<tr><td colspan='7'>List is Empty</td>";
}
						  
   
						?>
                      
                      </tbody>
                    </table>
					
					
                  </div>
                </div>
              </div>
            </div>
                </div>
              </div>
			    
	
			 
			  <div class="clearfix"></div> 
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
       <footer>
          <div class="pull-right">
             <a href="https://centromonics.com">Centromonics - Point of Sale</a>
          </div>
          <div class="clearfix"></div>
        </footer>
         <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
   <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    
    <!-- iCheck -->
    <script src="../vendors/iCheck/icheck.min.js"></script>
    <!-- Datatables -->
    <script src="../vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="../vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="../vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="../vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
    <script src="../vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
    <script src="../vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="../vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
    <script src="../vendors/datatables.net-scroller/js/dataTables.scroller.min.js"></script>
    <script src="../vendors/jszip/dist/jszip.min.js"></script>
    <script src="../vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="../vendors/pdfmake/build/vfs_fonts.js"></script>
	  
	   <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
   <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- iCheck -->
    <script src="../vendors/iCheck/icheck.min.js"></script>
    <!-- Datatables -->
    <script src="../vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="../vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="../vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="../vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
    <script src="../vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
    <script src="../vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="../vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
    <script src="../vendors/datatables.net-scroller/js/dataTables.scroller.min.js"></script>
    <script src="../vendors/jszip/dist/jszip.min.js"></script>
    <script src="../vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="../vendors/pdfmake/build/vfs_fonts.js"></script>

    <!-- Custom Theme Scripts -->
	  
	  
	   <script src="../vendors/nprogress/nprogress.js"></script>
	  <script src="../vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
	  
	   <script src="../vendors/moment/min/moment.min.js"></script>
    <script src="../vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
	  

    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>

  </body>
</html>