<?php
$stu_id = $_POST['c_id'];
$stu_name = $_POST['c_name'];
$stu_address = $_POST['c_address'];
$stu_phone = $_POST['c_phone'];
$stu_email = $_POST['c_email'];

   include_once 'con_file.php';
			  $conn;

$sql = "UPDATE tblcustomer SET customer_name = '{$stu_name}', customer_address = '{$stu_address}', customer_contact = '{$stu_phone}', customer_email = '{$stu_email}' WHERE customer_id = {$stu_id}";
 
$result = mysqli_query($conn, $sql) or die("Query Unsuccessful.");
 

header("Location: CustomerView.php");

mysqli_close($conn);

?>
