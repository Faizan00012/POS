
<?php
 include_once 'con_file.php';
    if(isset($_POST['submit'])){
        $Supplier_id=$_POST['supplier_id'];
        $Supplier_name=$_POST['_name'];
        $user_name=$_POST['user_name'];
        $purchase_invoice=0;
        $cart_product_id=$_POST['cart_product_id'];
        $cart_barcode=$_POST['cart_barcode'];
        $cart_product=$_POST['cart_product'];
        $cart_detail=$_POST['cart_detail'];
        $cart_qty=$_POST['cart_qty'];
        $cart_unit_price=$_POST['cart_unit_price'];
        $cart_sale_price=$_POST['cart_sale_price'];
        $cart_discount=$_POST['cart_discount'];
        $cart_sub_total=$_POST['cart_sub_total'];
        $discount_amount=$_POST['discount_amount'];
        $total_amount=$_POST['total_amount'];
        $discount_amount=$_POST['discount_amount'];
        $paid_amount=$_POST['paid_amount'];
        $Remain_Amount=$_POST['Remain_Amount'];
        $cart_product_id=explode(",",$cart_product_id[0]);
        $cart_barcode=explode(",",$cart_barcode[0]);
        $cart_product=explode(",",$cart_product[0]);
        $cart_detail=explode(",",$cart_detail[0]);
        $cart_qty=explode(",",$cart_qty[0]);
        $cart_unit_price=explode(",",$cart_unit_price[0]);
        $cart_sale_price=explode(",",$cart_sale_price[0]);
        $cart_discount=explode(",",$cart_discount[0]);
        $cart_sub_total=explode(",",$cart_sub_total[0]);
  
							
        $sql = "INSERT INTO tblpurchaseorder (supplier_id, total_amount,discount, paid_amount, due_amount, order_date, user_id)
        VALUES ('".$Supplier_id."','".$total_amount."','".$discount_amount."','".$paid_amount."','".$Remain_Amount."','".date("Y-m-d")."', '".$user_name."' )";

        if ($conn->query($sql) === TRUE) {
        } 
        else {
        echo "Error: " . $sql . "<br>" . $conn->error;    
        }
          $sql = "INSERT INTO payments (amount , Type, customer_id, supplier_id, party)
        VALUES ('".$paid_amount."','Purchase','0','".$Supplier_id."','Supplier' )";
   
        if ($conn->query($sql) === TRUE) {
        } 
        else {
          
        }
        $sql = "SELECT purchase_order_id FROM tblpurchaseorder ORDER BY purchase_order_id";
        
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {
                $purchase_invoice=(int)$row["purchase_order_id"];
           
            }
        } else {
             
        }
           
         $sql = "INSERT INTO supplier_accounts (supplier_id, purchase_order_id, title, amount, due, paid, acc_date)
        VALUES ('".$Supplier_id."', '".$purchase_invoice."','Purchase on purchase_order: ".$purchase_invoice."', '".$total_amount."', '".$Remain_Amount."', '".$paid_amount."', '".date("Y-m-d")."' )";
   
 
        if ($conn->query($sql) === TRUE) {
        } 
        else {
          
        }
        for ($i=0;$i<count($cart_qty);$i++){

        $sql = "INSERT INTO tblpruchase (product_id, quantity, unit_price, discount, sub_total, purchase_order_id)
     VALUES ('".$cart_product_id[$i]."','".$cart_qty[$i]."','".$cart_unit_price[$i]."','".$cart_discount[$i]*$cart_qty[$i]."','".$cart_sub_total[$i]."','".$purchase_invoice."' )";

        if ($conn->query($sql) === TRUE) {
        } 
        else {
        echo "Error: " . $sql . "<br>" . $conn->error;    
        }
            
        $sql = "UPDATE tblproduct SET unit_in_stock= unit_in_stock+'".$cart_qty[$i]."' WHERE product_id='".$cart_product_id[$i]."'";

            if ($conn->query($sql) === TRUE) {
        
        } else {
    echo "Error updating record: " . $conn->error;
        }    
            
            
            
        } 
  header("location: Purchase.php");
                       
    }
                       
?>
 