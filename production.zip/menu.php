<div class="navbar nav_title" style="border: 0;">
              <a href="dashboard.php" class="site_title"><i class="fa fa-laptop"></i> <span>CPOS</span></a>
            </div>

            <div class="clearfix"></div>

             

            <br /> 
<div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
 <div class="menu_section">    
 <h3>General</h3>     
 <ul class="nav side-menu">
 <li><a href="dashboard.php"><i class="fa fa-home"></i> Home </a></li>
<li><a href="Sale.php"><i class="fa fa-shopping-cart"></i> Sale </a></li>
   
<li><a href="Purchase.php"><i class="fa fa-money"></i> Purchase</a></li>
   
 <li><a><i class="fa fa-dollar"></i> Payments <span class="fa fa-chevron-down"></span></a>
 <ul class="nav child_menu">
 <li><a href="paymentin.php">Payment In</a></li>
     <li><a href="paymentout.php">Payment Out</a></li>
        <li><a href="payment_record.php">Payment Record</a></li>
 
 </ul>
 </li>   
  
 <li><a><i class="fa fa-users"></i> Customers <span class="fa fa-chevron-down"></span></a>
 <ul class="nav child_menu">
 <li><a href="customer.php">Add Customer</a></li>                 
 <li><a href="CustomerView.php">Customer Record</a></li>
 </ul></li>
 <li><a><i class="fa fa-user"></i> Suppliers <span class="fa fa-chevron-down"></span></a>
 <ul class="nav child_menu">
 <li><a href="supplier.php">Add Supplier</a></li>                      
 <li><a href="supplierview.php">Supplier Record</a></li>
 </ul></li>

 <li><a><i class="fa fa-cubes"></i> Stock <span class="fa fa-chevron-down"></span></a>
 <ul class="nav child_menu">
 <li><a href="additem.php">Add Product</a></li>
     <li><a href="items.php">Product List</a></li>
 
 
 <li><a href="P_items.php">Purchase Stock</a></li>
 <li><a href="S_items.php">Sale Stock</a></li>
 </ul>
 </li>
 <li><a><i class="fa fa-line-chart"></i> Expense <span class="fa fa-chevron-down"></span></a>
 <ul class="nav child_menu">
 <li><a href="expense.php">Add Expense</a></li>
 <li><a href="expenseView.php">Expense Record</a></li>
 </ul>
 </li>
 <li><a><i class="fa fa-pie-chart"></i> Payroll <span class="fa fa-chevron-down"></span></a>
 <ul class="nav child_menu">
 <li><a href="staff.php">Add Staff</a></li>
 <li><a href="staffview.php">Staff Record</a></li>
 <li><a href="attendance.php">Staff Attendance</a></li>
 <li><a href="attend_reports.php">Attendance Record</a></li>
 <li><a href="updatestaff.php">Remove Staff</a></li>
 <li><a href="staffexpense.php">Staff Expense</a></li>
 <li><a href="staffexpenseview.php">Staff Expense Details</a></li>
 </ul>
 </li>
 <li><a><i class="fa fa-bar-chart"></i> Accounts <span class="fa fa-chevron-down"></span></a>
 <ul class="nav child_menu">
 <li><a>Due<span class="fa fa-chevron-down"></span></a>
 <ul class="nav child_menu">
 <li><a href="Receavable.php">Receivable</a>
 </li>
 <li><a href="payable.php">Payable</a>
 </li>
 </ul>
 </li>
  
 <li><a href="profit_analysis.php">Profit Analysis</a></li>                      
 <li><a href="Reports.php">Reports</a></li>
 </ul>
 </li>
 
       <li><a href="invoice_cus.php"><i class="fa fa-newspaper-o"></i> Customer Invoice </a></li>

 </div>
 </div>