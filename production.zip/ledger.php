<?php
 session_start();
 
if(empty($_SESSION['username']) || $_SESSION['username'] == ''){
    header("Location: login.php");
    die();
	
	
	
}
?><!DOCTYPE html>
<html lang="en">
  <head>
	  <style>
		  td{padding: 10px;color: black;font-size: 14px;}
		   th{padding: 10px;color: black;font-size: 14px;}
	  </style>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	  
    <title>Ledger | C-POS</title>

    <!-- Bootstrap -->
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- bootstrap-wysiwyg -->
    <link href="../vendors/google-code-prettify/bin/prettify.min.css" rel="stylesheet">
    <!-- Select2 -->
    <link href="../vendors/select2/dist/css/select2.min.css" rel="stylesheet">
    <!-- Switchery -->
    <link href="../vendors/switchery/dist/switchery.min.css" rel="stylesheet">
    <!-- starrr -->
    <link href="../vendors/starrr/dist/starrr.css" rel="stylesheet">
    <!-- bootstrap-daterangepicker -->
    <link href="../vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
          <?php include_once 'menu.php';?>   
            <!-- /menu footer buttons -->
            <div class="sidebar-footer hidden-small">
              <a data-toggle="tooltip" data-placement="top" title="Settings">
                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="FullScreen">
                <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Lock">
                <span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Logout" href="login.php">
                <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
              </a>
            </div>
            <!-- /menu footer buttons -->
          </div>
        </div>

        <!-- top navigation -->
    
       <!-- /top navigation -->
			<?php  include_once 'con_file.php';
			  $conn;
                         
							$conn = new mysqli($servername, $username, $password, $dbname);

		  ?>
        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Ledger Accounts </h2>
                
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />
                    <?php
					 
	$name="";
	$contact="";
	$address=""; 
    $total_bal=0;
	$inoviceNo=array();
	$Date=array();
   	$Amount=array();
	$Paid=array();
	$Due=array();
	$l_total=0;
	$debit=0;
	$credit=0;
					$l_receavable=0;
					$l_payable=0;
					  
					  	$exp=array();
					  $seller=array();
					  $count=0;
 
	$category="";
			  
	$sql = "SELECT name, cat FROM ledger_user";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $name=$row["name"];
		$category=$row["cat"];
    }
} else {
    echo "0 results";
}
					  
	$sql = "SELECT address, email, contact, inoviceNo, Date, Amount, Paid, Due, S_Account, exp, seller FROM ".$category." WHERE name='".$name."'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
     
		$contact=$row["contact"];
	    $address=$row["address"];
		
	   $inoviceNo[$count]=$row["inoviceNo"];
	   $Date[$count]=$row["Date"];
   	   $Amount[$count]=$row["Amount"];
	   $Paid[$count]=$row["Paid"];
	   $Due[$count]=$row["Due"];
	    $exp[$count]=$row["exp"];
		$seller[$count]=$row["seller"];
		 
		$count=$count+1;
		
    }
} else {
    echo "0 results";
}				  
		
					  
// sql to delete a record
$sql = "DELETE FROM ledger_user";

if ($conn->query($sql) === TRUE) {} else {}
					  
					  
					  ?>
				 
					  	<h2 style="text-align:center">Naseeb Shopping Mall</h2>
					  <h4 style="text-align:center">G.T Road, Kamra Cantt.</h4>
                      
					  <b style="font-size:16px; color:black">Name: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $name." (".$category.")"; ?></b><br>
					  <b style="font-size:16px;color:black">Contact: &nbsp;&nbsp;&nbsp;<?php echo $contact; ?></b><br>
					  <b style="font-size:16px;color:black">Address: &nbsp;&nbsp;<?php echo $address; ?></b><br>
					  <br><br>
					  <center><table border="1">
					  <tr>
						  <th style="width:5%;background-color: #5e87ff;color:white">S-No</th>
						  <th style="width:20%;background-color: #5e87ff;color:white">Date</th>
						  <th style="width:30%;background-color: #5e87ff;color:white">Particulars</th>
						  <th style="width:8%;background-color: #5e87ff;color:white">Debit</th>
                          <th style="width:8%;background-color: #5e87ff;color:white">Credit</th>
						  <th style="width:10%;background-color: #5e87ff;color:white">Balance</th>
						  </tr>
					   
					  <?php
						  $s_no=0;
						  if ($category=="customer"){						  
						  
							  
							  for ($i=0;$i<$count;$i++){ 
						   $l_total=0;
								  $l_total=$Amount[$i]; 
						  ?>
						      
						     
						     <tr><td style="background-color: lightyellow;"><?php  $s_no=$s_no+1;
						       echo $s_no; ?></td>
							  <td style="background-color: lightyellow;"><?php echo $Date[$i]; ?></td>
							  <td style="background-color: lightyellow;"><?php echo "Invoice # ".$inoviceNo[$i]; ?></td>
							  <td style="background-color: lightyellow;"><?php echo $Amount[$i]+$exp[$i]; ?></td>
								<?php $debit=$debit+$Amount[$i]+$exp[$i]; ?>
							  <td style="background-color: lightyellow;"></td>
							  <td style="background-color: lightyellow;"><?php echo $l_total=$l_total+$exp[$i]; ?></td> </tr>
							  
						  	  
						  
						     
						  
						  
						    <tr><td><?php $s_no=$s_no+1;
						       echo $s_no; ?></td>
							  <td><?php echo $Date[$i]; ?></td>
								 <?php $credit=$credit+$exp[$i]; ?>
							 
							  <td><?php echo "Expenses "; ?></td>
								<td></td>  
							  <td><?php echo $exp[$i]; ?></td>
								 
							  <td><?php $l_total=$l_total-$exp[$i]; 
						    		echo $l_total; ?></td></tr>
						  
						  <tr><td><?php  $s_no=$s_no+1;
						       echo $s_no; ?></td>
							  <td><?php echo $Date[$i]; ?></td>
							  <?php $credit=$credit+$Paid[$i]; ?>
							 
							  <td><?php echo "Received Cash To ".$seller[$i]; ?></td>
							  <td></td>
							  <td style="background-color:white;"><?php echo $Paid[$i]; ?></td>
							  
							  <td><?php echo $l_total=$l_total-$Paid[$i];
								  $total_bal=$total_bal+$l_total;?></td></tr>
						   
						   
					  <?php }
						  
						  }
						  else{
						  
							  
							  for ($i=0;$i<$count;$i++){ 
						   $l_total=0;
								  $l_total=$Amount[$i]; 
						  ?>
						      
						     
						     <tr><td style="background-color: lightyellow;"><?php  $s_no=$s_no+1;
						       echo $s_no; ?></td>
							  <td style="background-color: lightyellow;"><?php echo $Date[$i]; ?></td>
							  <td style="background-color: lightyellow;"><?php echo "Invoice # ".$inoviceNo[$i]; ?></td>
							  <td style="background-color: lightyellow;"><?php echo $Amount[$i]+$exp[$i]; ?></td>
								<?php $debit=$debit+$Amount[$i]+$exp[$i]; ?>
							  <td style="background-color: lightyellow;"></td>
							  <td style="background-color: lightyellow;"><?php echo $l_total=$l_total+$exp[$i]; ?></td> </tr>
							  
						  	  
						  
						     
						  
						  
						    <tr><td><?php $s_no=$s_no+1;
						       echo $s_no; ?></td>
							  <td><?php echo $Date[$i]; ?></td>
								 <?php $credit=$credit+$exp[$i]; ?>
							 
							  <td><?php echo "Expenses "; ?></td>
								<td></td>  
							  <td><?php echo $exp[$i]; ?></td>
								 
							  <td><?php $l_total=$l_total-$exp[$i]; 
						    		echo $l_total; ?></td></tr>
						  
						  <tr><td><?php  $s_no=$s_no+1;
						       echo $s_no; ?></td>
							  <td><?php echo $Date[$i]; ?></td>
							  <?php $credit=$credit+$Paid[$i]; ?>
							 
							  <td><?php echo "Cash Paid By ".$seller[$i]; ?></td>
							  <td></td>
							  <td style="background-color:white;"><?php echo $Paid[$i]; ?></td>
							  
							  <td><?php echo $l_total=$l_total-$Paid[$i];
								  $total_bal=$total_bal+$l_total;?></td></tr>
						   
						   
					  <?php }
						  
						  }
						  
						  ?>
						  
						   <tr><td style="font-size:14px;" rowspan="2" colspan="3"><b></b></td>
							 
							  <td  style="font-size:14px;background-color: #5e87ff;color:white"><b>Total Debit</b></td>
							  <td style="font-size:14px;background-color: #5e87ff;color:white"><b>Total Credit</b></td>
							  <td style="font-size:14px;background-color: #5e87ff;color:white"><b>Total Balance</b></td>
							   
							   </tr>
						  <tr>
							 
							  <td  style="font-size:14px;"><b><?php echo $debit; ?></b></td>
							  <td style="font-size:14px;"><b><?php echo $credit; ?></b></td>
							  <td style="font-size:14px;"><b><?php echo $total_bal; ?></b></td>
							   
							   </tr>
						 
						 </table></center>
                      
                 
                     

                     
                  </div>
                </div>
              </div>
            </div>
   
       	 
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <footer>
          <div class="pull-right">
             <h6>Developed By Centromonics</h6>
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
   <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- bootstrap-progressbar -->
    <script src="../vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <!-- iCheck -->
    <script src="../vendors/iCheck/icheck.min.js"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="../vendors/moment/min/moment.min.js"></script>
    <script src="../vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
    <!-- bootstrap-wysiwyg -->
    <script src="../vendors/bootstrap-wysiwyg/js/bootstrap-wysiwyg.min.js"></script>
    <script src="../vendors/jquery.hotkeys/jquery.hotkeys.js"></script>
    <script src="../vendors/google-code-prettify/src/prettify.js"></script>
    <!-- jQuery Tags Input -->
    <script src="../vendors/jquery.tagsinput/src/jquery.tagsinput.js"></script>
    <!-- Switchery -->
    <script src="../vendors/switchery/dist/switchery.min.js"></script>
    <!-- Select2 -->
    <script src="../vendors/select2/dist/js/select2.full.min.js"></script>
    <!-- Parsley -->
    <script src="../vendors/parsleyjs/dist/parsley.min.js"></script>
    <!-- Autosize -->
    <script src="../vendors/autosize/dist/autosize.min.js"></script>
    <!-- jQuery autocomplete -->
    <script src="../vendors/devbridge-autocomplete/dist/jquery.autocomplete.min.js"></script>
    <!-- starrr -->
    <script src="../vendors/starrr/dist/starrr.js"></script>
    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>
	
  </body>
</html>


 


 