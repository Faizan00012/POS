<?php
header("Expires: Thu, 19 Nov 1981 08:52:00 GMT"); //Date in the past
header("Cache-Control: no-store, no-cache, must-revalidate"); //HTTP/1.1
?>
<?php
 session_start();
 
if(empty($_SESSION['username']) || $_SESSION['username'] == ''){
    header("Location: login.php");
    die();
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
	 
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Payable - POS </title>

    <!-- Bootstrap -->
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
  </head>

   
       <body class="nav-md">
    <div class="container body">
      <div class="main_container">
          <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
           <?php include_once 'menu.php';?>       <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
            <div class="sidebar-footer hidden-small">
              <a data-toggle="tooltip" data-placement="top" title="Settings">
                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="FullScreen">
                <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Lock">
                <span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Logout" href="login.php">
                <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
              </a>
            </div>
            <!-- /menu footer buttons -->
          </div>
        </div>

        <!-- top navigation -->
         <div class="top_nav">
          <div class="nav_menu">
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>
              <nav class="nav navbar-nav">
              <ul class=" navbar-right">
                <li class="nav-item dropdown open" style="padding-left: 15px;">
                  <a href="javascript:;" class="user-profile dropdown-toggle" aria-haspopup="true" id="navbarDropdown" data-toggle="dropdown" aria-expanded="false">
                    <?php echo $_SESSION["username"]; ?>
                  </a>
                  <div class="dropdown-menu dropdown-usermenu pull-right" aria-labelledby="navbarDropdown">
					  <?php
					  include_once 'con_file.php';
			  $conn;

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
					  $sql = "SELECT username, access FROM users";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		if ($_SESSION["username"]==$row["username"])
		{
			
			$access=$row["access"];
			if ($access=="admin"){
				echo "<a class='dropdown-item'  href='setting.php'><i class='fa fa-gear pull-right'></i> Settings</a>";
			}
			
			
					 
		}
       
    }
} else {
    
}
$conn->close();
?> 
					  
                    
                    <a class="dropdown-item"  href="login.php"><i class="fa fa-sign-out pull-right"></i> Log Out</a>
                  </div>
                </li>

              </ul>
            </nav>
          </div>
        </div>
  
        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Payable Screen</h3>
				  
              </div>
					
           
            </div>

            <div class="clearfix"></div>
			  <?php
			 
			 include_once 'con_file.php';
			  $conn;
                         
							$conn = new mysqli($servername, $username, $password, $dbname);

							if ($conn->connect_error) {
    						die("Connection failed: " . $conn->connect_error);
							} 
			  $id=$_GET['id'];
			  $total=0;
			  $discount=0; 
			  $paid=0;
			  $due=0;
			  $data=explode("|",$id);
              
						$sql = "SELECT total_amount, paid_amount, due_amount FROM tblpurchaseorder where purchase_order_id='".$data[0]."'";
                   
              
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        
		$total=$row["total_amount"];
			   $paid=$row["paid_amount"];
			  $due=$row["due_amount"];
    }
} else {
  
}
			
          
        ?>

			  <form method="post" action="Payable_script.php">
            <div class="row">
              <div class="col-md-12 ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Purchase No: <?php echo $data[0]; ?></h2>
                    <ul class="nav navbar-right panel_toolbox">
                     
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />
                    

                      <div class="form-group row">
                        <label class="control-label col-md-3 col-sm-3 ">Net Amount</label>
                        <div class="col-md-9 col-sm-9 ">
                    
							<input type="text"  class="form-control"
								value ="<?php echo $total;?>" name="Total" readonly="readonly" >
                        </div>
                      </div>
                      <div class="form-group row">
                        <label class="control-label col-md-3 col-sm-3 ">Paid</label>
                        <div class="col-md-9 col-sm-9 ">
                         <input type="text" value ="<?php echo $paid;?>"  class="form-control" name="Paid" readonly="readonly" >
                        </div>
                      </div>
                  
					  <div class="form-group row">
                        <label class="col-form-label col-md-3 col-sm-3 ">Payable</label>
                        <div class="col-md-9 col-sm-9 ">
                          <input type="text" value ="<?php echo $due ;?>" id="Price" class="form-control"  name="Recevable" readonly="readonly" required>
                            <input type="hidden" value ="<?php echo $total ;?>"  name="Ntotal" >
                            <input type="hidden" value ="<?php echo $data[0] ;?>"  name="id" >
                             <input type="hidden" value ="<?php echo $data[1] ;?>"  name="customer_id" >
							 
                        </div>
                      </div>
                 
                      <div class="form-group row">
                        <label class="control-label col-md-3 col-sm-3 ">Amount</label>
                        <div class="col-md-9 col-sm-9 ">
                          <input type="number" onkeypress="" onchange="" class="form-control" value="<?php echo $due ;?>" id="amount" name="Amount" required>
                        </div>
                      </div>
                      
                           <script>
                              function amountcheck(){
                                   var due=document.getElementById("Price").value;
                                  var amount=document.getElementById("amount").value;
                                  if (amount>due){
                                      document.getElementById("amount").value=due;
                                  }
                               }
                      </script>
              

                      <div class="ln_solid"></div>
                       
							<div class="col-md-9 col-sm-9  offset-md-3">
						  <input type="submit" name="submit" class="btn btn-success">
                           
                         
                        </div>
                  
                  </div>
                </div>
              </div>

		 
      

          
            </div>
			  </form>
			
			 
			
        	  
          </div>
			  <div class="clearfix"></div>
        </div>
        <!-- /page content -->
		  

        <!-- footer content -->
       <footer>
          <div class="pull-right">
             <a href="https://centromonics.com">Centromonics - Point of Sale</a>
          </div>
          <div class="clearfix"></div>
        </footer>
         <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
   <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    
    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>
  </body>
</html>
