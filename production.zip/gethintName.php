<?php
include_once 'con_file.php';
			  $conn;
$data="";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * FROM tblcustomer";
$result = $conn->query($sql);

$data=$_REQUEST["q"];
$hint = "";

 
			//echo "<script type='text/javascript'>alert('$message');</script>";
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		if ($data==$row["customer_name"]){
			
		 	$hint.=$row["customer_address"]."|";
			$hint.=$row["customer_email"]."|";
			$hint.=$row["customer_contact"]."|";
            $hint.=$row["customer_id"]."|";
			 echo $hint;
		}
       
    }
} else {
    echo "0 results";
}
echo  $hint;
 
$conn->close();

?> 