  <?php
					$ItemName = array();
					$Itemdetail= array();
					$Qty = array();
					$price = array();
					$discount = array();			
					$count =0;
					$status ="";
								
						if(isset($_POST['submit'])){
							
					
						include_once 'con_file.php';
			  $conn;
                         
							$conn = new mysqli($servername, $username, $password, $dbname);
	
							if ($conn->connect_error) {
    						die("Connection failed: " . $conn->connect_error);
							} 
							
							if ($_POST["FName"]!=""){
								$status="true";
							}
							
							$sql = "INSERT INTO purchase (Item_Name, Unit_P,Purchase_P,detail, Discount,DC_Mode, Qty,mass, Purchase_Name,Purchase_Contact,Purchase_Email, Purchase_Address,curr ,Sub_Total,P_status)
							VALUES ('".$_POST["ItemName"]."', '".$_POST["UPrice"]."','".$_POST["SPrice"]."', '".$_POST["ItemDetails"]."', '".$_POST["Discount"]."','".$_POST['DC']."','".$_POST["Qty"]."','".$_POST["mass"]."','".$_POST["FName"]."','".$_POST["Phone"]."','".$_POST["Email"]."','".$_POST["Address"]."','".$_POST["exp"]."','".($_POST["UPrice"]-$_POST["Discount"])*$_POST["Qty"]."','".$status."')";
						 	 header("location: Purchase.php");
							 
							
							if ($conn->query($sql) === TRUE) {
							} else {
    						echo "Error: " . $sql . "<br>" . $conn->error;
							}
						   }
							 
						
							

							$conn->close();
								
						 
						?>