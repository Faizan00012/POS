<?php 
$id=$_GET["id"];
$arr = explode("-", $id);
$sale_id=$arr[0];
$invoice_id=$arr[1];
$product_id=$arr[2];




?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>CRUD</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div id="wrapper">
        <div id="header">
            <h1>Customer Return</h1>
        </div>
        <div id="menu">
            <ul>
                <li>
                    <a href="return.php?id=<?php echo $invoice_id; ?>">Back</a>
                </li>
                
            </ul>
        </div>


<div id="main-content">
   
    <?php
    include_once 'con_file.php';
			  $conn;

    $sc_id = $_GET['id'];

    $sql = "SELECT * FROM tblsale WHERE sale_id = {$sale_id} AND product_id = {$product_id}";
  
    $result = mysqli_query($conn, $sql) or die("Query Unsuccessful.");

    if(mysqli_num_rows($result) > 0)  {
      while($row = mysqli_fetch_assoc($result)){
    ?>
    <form class="post-form" action="updatedata_returncus.php" method="post">
      <div class="form-group">
          <label>Product Quantity</label> 
          <input type="hidden" name="old_quantity" value="<?php echo $row['quantity']; ?>"/>
            <input type="text" name="quantity" value="<?php echo $row['quantity']; ?>"/>
          <input type="hidden" name="sale_id" value="<?php echo $row['sale_id']; ?>"/>
           <input type="hidden" name="product_id" value="<?php echo $row['product_id']; ?>"/>
           <input type="hidden" name="invoice_id" value="<?php echo $row['invoice_id']; ?>"/>
           <input type="hidden" name="sale_price" value="<?php echo $row['sale_price']; ?>"/>
          <input type="hidden" name="sub_total" value="<?php echo $row['sub_total']; ?>"/>
        
      </div>
      
      <input class="submit" type="submit" value="Update"/>
    </form>
    <?php
      }
    }
    ?>
</div>
</div>
</body>
</html>
