<?php
						
	include_once 'con_file.php';
			  $conn;
                         
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection

$id=$_GET['id'];
// sql to delete a record
$sql = "DELETE FROM sale WHERE Sale_id={$id}";

if ($conn->query($sql) === TRUE) {
	 header("location: sale.php");
} else {
   header("location: sale.php");
}

$conn->close();
?> 