<?php
 session_start();
 
if(empty($_SESSION['username']) || $_SESSION['username'] == ''){
    header("Location: login.php");
    die();
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	  
    <title>Settings | C-POS </title>

    <!-- Bootstrap -->
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- bootstrap-wysiwyg -->
    <link href="../vendors/google-code-prettify/bin/prettify.min.css" rel="stylesheet">
    <!-- Select2 -->
    <link href="../vendors/select2/dist/css/select2.min.css" rel="stylesheet">
    <!-- Switchery -->
    <link href="../vendors/switchery/dist/switchery.min.css" rel="stylesheet">
    <!-- starrr -->
    <link href="../vendors/starrr/dist/starrr.css" rel="stylesheet">
    <!-- bootstrap-daterangepicker -->
    <link href="../vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
  </head>
  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
            <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            <div class="navbar nav_title" style="border: 0;">
              <a href="dashboard.php" class="site_title"><i class="fa fa-laptop"></i> <span>NASEEB MALL</span></a>
            </div>

            <div class="clearfix"></div>

            <!-- menu profile quick info -->
            
            <!-- /menu profile quick info -->

            <br />

            <!-- sidebar menu -->
    <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                <h3>Settings</h3>
                <ul class="nav side-menu">
                 <li><a href="setting.php"><i class="fa fa-dot-circle-o"></i>Home </a></li>
					<li><a href="setting_Database.php"><i class="fa fa-dot-circle-o"></i>Data Settings </a></li>	        <li><a href="setting_privilege.php"><i class="fa fa-dot-circle-o"></i>User Privilege </a></li>      
					<li><a><i class="fa fa-dot-circle-o"></i>Users <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
					  <li><a href="setting_AddUser.php">Add User</a></li>
					  <li><a href="setting_RemoveUser.php">Remove User</a></li>
						
                    </ul>
                  </li>
					
			 <li><a href="dashboard.php"><i class="fa fa-dot-circle-o"></i>DashBoard</a></li>

                   
                   
                   
       
                     
                 
				
				 
				  </ul>
              </div>
          
            </div>  
            <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
            <div class="sidebar-footer hidden-small">
              <a data-toggle="tooltip" data-placement="top" title="Settings">
                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="FullScreen">
                <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Lock">
                <span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Logout" href="login.php">
                <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
              </a>
            </div>
            <!-- /menu footer buttons -->
          </div>
        </div>

        <!-- top navigation -->
        <div class="top_nav">
          <div class="nav_menu">
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>
              <nav class="nav navbar-nav">
              <ul class=" navbar-right">
                <li class="nav-item dropdown open" style="padding-left: 15px;">
                  <a href="javascript:;" class="user-profile dropdown-toggle" aria-haspopup="true" id="navbarDropdown" data-toggle="dropdown" aria-expanded="false">
                    <?php echo $_SESSION["username"]; ?>
                  </a>
                  <div class="dropdown-menu dropdown-usermenu pull-right" aria-labelledby="navbarDropdown">
					  <?php
					  include_once 'con_file.php';
			  $conn;

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
					  $sql = "SELECT username, access FROM users";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		if ($_SESSION["username"]==$row["username"])
		{
			
			$access=$row["access"];
			if ($access=="admin"){
				echo "<a class='dropdown-item'  href='setting.php'><i class='fa fa-gear pull-right'></i> Settings</a>";
			}
			
			
					 
		}
       
    }
} else {
    
}
$conn->close();
?> 
					  
                    
                    <a class="dropdown-item"  href="login.php"><i class="fa fa-sign-out pull-right"></i> Log Out</a>
                  </div>
                </li>

              </ul>
            </nav>
          </div>
        </div>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
             
              </div>

            </div>

        
			  
			  <div class="clearfix"></div>

             <form method="post">
            <div class="row">
           

              <div class="col-md-12 ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>User Privilege</h2>
                     
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />
                    <table style="width:100%">
					  <tr>
						  <td>
							        <div class="form-group row">
                        <strong class="control-label col-md-3 col-sm-3 ">Customer</strong>
                        <div class="col-md-9 col-sm-9 ">
                           
                            <label>
                              <input type="checkbox" name="AddCustomer" class="js-switch" checked /> &nbsp;Add Customer
                            </label>
							<br>
							 <label>
                              <input type="checkbox" name="CustomerReport" class="js-switch" checked /> &nbsp;Customer Report
                            </label>
                        
                          
                        </div>
                      </div>
						  </td>
						  <td>
						     <div class="form-group row">
                        <strong class="control-label col-md-3 col-sm-3 ">Supplier</strong>
                        <div class="col-md-9 col-sm-9 ">
                           
                            <label>
                              <input type="checkbox" name="AddSupplier" class="js-switch" checked /> &nbsp;Add Supplier
                            </label>
							<br>
							 <label>
                              <input type="checkbox"  name="SupplierReport" class="js-switch" checked /> &nbsp;Supplier Report
                            </label>
                        
                          
                        </div>
                      </div>
						  </td>
						</tr>
						<tr>
						<td>
							 <div class="form-group row">
                        <strong class="control-label col-md-3 col-sm-3 ">Stock</strong>
                        <div class="col-md-9 col-sm-9 ">
                           
                            <label>
                              <input type="checkbox" name="Items" class="js-switch" checked /> &nbsp;Items
                            </label>
							<br>
							  <label>
                              <input type="checkbox" name="AddItems"  class="js-switch" checked /> &nbsp;Add Items
                            </label>
							<br>
							<label>
                              <input type="checkbox" name="UpdateItems"  class="js-switch" checked /> &nbsp;Update Items
                            </label>
							<br>
							<label>
                              <input type="checkbox" name="PurchaseStock"  class="js-switch" checked /> &nbsp;Purchase Stock
                            </label>
							<br>
							<label>
                              <input type="checkbox" name="SaleStock"  class="js-switch" checked /> &nbsp;Sale Stock
                            </label>
							<br>
                        
                          
                        </div>
                      </div>
							</td>
							<td>
							
							 <div class="form-group row">
                        <strong class="control-label col-md-3 col-sm-3 ">Accounts</strong>
                        <div class="col-md-9 col-sm-9 ">
                            <label>
                              <input type="checkbox" name="Due" class="js-switch" checked /> &nbsp;Due
                            </label>
							<br>
							 <label>
                              <input type="checkbox" name="Ledger" class="js-switch" checked /> &nbsp;Ledger
                            </label>
                        <br>
							 <label>
                              <input type="checkbox" name="PA" class="js-switch" checked /> &nbsp;Profit Analysis
                            </label>
							<br>
							 <label>
                              <input type="checkbox" name="Reports" class="js-switch" checked /> &nbsp;Reports
                            </label>
							<br><br>
                          
                        </div>
                      </div>
							</td>
						
						</tr>
						<tr>
						<td>
							 <div class="form-group row">
                        <strong class="control-label col-md-3 col-sm-3 ">Expense</strong>
                        <div class="col-md-9 col-sm-9 ">
                           
                            <label>
                              <input type="checkbox" name="AddExpense"  class="js-switch" checked /> &nbsp;Add Expense
                            </label>
							<br>
							  <label>
                              <input type="checkbox" name="ExpenseReport"  class="js-switch" checked /> &nbsp;Expense Report
                            </label>
							<br>
							 
                        </div>
                      </div>
							</td>
							<td>
							
							 <div class="form-group row">
                        <strong class="control-label col-md-3 col-sm-3 ">Invoice</strong>
                        <div class="col-md-9 col-sm-9 ">
                            <label>
                              <input type="checkbox" name="Invoice" class="js-switch" checked /> &nbsp;Invoice
                            </label>
							<br>
							  
                          
                        </div>
                      </div>
							</td>
						
						</tr>
						<tr>
						<td>
							 <div class="form-group row">
                        <strong class="control-label col-md-3 col-sm-3 ">PayRoll</strong>
                        <div class="col-md-9 col-sm-9 ">
                           
                            <label>
                              <input type="checkbox" name="AddStaff" class="js-switch" checked /> &nbsp;Add Staff
                            </label>
							<br>
							  <label>
                              <input type="checkbox" name="StaffRecord" class="js-switch" checked /> &nbsp;Staff Record
                            </label>
							<br>
							<label>
                              <input type="checkbox" name="StaffAttendance" class="js-switch" checked /> &nbsp;Staff Attendance
                            </label>
							<br>
							<label>
                              <input type="checkbox" name="AttendanceRecord" class="js-switch" checked /> &nbsp;Attendance Record
                            </label>
							<br>
							<label>
                              <input type="checkbox" name="RemoveStaff" class="js-switch" checked /> &nbsp;Remove Staff
                            </label>
							<br>
							<label>
                              <input type="checkbox" name="StaffExpense" class="js-switch" checked /> &nbsp;Staff Expense
                            </label>
							<br>
							<label>
                              <input type="checkbox" name="StaffExpenseDetails" class="js-switch" checked /> &nbsp;Staff Expense Details
                            </label>
							<br>
							 
                        </div>
                      </div>
							</td>
						 
						
						</tr>
	
					  </table>
                
                   
					  
        

					  
					  
                       
                      
                   

                      <div class="ln_solid"></div>
                       
							<div class="col-md-9 col-sm-9  offset-md-3">
						  <button type="submit" name="submit" class="btn btn-success">Update Privilege</button>
                        
                         
                        </div>
                  
                  </div>
                </div>
              </div>


          
            </div>
			  </form>
	
			  
			  
			<?php

if(isset($_POST['submit'])){
	$AddCustomer="";
	$CustomerReport="";
	$AddSupplier="";
	$SupplierReport="";
    $Items="";
	$AddItems="";
	$UpdateItems="";
	$PurchaseStock="";
	$SaleStock="";
	$Due="";
	$Ledger="";
	$PA="";
	$Reports="";
    $AddExpense="";
    $ExpenseReport="";
    $Invoice="";
    $AddStaff="";
    $StaffRecord="";
    $StaffAttendance="";
    $AttendanceRecord="";
    $RemoveStaff="";
    $StaffExpense="";
    $StaffExpenseDetails="";
	$bodyStr="";

		
	if (isset($_POST['AddCustomer'])) {

    $AddCustomer='<li><a href="customer.php">Add Customer</a></li>';
} 	
	if (isset($_POST['CustomerReport'])) {

    $CustomerReport='<li><a href="CustomerView.php">Customer Record</a></li>';
} 		
	if (isset($_POST['AddSupplier'])) {

                      
    $AddSupplier='<li><a href="supplier.php">Add Supplier</a></li>';
} 
	if (isset($_POST['SupplierReport'])) {

    $SupplierReport='<li><a href="supplierview.php">Supplier Record</a></li>';
} 
	if (isset($_POST['Items'])) {
	
    $Items='<li><a href="items.php">Items</a></li>';
} 
	if (isset($_POST['AddItems'])) {

    $AddItems='<li><a href="additem.php">Add Items</a></li>';
} 
	if (isset($_POST['UpdateItems'])) {

    $UpdateItems='<li><a href="changeItem.php">Update Items</a></li>';
} 
	if (isset($_POST['PurchaseStock'])) {

    $PurchaseStock='<li><a href="P_items.php">Purchase Stock</a></li>';
} 
	if (isset($_POST['SaleStock'])) {

    $SaleStock='<li><a href="S_items.php">Sale Stock</a></li>';
} 
	if (isset($_POST['Due'])) {
		$Due='<li><a>Due<span class="fa fa-chevron-down"></span></a>
                          <ul class="nav child_menu">
                            <li><a href="Receavable.php">Receivable</a>
                            </li>
                            <li><a href="payable.php">Payable</a>
                            </li>
                          </ul>
                        </li>';
} 
	if (isset($_POST['Ledger'])) {

    $Ledger='<li><a href="ledgershow.php">Ledger</a></li>';
	
} 
	if (isset($_POST['PA'])) {

    $PA='<li><a href="profit_analysis.php">Profit Analysis</a></li>';
} 
	if (isset($_POST['Reports'])) {

    $Reports='<li><a href="Reports.php">Reports</a></li>';
} 
	if (isset($_POST['AddExpense'])) {

                      
					 
    $AddExpense='<li><a href="expense.php">Add Expense</a></li>';
} 
	if (isset($_POST['ExpenseReport'])) {

    $ExpenseReport='<li><a href="expenseView.php">Expense Record</a></li>';
} 
	if (isset($_POST['Invoice'])) {

    $Invoice='<li><a href="invoiceShow.php"><i class="fa fa-newspaper-o"></i>Invoice Report</a></li>';
	
} 
	if (isset($_POST['AddStaff'])) {
		
    $AddStaff='<li><a href="staff.php">Add Staff</a></li>';
} 
	if (isset($_POST['StaffRecord'])) {
		 

    $StaffRecord='<li><a href="staffview.php">Staff Record</a></li>';
} 
	if (isset($_POST['StaffAttendance'])) {

    $StaffAttendance='<li><a href="attendance.php">Staff Attendance</a></li>';
} 
	if (isset($_POST['AttendanceRecord'])) {

    $AttendanceRecord='<li><a href="attend_reports.php">Attendance Record</a></li>';
} 
	if (isset($_POST['RemoveStaff'])) {

    $RemoveStaff='<li><a href="updatestaff.php">Remove Staff</a></li>';
} 
	if (isset($_POST['StaffExpense'])) {

    $StaffExpense='<li><a href="staffexpense.php">Staff Expense</a></li>';
} 
	if (isset($_POST['StaffExpenseDetails'])) {

    $StaffExpenseDetails='<li><a href="staffexpenseview.php">Staff Expense Details</a></li>';
} 
	
	
	$bodyStr='     <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                <h3>General</h3>
                <ul class="nav side-menu">
				<li><a href="dashboard.php"><i class="fa fa-home"></i> Home </a></li>
                
					 <li><a href="Sale.php"><i class="fa fa-shopping-cart"></i>Sale</a>  </li>
					
	              <li><a href="Purchase.php"><i class="fa fa-money"></i>Purchase</a></li>
					
                  
					 <li><a href="ReturnShow.php"><i class="fa fa-external-link-square"></i> Return</a></li>
				 
';
						              
					
					
	
	
	if (!isset($_POST['CustomerReport'])&&!isset($_POST['AddCustomer'])) {

     
	}
	else{
		$bodyStr=$bodyStr.'<li><a><i class="fa fa-users"></i> Customers <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">'.$AddCustomer.$CustomerReport.'</ul>
                  </li>';
		
	}
	if (!isset($_POST['SupplierReport'])&&!isset($_POST['AddSupplier'])) {

     
	}
	else{
		$bodyStr=$bodyStr.'<li><a><i class="fa fa-user"></i> Suppliers <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">'.$AddSupplier.$SupplierReport.'</ul></li>';
		
	}
	if (!isset($_POST['Items'])&&!isset($_POST['AddItems'])&&!isset($_POST['UpdateItems'])&&!isset($_POST['PurchaseStock'])&&!isset($_POST['SaleStock'])) {}
	else{
		$bodyStr=$bodyStr.'<li><a><i class="fa fa-cubes"></i> Stock <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">'.$Items.$AddItems.$UpdateItems.$PurchaseStock.$SaleStock.'</ul></li>';
	}
	if (!isset($_POST['AddExpense'])&&!isset($_POST['ExpenseReport'])) {}
	else{
		$bodyStr=$bodyStr.'<li><a><i class="fa fa-line-chart"></i> Expense <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">'.$AddExpense.$ExpenseReport.'</ul></li>';
	}
	if (!isset($_POST['AddStaff'])&&!isset($_POST['StaffRecord'])&&!isset($_POST['StaffAttendance'])&&!isset($_POST['AttendanceRecord'])&&!isset($_POST['RemoveStaff'])&&!isset($_POST['StaffExpense'])&&!isset($_POST['StaffExpenseDetails'])) {}
	else{
		$bodyStr=$bodyStr.'<li><a><i class="fa fa-pie-chart"></i> Payroll <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">'.$AddStaff.$StaffRecord.$StaffAttendance.$AttendanceRecord.$RemoveStaff.$StaffExpense.$StaffExpenseDetails.'</ul></li>';
	}
	
	if (!isset($_POST['Due'])&&!isset($_POST['Ledger'])&&!isset($_POST['PA'])&&!isset($_POST['Reports'])) {}
	else{
		$bodyStr=$bodyStr.'<li><a><i class="fa fa-bar-chart"></i> Accounts <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">'.$Due.$Ledger.$PA.$Reports.'</ul></li>';
	}
	if (isset($_POST['Invoice'])){
		$bodyStr=$bodyStr.$Invoice;
	}
	$bodyStr=$bodyStr.'
             
				  
				   
				                  
				  </ul>
              </div>
          
            </div>          
';
	
	
			  include_once 'con_file.php';
			  $conn;
			 							$conn = new mysqli($servername, $username, $password, $dbname);
	$sql = "UPDATE dashboard SET sidebar='".$bodyStr."' WHERE user='user'";

if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
} else {
     
}
 
	
	}
			
			 
			  
			  
			  ?>
						
			 <div class='clearfix'></div>
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <footer>
          <div class="pull-right">
             <a href="https://centromonics.com">Centromonics - Point of Sale</a>
          </div>
          <div class="clearfix"></div>
        </footer>
      <!-- /footer content -->
      </div>
    </div>

     <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
   <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- bootstrap-progressbar -->
    <script src="../vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <!-- iCheck -->
    <script src="../vendors/iCheck/icheck.min.js"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="../vendors/moment/min/moment.min.js"></script>
    <script src="../vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
    <!-- bootstrap-wysiwyg -->
    <script src="../vendors/bootstrap-wysiwyg/js/bootstrap-wysiwyg.min.js"></script>
    <script src="../vendors/jquery.hotkeys/jquery.hotkeys.js"></script>
    <script src="../vendors/google-code-prettify/src/prettify.js"></script>
    <!-- jQuery Tags Input -->
    <script src="../vendors/jquery.tagsinput/src/jquery.tagsinput.js"></script>
    <!-- Switchery -->
    <script src="../vendors/switchery/dist/switchery.min.js"></script>
    <!-- Select2 -->
    <script src="../vendors/select2/dist/js/select2.full.min.js"></script>
    <!-- Parsley -->
    <script src="../vendors/parsleyjs/dist/parsley.min.js"></script>
    <!-- Autosize -->
    <script src="../vendors/autosize/dist/autosize.min.js"></script>
    <!-- jQuery autocomplete -->
    <script src="../vendors/devbridge-autocomplete/dist/jquery.autocomplete.min.js"></script>
    <!-- starrr -->
    <script src="../vendors/starrr/dist/starrr.js"></script>
    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>
  </body>
</html>
