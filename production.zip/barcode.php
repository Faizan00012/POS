<html>
<head>
<style>
p.inline {display: inline-block;}
span { font-size: 13px;}
</style>
<style type="text/css" media="print">
    @page 
    {
        size: auto;   /* auto is the initial value */
        margin: 0mm;  /* this affects the margin in the printer settings */

    }
</style>
</head>
<body onload="window.print();">
	<div style="margin-left: 5%">
		<?php
		include 'barcode128.php';
		$product = $_POST['ItemName'];
		$product_id = $_POST['pid'];
		$rate = $_POST['SPrice'];
		include_once 'con_file.php';
	    $conn;
		$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$sql = "SELECT bar_id, item_id FROM items";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		if ($row["item_id"]==$product_id){
		
			if ($row["bar_id"]==""){
				$sql = "UPDATE items SET bar_id='".$product_id."' WHERE item_id='".$product_id."'";

if ($conn->query($sql) === TRUE) {
    
} else {
   
}

			
		}
			else{
				$product_id=$row["bar_id"];
			}
			
		}
		
        
    }
} else {
    echo "0 results";
}
		
		
		

		for($i=1;$i<=$_POST['qty'];$i++){
			echo "<p class='inline'><span ><b>Item: $product</b></span>".bar128(stripcslashes($product_id))."<span ><b><br>Price: ".$rate." </b><span></p>&nbsp&nbsp&nbsp&nbsp";
		}
		
		

$conn->close();
?> 

		 
	</div>
</body>
</html>