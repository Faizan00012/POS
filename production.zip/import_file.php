
<?php
if(isset($_POST["submit_file"]))
{
 $firstline = true;
 $file = $_FILES["file"]["tmp_name"];
 $file_open = fopen($file,"r");
    $index=0;
 while(($csv = fgetcsv($file_open, 1000, ",")) !== false)
 {
  $produce_code = $csv[0];
  $product_name = $csv[1];
  $product_detail = $csv[2];
  $unit_in_stock = $csv[3];
  $unit_price = $csv[4];
  $sale_price = $csv[5];
  include_once 'con_file.php';
  $conn;
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
if (!$firstline) {     
$sql = "INSERT INTO tblproduct ( produce_code, product_name, product_detail, unit_in_stock, unit_price, sale_price) VALUES ('".$produce_code."', '".$product_name."', '".$product_detail."', '".$unit_in_stock."' ,'".$unit_price."', '".$sale_price."')";
echo $sql;
if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
}
      $firstline = false;
     
 header('location: additem.php');
 }
}
?>
