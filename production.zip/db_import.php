<?php

$connection = mysqli_connect("localhost","root","","faizan_db") or   die("Connection failed: " . mysqli_connect_error());
$filename = 'backup.sql';
$handle = fopen($filename,"r+");
$contents = fread($handle,filesize($filename));
$sql = explode(';',$contents);
foreach($sql as $query){
  $result = mysqli_query($connection,$query);
  if($result){
     // echo '<tr><td><br></td></tr>';
     // echo '<tr><td>'.$query.' <b>SUCCESS</b></td></tr>';
     // echo '<tr><td><br></td></tr>';
  }
}
fclose($handle);
//header("location: setting.php");
?>