<?php
						
include_once 'con_file.php';
			  $conn;
                         
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection

$id=$_GET['id'];
// sql to delete a record
$sql = "DELETE FROM Purchase WHERE Purchase_id={$id}";

if ($conn->query($sql) === TRUE) {
	 header("location: Purchase.php");
} else {
   header("location: Purchase.php");
}

$conn->close();
?> 