	<?php
			  include_once 'con_file.php';
			  $conn;
                         
			 if(isset($_POST['submit'])){
			     $N_Paid=$_POST["Amount"];
                 $paid=$_POST["Paid"];
                 $total=$_POST["Ntotal"];
                 $id=$_POST["id"];
                 $c_id=$_POST["customer_id"];
                 $N_due=$total-($paid+$N_Paid);
                 $total_paid=$total-($paid);
		     $sql = "UPDATE tblpurchaseorder SET paid_amount=paid_amount+'".$N_Paid."', due_amount='".$N_due."' WHERE purchase_order_id='".$id."'";
                echo $sql;
                if ($conn->query($sql) === TRUE) {
   
                 }
                 $sql = "INSERT INTO payments (amount , Type, customer_id, supplier_id, party)
        VALUES ('".$N_Paid."','Payable','0','".$c_id."','Supplier' )";
   
        if ($conn->query($sql) === TRUE) {
        } 
        else {
          
        }
                $sql = "INSERT INTO supplier_accounts (supplier_id, purchase_order_id,title, amount, paid, due, acc_date)
        VALUES ('".$c_id."', '".$id."','Due Amount of invoice: ".$id."','".$total_paid."', '".$N_Paid."', '".$N_due."', '".date("Y-m-d")."' )";
     
 
        if ($conn->query($sql) === TRUE) {
        } 
        else {
          
        } 
          
				  header("Location: payable.php");
					 
				 }
			  ?>