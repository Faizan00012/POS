<?php
 session_start();
 
if(empty($_SESSION['username']) || $_SESSION['username'] == ''){
    header("Location: login.php");
    die();
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
	  
	 
	  
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	  <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
 
    <title>Reports | C-POS</title>
	  
	  <script type="text/javascript" src="jquery.min.js"></script>
<script type="text/javascript" src="moment.min.js"></script>
<script type="text/javascript" src="daterangepicker.min.js"></script>
<link rel="stylesheet" type="text/css" href="daterangepicker.css" />
<script type="text/javascript">
		 
$(function() {

    var start = moment().subtract(29, 'days');
    var end = moment();

    function cb(start, end) {
        $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
    }

    $('#reportrange').daterangepicker({
        startDate: start,
        endDate: end,
        ranges: {
           'Today': [moment(), moment()],
           'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
           'Last 7 Days': [moment().subtract(6, 'days'), moment()],
           'Last 30 Days': [moment().subtract(29, 'days'), moment()],
           'This Month': [moment().startOf('month'), moment().endOf('month')],
           'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        }
    }, cb);

    cb(start, end);

});
	
    function cbs() {
        var startDate = $('#reportrange').data('daterangepicker').startDate._d;
		var endDate = $('#reportrange').data('daterangepicker').endDate._d;
		 
	            var a = startDate; 
                var Smonth = ("0" + (a.getMonth() + 1)).slice(-2); 
                var Sdate = ("0" + a.getDate()).slice(-2); 
                var b = endDate; 
                var emonth = ("0" + (b.getMonth() + 1)).slice(-2); 
                var edate = ("0" + b.getDate()).slice(-2); 
       
	 
		
		//alert(Sdate+"/"+Smonth+"/20");
		//alert(edate+"/"+emonth+"/20");
				
	//	document.getElementById("SDate").value=Smonth+"/"+Sdate+"/20";
	//	document.getElementById("EDate").value=emonth+"/"+edate+"/20";
       var d = new Date();
  var n = d.getFullYear();
      document.getElementById("SDate").value=Smonth+"/"+Sdate+"/"+n;
 	document.getElementById("EDate").value=emonth+"/"+edate+"/"+n;
		
		
    }

   
		 
		 
		 
	  </script>
	   <link href="cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- Datatables -->
    
    <link href="../vendors/datatables.net-bs/css/dataTables.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-buttons-bs/css/buttons.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-fixedheader-bs/css/fixedHeader.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-responsive-bs/css/responsive.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-scroller-bs/css/scroller.bootstrap.min.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
    <!-- Bootstrap -->
    <link href="cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- Datatables -->
    
    <link href="../vendors/datatables.net-bs/css/dataTables.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-buttons-bs/css/buttons.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-fixedheader-bs/css/fixedHeader.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-responsive-bs/css/responsive.bootstrap.min.css" rel="stylesheet">
    <link href="../vendors/datatables.net-scroller-bs/css/scroller.bootstrap.min.css" rel="stylesheet">

	     <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
	  <link href="../vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
	   <link href="../vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">
	  
    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
   <style>
      @media print {
  * {
    display: none;
  }
  #printableTable_summary {
    display:block;
  }
}
      </style>
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
         <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
          <?php include_once 'menu.php';?>         <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
            <div class="sidebar-footer hidden-small">
              <a data-toggle="tooltip" data-placement="top" title="Settings">
                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="FullScreen">
                <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Lock">
                <span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Logout" href="login.php">
                <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
              </a>
            </div>
            <!-- /menu footer buttons -->
          </div>
        </div>

        <!-- top navigation -->
         <div class="top_nav">
          <div class="nav_menu">
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>
              <nav class="nav navbar-nav">
              <ul class=" navbar-right">
                <li class="nav-item dropdown open" style="padding-left: 15px;">
                  <a href="javascript:;" class="user-profile dropdown-toggle" aria-haspopup="true" id="navbarDropdown" data-toggle="dropdown" aria-expanded="false">
                    <?php echo $_SESSION["username"]; ?>
                  </a>
                  <div class="dropdown-menu dropdown-usermenu pull-right" aria-labelledby="navbarDropdown">
					  <?php
					  include_once 'con_file.php';
			  $conn;

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
					  $sql = "SELECT username, access FROM users";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		if ($_SESSION["username"]==$row["username"])
		{
			
			$access=$row["access"];
			if ($access=="admin"){
				echo "<a class='dropdown-item'  href='setting.php'><i class='fa fa-gear pull-right'></i> Settings</a>";
			}
			
			
					 
		}
       
    }
} else {
    
}
$conn->close();
?> 
					  
                    
                    <a class="dropdown-item"  href="login.php"><i class="fa fa-sign-out pull-right"></i> Log Out</a>
                  </div>
                </li>

              </ul>
            </nav>
          </div>
        </div>
       <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
			  
			  <form method="post">
                
              <div class="col-md-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Accounts Summary</h2>
                    <div class="filter">
						  
                      <div id="reportrange" class="pull-right" style="background: #fff; cursor: pointer; padding: 5px 10px; border: 1px solid #ccc">
                        <i class="fa fa-calendar">&nbsp;&nbsp;</i>
                        <span>January 05, 2020 - January 01, 2026</span> <b class="caret"></b>
                      </div>
						
                    </div>
                    <div class="clearfix"></div>
					  
                  </div><input type="hidden" name="date_R" id="SDate"/><input type="hidden" name="date_E" id="EDate"/>
					<center><input style="width: 120px;height:50px;" onclick="cbs()" type="submit" value="Show Record" class="btn btn-app" ></center>
                </div>
				  
              </div>
            
</form>

            <div class="clearfix"></div>
			  <div class="row">
    		  
			  
			 		  
           
             
                     <?php 
					        include_once 'con_file.php';
			  $conn;
                         $newDate="";
				         $newDateE="";
				  		 $S_Day="";
				  		 $E_Day="";
							$conn = new mysqli($servername, $username, $password, $dbname);

							if ($conn->connect_error) {
    						die("Connection failed: " . $conn->connect_error);
							} 
						  
					  
		              
				    if(isset($_POST['date_R'])){
					  $origDate = $_POST["date_R"];
						   $newDate = date("Y-m-d", strtotime($origDate));
						$S_Day = substr($newDate, 0, -6);
						
						 
				  		 
						$origDateE = $_POST["date_E"];
						   $newDateE = date("Y-m-d", strtotime($origDateE));
$E_Day = substr($newDateE, 0, -6);
						$dd=$newDate.", ".$newDateE;
						// echo "<script type='text/javascript'>alert('$dd');</script>";
				  }
				  else{
					   
						   $newDate = date("Y-m-d");
				  }
					 
						
 

					  $Profit=0;
					  $sale=0;
					  $purchase=0;
					  $Payable=0;
					  $receavable=0;
				  	  $expense=0;
				  	  $material=0;
				      $tax=0;
				      $sale_exp=0;
				  	  $purchase_exp=0;
				  
				  
                  $sql = "SELECT i.total_amount, i.due_amount, s.quantity, s.unit_price, s.sale_price FROM tblinvoice i INNER JOIN tblsale s ON i.invoice_id=s.invoice_id WHERE invoice_date between '".$newDate."' And '".$newDateE."'"; 
                
			 
		
$result = $conn->query($sql);
		  if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {

	$Profit=$Profit+(($row["sale_price"]-$row["unit_price"])*$row["quantity"]);	
$sale=$sale+$row["total_amount"];
$receavable=$receavable+$row["due_amount"];
    
	}
}
				  

				  
 $sql = "SELECT cost FROM tblexpense WHERE exp_date between '".$newDate."' And '".$newDateE."'"; 
$result = $conn->query($sql);
		  if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		 	$expense=$expense+$row["cost"];
	 }
} else {
    
}
				  
$sql = "SELECT total_amount, due_amount FROM tblpurchaseorder WHERE order_date between '".$newDate."' And '".$newDateE."'"; 
			  
$result = $conn->query($sql);
		  if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		
   $purchase=$purchase+$row["total_amount"];
$Payable=$Payable+$row["due_amount"];
 
    
	}
} 
?>
			  

              
            </div>
			 <div class="clearfix"></div>
			   <?php 
               if (isset($origDate)){
              ?>
				   					<div class="col-md-12 col-sm-12 ">
              <div class="x_panel tile">
                <div>
					<h2>Summary of the Date: <?php echo $newDate." To ".$newDateE; ?></h2>
                </div>
			  </div>
            </div>
	 
	<div class="clearfix"></div>
			  
		 
			 
				  
		  <div class="col-md-12 col-sm-12 ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Financial  Report</h2>
                   <div style="float:right">
                      <button onclick="selectElementContents( document.getElementById('table1') );" style="border-radius:4px;background-color:gray;padding:6px;border-style:none;color:white;"><i class="fa fa-copy"></i> Copy </button>
                       
                     <button onclick="exportTableToExcel('table1', 'profitanalysis')" style="border-radius:4px;background-color:#4287f5;padding:6px;border-style:none;color:white;"><i class="fa fa-file-excel-o"></i> Export</button>
                       
                    <button onclick="printDiv('1')" style="border-radius:4px;background-color:#1ea66b;padding:6px;border-style:none;color:white;"><i class="fa fa-print"></i> Print</button>
                      </div>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                      
                    <div class="row">
                      <div class="col-sm-12">
                        <div class="card-box table-responsive">
                         
                          <div id="table1_summary">
                           <table id="table1" class="table table-striped table-bordered" style="width:100%">
                                
                             <thead>
                                 <tr>
                                 <td style="width:50%"><h2>Financial  Report</h2></td>
                                     <td ><h2>Date: <?php echo $newDate." To ".$newDateE; ?></h2></td>
                                 
                                 </tr>
                              <tr>
                              <td  style="padding:2%"><b>Title</b></td>
                          <td  style="padding:2%"><b>Details</b></td>
                    
                              </tr>
                            </thead>

                            <tbody>
                                <tr><td style="padding:2%"><b>Profit</b></td><td style="padding:2%"><?php echo $Profit; ?>.00</td></tr>
                                <tr><td style="padding:2%"><b>Loss</b></td><td style="padding:2%"><?php echo "0"; ?>.00</td></tr>
                                <tr><td style="padding:2%"><b>Sales</b></td><td style="padding:2%"><?php echo $sale; ?>.00</td></tr>
                                <tr><td style="padding:2%"><b>Purchase</b></td><td style="padding:2%"><?php echo $purchase; ?>.00</td></tr>
                                <tr><td style="padding:2%"><b>Payable</b></td><td style="padding:2%"><?php echo $Payable; ?>.00</td></tr>
                                <tr><td style="padding:2%"><b>Receivable</b></td> <td style="padding:2%"><?php echo $receavable; ?>.00</td></tr>
                                <tr><td style="padding:2%"><b>Expense</b></td><td style="padding:2%"><?php echo $expense; ?>.00</td></tr>
                                
							  </tbody> 
                                    
                          </table>
                            </div> 
                       
                            </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>		  		
	   <iframe name="print_frame" width="0" height="0" frameborder="0" src="about:blank"></iframe>
			  <div class="col-md-12 col-sm-12 ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Purchase Report</h2>
                         <div style="float:right">
                      <button onclick="selectElementContents( document.getElementById('table2') );" style="border-radius:4px;background-color:gray;padding:6px;border-style:none;color:white;"><i class="fa fa-copy"></i> Copy </button>
                       
                     <button onclick="exportTableToExcel('table2', 'profitanalysis')" style="border-radius:4px;background-color:#4287f5;padding:6px;border-style:none;color:white;"><i class="fa fa-file-excel-o"></i> Export</button>
                       
                    <button onclick="printDiv('2')" style="border-radius:4px;background-color:#1ea66b;padding:6px;border-style:none;color:white;"><i class="fa fa-print"></i> Print</button>
                      </div>
                  
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <div class="row">
                      <div class="col-sm-12">
                        <div class="card-box table-responsive">
                         
  <div id="table2_summary">
                          <table id="table2" class="table table-striped table-bordered" style="width:100%">
                            <thead>
                              <tr>
                              <th style="width: 5%">Purchase Order</th>
                          <th style="width: 10%">Order Date</th>
                          <th style="width: 20%">Order</th>
							<th style="width: 25%">Order Details</th>
                           <th style="width: 10%">Price</th>
                          <th style="width: 10%">Order Quantity</th>
								     
                              </tr>
                            </thead>


                            <tbody>
                             <?php
						  							 
						  
$sql1="SELECT p.purchase_order_id,i.product_name,i.product_detail,o.order_date, p.unit_price,p.quantity FROM tblpruchase p INNER JOIN tblpurchaseorder o ON p.purchase_order_id=o.purchase_order_id INNER JOIN tblproduct i ON p.product_id=i.product_id WHERE o.order_date between '".$newDate."' And '".$newDateE."'"; 
								 
$result = $conn->query($sql1);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		
		echo "<tr><td>" . $row["purchase_order_id"]. "</td>";
		echo "<td>" . $row["order_date"]. "</td>";
		echo "<td>" . $row["product_name"]. "</td>";	
		echo "<td>" . $row["product_detail"]. "</td>";	
		echo "<td>" . $row["unit_price"]. "</td>";	
		echo "<td>" . $row["quantity"]. "</td></tr>";
		 
		 
		
		 

		  }
} else {
   
}
						   
   
						?>
							  </tbody>
                          </table>
                            </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
 
              <div class="col-md-12 col-sm-12 ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Sale Report</h2>
                         <div style="float:right">
                      <button onclick="selectElementContents( document.getElementById('table3') );" style="border-radius:4px;background-color:gray;padding:6px;border-style:none;color:white;"><i class="fa fa-copy"></i> Copy </button>
                       
                     <button onclick="exportTableToExcel('table3', 'profitanalysis')" style="border-radius:4px;background-color:#4287f5;padding:6px;border-style:none;color:white;"><i class="fa fa-file-excel-o"></i> Export</button>
                       
                    <button onclick="printDiv('3')" style="border-radius:4px;background-color:#1ea66b;padding:6px;border-style:none;color:white;"><i class="fa fa-print"></i> Print</button>
                      </div>
           
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                      <div class="row">
                          <div class="col-sm-12">
                            <div class="card-box table-responsive">
                    
					  <div id="table3_summary">
                    <table id="table3" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                           <tr>
                              <th style="width: 5%">Invoice No</th>
                          <th style="width: 10%">Invoice Date</th>
                          <th style="width: 20%">Order</th>
							<th style="width: 25%">Order Details</th>
                           <th style="width: 10%">Price</th>
                          <th style="width: 10%">Order Quantity</th>
                        </tr>
                        
                      </thead>
                      <tbody>
                      <?php
						  
						 
 


						  
							
						  
$sql1="SELECT i.invoice_id,p.product_name,p.product_detail,i.invoice_date,s.unit_price,s.quantity FROM tblinvoice i INNER JOIN tblsale s ON i.invoice_id=s.invoice_id INNER JOIN tblproduct p ON s.product_id=p.product_id WHERE i.invoice_date between '".$newDate."' And '".$newDateE."'"; 
						 
						  
$result = $conn->query($sql1);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		
	echo "<tr><td>" . $row["invoice_id"]. "</td>";
		echo "<td>" . $row["invoice_date"]. "</td>";
		echo "<td>" . $row["product_name"]. "</td>";	
		echo "<td>" . $row["product_detail"]. "</td>";	
		echo "<td>" . $row["unit_price"]. "</td>";	
		echo "<td>" . $row["quantity"]. "</td></tr>";
		 
		 

		  }
} else {
   
}
						  
   
						?>
                      
                      </tbody>
                    </table>
                                </div>
					
					
                  </div>
                </div>
              </div>
            </div>
                </div>
              </div>
			     <?php 
                   }
              ?>
	
			 
			  <div class="clearfix"></div> 
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
       <footer>
          <div class="pull-right">
             <a href="https://centromonics.com">Centromonics - Point of Sale</a>
          </div>
          <div class="clearfix"></div>
        </footer>
         <!-- /footer content -->
      </div>
    </div>
<script>  
              function printDiv(val) {
                  if (val=='1'){
                     window.frames["print_frame"].document.body.innerHTML = document.getElementById('table1_summary').innerHTML;  
                  }
                  else if (val=='2'){
                     window.frames["print_frame"].document.body.innerHTML = document.getElementById('table2_summary').innerHTML;  
                  }
                  else if (val=='3'){
                     window.frames["print_frame"].document.body.innerHTML = document.getElementById('table3_summary').innerHTML;  
                  }
  
                 
         window.frames["print_frame"].window.focus();
         window.frames["print_frame"].window.print();
       }
    function selectElementContents(el) {
	var body = document.body, range, sel;
	if (document.createRange && window.getSelection) {
		range = document.createRange();
		sel = window.getSelection();
		sel.removeAllRanges();
		try {
			range.selectNodeContents(el);
			sel.addRange(range);
		} catch (e) {
			range.selectNode(el);
			sel.addRange(range);
		}
	} else if (body.createTextRange) {
		range = body.createTextRange();
		range.moveToElementText(el);
		range.select();
	}
}
    function exportTableToExcel(tableID, filename = ''){
    var downloadLink;
    var dataType = 'application/vnd.ms-excel';
    var tableSelect = document.getElementById(tableID);
    var tableHTML = tableSelect.outerHTML.replace(/ /g, '%20');
    
    // Specify file name
    filename = filename?filename+'.xls':'excel_data.xls';
    
    // Create download link element
    downloadLink = document.createElement("a");
    
    document.body.appendChild(downloadLink);
    
    if(navigator.msSaveOrOpenBlob){
        var blob = new Blob(['\ufeff', tableHTML], {
            type: dataType
        });
        navigator.msSaveOrOpenBlob( blob, filename);
    }else{
        // Create a link to the file
        downloadLink.href = 'data:' + dataType + ', ' + tableHTML;
    
        // Setting the file name
        downloadLink.download = filename;
        
        //triggering the function
        downloadLink.click();
    }
}
   
      </script>
    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
   <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    
    <!-- iCheck -->
    <script src="../vendors/iCheck/icheck.min.js"></script>
    <!-- Datatables -->
    <script src="../vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="../vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="../vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="../vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
    <script src="../vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
    <script src="../vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="../vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
    <script src="../vendors/datatables.net-scroller/js/dataTables.scroller.min.js"></script>
    <script src="../vendors/jszip/dist/jszip.min.js"></script>
    <script src="../vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="../vendors/pdfmake/build/vfs_fonts.js"></script>
	  
	   <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
   <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- iCheck -->
    <script src="../vendors/iCheck/icheck.min.js"></script>
    <!-- Datatables -->
    <script src="../vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="../vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="../vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="../vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="../vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
    <script src="../vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
    <script src="../vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="../vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
    <script src="../vendors/datatables.net-scroller/js/dataTables.scroller.min.js"></script>
    <script src="../vendors/jszip/dist/jszip.min.js"></script>
    <script src="../vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="../vendors/pdfmake/build/vfs_fonts.js"></script>

    <!-- Custom Theme Scripts -->
	  
	  
	   <script src="../vendors/nprogress/nprogress.js"></script>
	  <script src="../vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
	  
	   <script src="../vendors/moment/min/moment.min.js"></script>
    <script src="../vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
	  

    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>

  </body>
</html>