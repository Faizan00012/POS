<?php
$id=$_GET["id"];
include_once 'con_file.php';
			  $conn;
$sql = "DELETE FROM tblproduct Where product_id='".$id."'";
 
if ($conn->query($sql) === TRUE) {
    
	 
} else {
     
} 

          header('location: items.php');
				   
	 
?>