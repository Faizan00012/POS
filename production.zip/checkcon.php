<?php
include_once ('con_file.php');
$sql = "SELECT username, password FROM users";
$result = $con1->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "id: " . $row["username"]. " - Name: " . $row["password"]. " ". "<br>";
    }
} else {
    echo "0 results";
}
$con1->close();
?>