<?php
header("Expires: Thu, 19 Nov 1981 08:52:00 GMT"); //Date in the past
header("Cache-Control: no-store, no-cache, must-revalidate"); //HTTP/1.1

// Start the session
session_start();

?>
<?php
  
 
if(empty($_SESSION['username']) || $_SESSION['username'] == ''){
    header("Location: login.php");
    die();
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
	  
	  <script src="jquery-1.12.4.min.js"></script>

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Attendance | C-POS </title>

    <!-- Bootstrap -->
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- bootstrap-wysiwyg -->
    <link href="../vendors/google-code-prettify/bin/prettify.min.css" rel="stylesheet">
    <!-- Select2 -->
    <link href="../vendors/select2/dist/css/select2.min.css" rel="stylesheet">
    <!-- Switchery -->
    <link href="../vendors/switchery/dist/switchery.min.css" rel="stylesheet">
    <!-- starrr -->
    <link href="../vendors/starrr/dist/starrr.css" rel="stylesheet">
    <!-- bootstrap-daterangepicker -->
    <link href="../vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
           <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            <?php include_once 'menu.php';?> 
            <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
            <div class="sidebar-footer hidden-small">
              <a data-toggle="tooltip" data-placement="top" title="Settings">
                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="FullScreen">
                <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Lock">
                <span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Logout" href="login.php">
                <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
              </a>
            </div>
            <!-- /menu footer buttons -->
          </div>
        </div>

        <!-- top navigation -->
         <div class="top_nav">
          <div class="nav_menu">
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>
              <nav class="nav navbar-nav">
              <ul class=" navbar-right">
                <li class="nav-item dropdown open" style="padding-left: 15px;">
                  <a href="javascript:;" class="user-profile dropdown-toggle" aria-haspopup="true" id="navbarDropdown" data-toggle="dropdown" aria-expanded="false">
                    <?php echo $_SESSION["username"]; ?>
                  </a>
                  <div class="dropdown-menu dropdown-usermenu pull-right" aria-labelledby="navbarDropdown">
					  <?php
					  include_once 'con_file.php';
			  $conn;

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
					  $sql = "SELECT username, access FROM users";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		if ($_SESSION["username"]==$row["username"])
		{
			
			$access=$row["access"];
			if ($access=="admin"){
				echo "<a class='dropdown-item'  href='setting.php'><i class='fa fa-gear pull-right'></i> Settings</a>";
			}
			
			
					 
		}
       
    }
} else {
    
}
$conn->close();
?> 
					  
                    
                    <a class="dropdown-item"  href="login.php"><i class="fa fa-sign-out pull-right"></i> Log Out</a>
                  </div>
                </li>

              </ul>
            </nav>
          </div>
        </div>
       <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Staff Attendance</h3>
				  
              </div>
					
           
            </div>

            <div class="clearfix"></div>
		

			
	  
           
  					
			<form action="attend_backend.php" method="post" enctype="multipart/form-data">
  <div  class="col-md-14 col-sm-12;width:100%">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Select Date &nbsp;&nbsp;&nbsp; <input type="date" name="Dateinput"></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                     
                      
                    </ul>
                    <div class="clearfix"></div>
                  </div>

                  <div class="x_content">

                    <div class="table-responsive">
                      <table class="table table-striped jambo_table bulk_action">
                        <thead>
                          <tr class="headings">
                           
							  <th class="column-title">Index </th>
                            <th class="column-title">Name </th>
							   <th class="column-title">Address </th>
							   <th class="column-title">Contact </th>
                      
                            <th class="column-title">Attendance </th>
							   <th class="column-title">Remarks </th>
                      
                           
                          </tr>
                        </thead>

                        <tbody>
							 <?php 
                     include_once 'con_file.php';
			  $conn;
							$conn = new mysqli($servername, $username, $password, $dbname);
$reg=1;
$query="";       
                    

    $query = "SELECT * FROM staff";
   
     if ($result = $conn->query($query)) {
    while ($row = $result->fetch_assoc()) {
        

        $field1name = $row["name"];
        $field2name = $row["address"];
        $field3name = $row["contact"];
		$field4name = $row["designation"];
        $field5name = $row["salary"];
        $field6name = $row["DOJ"];
		$field7name = $row["CNIC"];
        // <td><input type="date" name="Date'.$reg.'" value="'. date("Y-m-d").'"></td>
             echo'   
             <tr>
                    
                    <td><input type="hidden" name="Reg'.$reg.'"value="'.$reg.'">'.$reg.'</td>
                    
                    <td><input type="hidden" name="Name'.$reg.'" value="'.$field1name.'">'.$field1name.'</td>
					<td><input type="hidden" name="Address'.$reg.'" value="'.$field2name.'">'.$field2name.'</td>
					<td><input type="hidden" name="Contact'.$reg.'" value="'.$field3name.'">'.$field3name.'</td>
           
                   
                    <td><input name="a'.$reg.'" type="checkbox" checked/> Present</td>
                    <td><input name="R'.$reg.'" type="text" /></td>
             </tr>
             ';
         

        $reg+=1;
        $_SESSION["index"] = $reg;       
                     }
    $result->free();
} 
 
   


?>
                          
                        
                        </tbody>
                      </table>
                    </div>
							
						
                  </div>
                </div>
              </div>
			    <br>
          <div class=""></div>
           <center> 
               <input style="color:white;background-color:blue;border-radius:5px;padding:5px;height:35px;width:150px;border-style:none;" type="submit" name="submit" value="Save Record"></center>
				  </form>
				<br>
        
        	  
          </div>
			  <div class="clearfix"></div>
        </div>
        <!-- /page content -->
		  

        <!-- footer content -->
      <footer>
          <div class="pull-right">
             <a href="https://centromonics.com">Centromonics - Point of Sale</a>
          </div>
          <div class="clearfix"></div>
        </footer>
          <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
   <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    
    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>
  </body>
</html>
