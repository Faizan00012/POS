<?php
include_once 'con_file.php';
			  $conn;
$data=array();
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * FROM tblproduct";
$result = $conn->query($sql);
$q = $_REQUEST["q"];
$data=explode("-",$q);
$hint = "";
    // $data[0]= substr($data[0], 0, -1) ;
  //$data[1]= substr($data[1], 0, -1) ;
 //data[1]=substr_replace(data[1] ,"",-1);
 	 
	 		// echo "<script type='text/javascript'>alert(' $data[0]');</script>";
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
	
		if ($data[0]==$row["product_id"]){
		
			$hint.=$row["product_name"]."|";
            $hint.=$row["produce_code"]."|";
			$hint.=$row["product_detail"]."|";
            $hint.=$row["unit_price"]."|";
			$hint.=$row["sale_price"]."|";
       
            $hint.=$row["discount_percentage"]."|";
            $hint.=$row["product_id"]."|";
            $hint.=$row["unit_in_stock"]."|";
             
			 
		}
       
    }
} else {
    echo "0 results";
}
echo  $hint;
 
$conn->close();

?> 