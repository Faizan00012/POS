<?php
include_once 'con_file.php';
$conn;
$id=$_GET["id"];
$arr = explode("-", $id);
$purchase_id=$arr[0];
$invoice_id=$arr[1];
$product_id=$arr[2];
$quantity=0;
$invoice_date="";
$sub=0;
$sql = "SELECT order_date FROM tblpurchaseorder WHERE purchase_order_id = {$invoice_id}";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
       $invoice_date=$row["order_date"];
    }
} 
$sql = "SELECT quantity,sub_total FROM tblpruchase WHERE purchase_id = {$purchase_id}";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
       $quantity=$row["quantity"];
        $sub=$row["sub_total"];
    }
} 

 $sql = "DELETE FROM  tblpruchase WHERE purchase_id = {$purchase_id}";
 
 $result = mysqli_query($conn, $sql) or die("1Query Unsuccessful.");

$sql = "UPDATE tblproduct SET unit_in_stock = (unit_in_stock-{$quantity})  WHERE product_id = {$product_id}";
 
 $result = mysqli_query($conn, $sql) or die("2Query Unsuccessful.");
 
$sql = "UPDATE tblpurchaseorder SET order_date = '".date("Y-m-d") ."', revise='".$invoice_date."', total_amount = (total_amount-{$sub}) , paid_amount = (paid_amount-{$sub})  WHERE purchase_order_id = {$invoice_id}";
 
  $result = mysqli_query($conn, $sql) or die("3Query Unsuccessful.");
 

 header("Location: return_supplier.php?id=".$invoice_id);

mysqli_close($conn);

?>
