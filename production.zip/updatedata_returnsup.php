<?php
$product_id=$_POST["product_id"];
$sale_id=$_POST["sale_id"];
$invoice_id=$_POST["invoice_id"];
$old_quantity=$_POST["old_quantity"];
$quantity=$_POST["quantity"];
$sale_price=$_POST["sale_price"];
$invoice_date="";
$sub=$quantity*$sale_price;
$total_amount=0;
$paid_amount=0;
$sub_old=$_POST["sub_total"];
include_once 'con_file.php';
$conn;
$sql = "SELECT order_date FROM tblpurchaseorder WHERE purchase_order_id = {$invoice_id}";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
       $invoice_date=$row["order_date"];
    }
} 

 $sql = "UPDATE tblpruchase SET quantity = '{$quantity}', sub_total='{$sub}' WHERE purchase_id = {$sale_id}";
 echo $sql."<br>";
  $result = mysqli_query($conn, $sql) or die("Query Unsuccessful.");

$sql = "UPDATE tblproduct SET unit_in_stock = (unit_in_stock-{$old_quantity})+{$quantity}  WHERE product_id = {$product_id}";
echo $sql."<br>";
 
  $result = mysqli_query($conn, $sql) or die("Query Unsuccessful.");
 
$sql = "UPDATE tblpurchaseorder SET order_date = '".date("Y-m-d") ."', revise='".$invoice_date."', total_amount = (total_amount-{$sub_old})+{$sub} , paid_amount = (paid_amount-{$sub_old})+{$sub}  WHERE purchase_order_id = {$invoice_id}";
echo $sql."<br>";
  $result = mysqli_query($conn, $sql) or die("Query Unsuccessful.");
 

 header("Location: return_supplier.php?id=".$invoice_id);

mysqli_close($conn);

?>
