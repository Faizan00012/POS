<?php
  session_start();

if(empty($_SESSION['username']) || $_SESSION['username'] == ''){
    header("Location: login.php");
    die();
}
	 include_once 'con_file.php';
			  $conn;
                         
							$conn = new mysqli($servername, $username, $password, $dbname);

							if ($conn->connect_error) {
    						die("Connection failed: " . $conn->connect_error);
							} 
 
	
				 
 
 
 

$conn->close();
		  ?> 

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	
    <title>DashBoard | C-POS</title>

    <!-- Bootstrap -->
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
	
    <!-- bootstrap-progressbar -->
    <link href="../vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
    <!-- JQVMap -->
    <link href="../vendors/jqvmap/dist/jqvmap.min.css" rel="stylesheet"/>
    <!-- bootstrap-daterangepicker -->
    <link href="../vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
  </head>

 <body class="nav-md">
    <div class="container body">
      <div class="main_container">
           <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
           

            <!-- sidebar menu -->
 <?php include_once 'menu.php';?>         <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
            <div class="sidebar-footer hidden-small">
              <a data-toggle="tooltip" data-placement="top" title="Settings">
                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="FullScreen">
                <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Lock">
                <span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Logout" href="login.php">
                <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
              </a>
            </div>
            <!-- /menu footer buttons -->
          </div>
        </div>

        <!-- top navigation -->
       <div class="top_nav">
          <div class="nav_menu">
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>
              <nav class="nav navbar-nav">
              <ul class=" navbar-right">
                <li class="nav-item dropdown open" style="padding-left: 15px;">
                  <a href="javascript:;" class="user-profile dropdown-toggle" aria-haspopup="true" id="navbarDropdown" data-toggle="dropdown" aria-expanded="false">
                    <?php echo $_SESSION["username"]; ?>
                  </a>
                  <div class="dropdown-menu dropdown-usermenu pull-right" aria-labelledby="navbarDropdown">
					  <?php
					  include_once 'con_file.php';
			  $conn;

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
					  $sql = "SELECT username, access FROM users";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		if ($_SESSION["username"]==$row["username"])
		{
			
			$access=$row["access"];
			if ($access=="admin"){
				echo "<a class='dropdown-item'  href='setting.php'><i class='fa fa-gear pull-right'></i> Settings</a>";
			}
			
			
					 
		}
       
    }
} else {
    
}
$conn->close();
?> 
					  
                    
                    <a class="dropdown-item"  href="login.php"><i class="fa fa-sign-out pull-right"></i> Log Out</a>
                  </div>
                </li>

              </ul>
            </nav>
          </div>
        </div>
         <!-- /top navigation -->




        <!-- page content -->
        <div class="right_col" role="main">
          <!-- top tiles -->
          <div class="row" style="display: inline-block; width:100%;" >
         
			     <div class="tile_count">
            <div class="col-md-2 col-sm-4  tile_stats_count">
				
              <a href="S_items.php" class="btn btn-app" style="width:140px;height:70px;">
                  <span style="font-size:12px;" class="badge bg-green"><?php echo ""; ?></span>
                    <i class="fa fa-shopping-cart green"></i> Total Sale
                  </a>
              
         
            </div>
            <div class="col-md-2 col-sm-4  tile_stats_count">
				<a  href="Receavable.php" class="btn btn-app" style="width:140px;height:70px;">
                    <span style="font-size:12px;" class="badge bg-red"><?php echo ""; ?></span>
                    <i class="fa fa-arrow-down red"></i> Recevable
                  </a>
              
          
            </div>
            <div class="col-md-2 col-sm-4  tile_stats_count">
			<a href="items.php" class="btn btn-app" style="width:140px;height:70px;">
                    <span style="font-size:12px;" class="badge bg-blue"><?php echo ""; ?></span>
                    <i class="fa fa-cubes blue"></i> Total Items
                  </a>
            
             
            </div>
            <div class="col-md-2 col-sm-4  tile_stats_count">
				<a href="P_items.php" class="btn btn-app" style="width:140px;height:70px;">
                    <span style="font-size:12px;" class="badge bg-green"><?php echo ""; ?></span>
                    <i class="fa fa-money green"></i> Total Purchase
                  </a>
        
              
            </div>
            <div class="col-md-2 col-sm-4  tile_stats_count">
				<a href="payable.php" class="btn btn-app" style="width:140px;height:70px;">
                    <span  style="font-size:12px;" class="badge bg-green"><?php echo ""; ?></span>
                    <i class="fa fa-arrow-up red"></i> Payable
                  </a>
              
              
            </div>
            <div class="col-md-2 col-sm-4  tile_stats_count">
			<a href="CustomerView.php" class="btn btn-app" style="width:140px;height:70px;">
                    <span style="font-size:12px;" class="badge bg-green"><?php echo ""; ?></span>
                    <i class="fa fa-users green"></i> Total Customers
                  </a>
              
              
            </div>
          </div>
        </div>
          <!-- /top tiles -->

		<?php 
			if ($access=="user"||$access=="account"){
				echo "<!--";
			}
?>
       
            
  </div>
       
    
        </div>
        <!-- /page content -->

        <!-- footer content -->
       
         
           
       
        <!-- /footer content -->
      </div>
      <div style="margin-right:30px;margin-top:-40px;" class="pull-right">
             <a href="https://centromonics.com">Centromonics - Point of Sale</a>
          </div>

     <script type="text/javascript">
    var dom = document.getElementById('container');
    var myChart = echarts.init(dom, null, {
      renderer: 'canvas',
      useDirtyRect: false
    });
    var app = {};
    
    var option;

    option = {
  title: {
    text: 'Sale and Purchase',
    subtext: 'Data Analysis'
  },
  tooltip: {
    trigger: 'axis'
  },
  legend: {
    data: ['Sale', 'Purchase']
  },
  toolbox: {
    show: true,
    feature: {
      dataView: { show: true, readOnly: false },
      magicType: { show: true, type: ['line', 'bar'] },
      restore: { show: true },
      saveAsImage: { show: true }
    }
  },
  calculable: true,
  xAxis: [
    {
      type: 'category',
      // prettier-ignore
      data: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
    }
  ],
  yAxis: [
    {
      type: 'value'
    }
  ],
  series: [
    {
      name: 'Sale',
      type: 'bar',
      data: [
        2.0, 4.9, 7.0, 23.2, 25.6, 76.7, 135.6, 162.2, 32.6, 20.0, 6.4, 3.3
      ],
      markPoint: {
        data: [
          { type: 'max', name: 'Max' },
          { type: 'min', name: 'Min' }
        ]
      },
      markLine: {
        data: [{ type: 'average', name: 'Avg' }]
      }
    },
    {
      name: 'Purchase',
      type: 'bar',
      data: [
        2.6, 5.9, 9.0, 26.4, 28.7, 70.7, 175.6, 182.2, 48.7, 18.8, 6.0, 2.3
      ],
      markPoint: {
        data: [
          { name: 'Max', value: 182.2, xAxis: 7, yAxis: 183 },
          { name: 'Min', value: 2.3, xAxis: 11, yAxis: 3 }
        ]
      },
      markLine: {
        data: [{ type: 'average', name: 'Avg' }]
      }
    }
  ]
};

    if (option && typeof option === 'object') {
      myChart.setOption(option);
    }

    window.addEventListener('resize', myChart.resize);
  </script>
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- Chart.js -->
    <script src="../vendors/Chart.js/dist/Chart.min.js"></script>
    <!-- gauge.js -->
    <script src="../vendors/gauge.js/dist/gauge.min.js"></script>
    <!-- bootstrap-progressbar -->
    <script src="../vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <!-- iCheck -->
    <script src="../vendors/iCheck/icheck.min.js"></script>
    <!-- Skycons -->
    <script src="../vendors/skycons/skycons.js"></script>
    <!-- Flot -->
    <script src="../vendors/Flot/jquery.flot.js"></script>
    <script src="../vendors/Flot/jquery.flot.pie.js"></script>
    <script src="../vendors/Flot/jquery.flot.time.js"></script>
    <script src="../vendors/Flot/jquery.flot.stack.js"></script>
    <script src="../vendors/Flot/jquery.flot.resize.js"></script>
    <!-- Flot plugins -->
    <script src="../vendors/flot.orderbars/js/jquery.flot.orderBars.js"></script>
    <script src="../vendors/flot-spline/js/jquery.flot.spline.min.js"></script>
    <script src="../vendors/flot.curvedlines/curvedLines.js"></script>
    <!-- DateJS -->
    <script src="../vendors/DateJS/build/date.js"></script>
    <!-- JQVMap -->
    <script src="../vendors/jqvmap/dist/jquery.vmap.js"></script>
    <script src="../vendors/jqvmap/dist/maps/jquery.vmap.world.js"></script>
    <script src="../vendors/jqvmap/examples/js/jquery.vmap.sampledata.js"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="../vendors/moment/min/moment.min.js"></script>
    <script src="../vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
    <script src="../vendors/echarts/dist/echarts.min.js"></script>
    <script src="../vendors/echarts/map/js/world.js"></script>
    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>
	
  </body>
</html>
