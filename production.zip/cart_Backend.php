  <?php
					$ItemName = array();
					$Itemdetail= array();
					$Qty = array();
					$price = array();
					$discount = array();			
					$count =0; 			
						 
								$status="true";
							 
									
						if(isset($_POST['submit'])){
							 
					   include_once 'con_file.php';
			  $conn;
                         
							$conn = new mysqli($servername, $username, $password, $dbname);
	               
							if ($conn->connect_error) {
    						die("Connection failed: " . $conn->connect_error);
							} 
					 
							
							$data=explode("(",$_POST["ItemName"]);
								 
     					$data[0]= substr($data[0], 0, -1) ;
  						$data[1]= substr($data[1], 0, -1) ;
						  
							$sql = "INSERT INTO client_sale (user_id, item_name, item_detail,item_qty, item_price, sub_total,c_name)
							VALUES ('".$_POST["user_id"]."','".$data[0]."', '".$data[1]."','".$_POST["Qty"]."','".$_POST["Price"]."','".($_POST["Price"]*$_POST["Qty"])."','".$_POST["c_name"]."')";
					 
							
							 
					 

							if ($conn->query($sql) === TRUE) {
							} else {
    						echo "Error: " . $sql . "<br>" . $conn->error;
							}
header("location: cart.php"); 
							  
 
							$conn->close();
								}
			  				  
						?>