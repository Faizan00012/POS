<?php
     include_once 'con_file.php';
                $conn;

                              $conn = new mysqli($servername, $username, $password, $dbname);

                              if ($conn->connect_error) {
                              die("Connection failed: " . $conn->connect_error);
                              } 
 $url =  "//{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";
                $arr = array();
$arr=explode("=",$url);
$sql = "DELETE FROM client_sale WHERE user_id = {$arr[1]}";
$result = mysqli_query($conn, $sql) or die("Query Unsuccessful.");
 header("Location: cs_list.php");

?>