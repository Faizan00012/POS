
<?php
	  include_once 'con_file.php';
			  $conn;
$profit=0;
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

for ($i=1;$i<=date("d");$i++){
	//echo "Date".$i."<br>";
	 $sql = "SELECT total,C_Due,profit FROM sale_client where date='".date($i."/m/y") ."'";
$result = $conn->query($sql);
		  if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
   		$profit=$profit+$row["profit"];
		
		//$T_Customers+=$row["SUM(name)"];
    
	}
			  echo $profit."<br>";
} 
}
?>