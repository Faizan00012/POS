<?php
 session_start();
 
if(empty($_SESSION['username']) || $_SESSION['username'] == ''){
    header("Location: login.php");
    die();
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Purchase Invoice | C-POS </title>

    <!-- Bootstrap -->
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    
    <!-- Custom styling plus plugins -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
  </head>

  <body class="nav-md">
	  <?php
 


?>

    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
           <?php include_once 'menu.php';?>          <!-- /sidebar menu -->


            <!-- /menu footer buttons -->
            <div class="sidebar-footer hidden-small">
              <a data-toggle="tooltip" data-placement="top" title="Settings">
                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="FullScreen">
                <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Lock">
                <span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Logout" href="login.php">
                <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
              </a>
            </div>
            <!-- /menu footer buttons -->
          </div>
        </div>

        <!-- top navigation -->
           <div class="top_nav">
          <div class="nav_menu">
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>
              <nav class="nav navbar-nav">
              <ul class=" navbar-right">
                <li class="nav-item dropdown open" style="padding-left: 15px;">
                  <a href="javascript:;" class="user-profile dropdown-toggle" aria-haspopup="true" id="navbarDropdown" data-toggle="dropdown" aria-expanded="false">
                    <?php echo $_SESSION["username"]; ?>
                  </a>
                  <div class="dropdown-menu dropdown-usermenu pull-right" aria-labelledby="navbarDropdown">
					  <?php
					  include_once 'con_file.php';
			  $conn;

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
					  $sql = "SELECT username, access FROM users";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		if ($_SESSION["username"]==$row["username"])
		{
			
			$access=$row["access"];
			if ($access=="admin"){
				echo "<a class='dropdown-item'  href='setting.php'><i class='fa fa-gear pull-right'></i> Settings</a>";
			}
			
			
					 
		}
       
    }
} else {
    
}
$conn->close();
?> 
					  
                    
                    <a class="dropdown-item"  href="login.php"><i class="fa fa-sign-out pull-right"></i> Log Out</a>
                  </div>
                </li>

              </ul>
            </nav>
          </div>
        </div>
         <!-- /top navigation -->

        <!-- /top navigation -->
        
    
        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
             
              </div>

       
            </div>

            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12">
                <div class="x_panel">
                  <div class="x_title">
 				 <h2>Invoice No.00
						<?php
						$last_id=1;
					 $name="";
							$contact="";
							$email="";
								$address="";
					 $expense="";
					 $Item="";
						$I_qty="";
						$I_price="";
                     $I_mass="";
						$I_detail="";
						$I_discount="";
						$I_total="";
							 include_once 'con_file.php';
			  $conn;
                         
							$conn = new mysqli($servername, $username, $password, $dbname);

							if ($conn->connect_error) {
    						die("Connection failed: " . $conn->connect_error);
							} 
					 
					 
					 
					 
						 $sql = "SELECT invoiceNo  FROM purchase_seller;";
						
						
						$result = $conn->query($sql);
if ($result->num_rows > 0) {
	
    // output data of each row
    while($row = $result->fetch_assoc()) {
						
						   if ($row["invoiceNo"]!=""){
						    $last_id=$row["invoiceNo"];
							   }
		else{
			$last_id=1;
		}
	
		
	}
	$last_id+=1;
						    echo($last_id);
}
							
							?>
							</h2>
           
							
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
<img >
                    <section class="content invoice">
                      <!-- title row -->
                      <div class="row">
                        <div class="  invoice-header">
                          <h1>
                                           
                                      </h1>
                        </div>
                        <!-- /.col -->
                      </div>
                      <!-- info row -->
                      <div class="row invoice-info">
                        <div class="col-sm-4 invoice-col">
                              <address>
                                          <p><strong>Naseeb Shopping Mall</strong><br><br>
											  <strong>Address: </strong>G.T Road, Kamra Cantt.<br><br>
											  
											  <strong>Contact 1: </strong>0345-5807152<br>
                                              <strong>Contact 2: </strong>0313-1141555<br><br>
							  				  <strong></strong><br></p>
							  
                                           
                                      </address>
                        </div>
                        <!-- /.col -->
                        <div class="col-sm-4 invoice-col">
                          From
                          <address>
                                          
							  <?php
							  $trig=true;
							 include_once 'con_file.php';
			  $conn;
							$conn = new mysqli($servername, $username, $password, $dbname);

								

						
						   $sql = "SELECT Purchase_id,Unit_P, Purchase_P, Item_Name, detail,Discount,Qty, Purchase_Name,Purchase_Contact,Purchase_Email, Purchase_Address, curr,  Sub_Total FROM purchase";
$result = $conn->query($sql);
$total=0;
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		if ($row["curr"]>0){
										$expense=$row["curr"];
									}
		
								if ($row["Purchase_Name"]!=""){
								$name=$row["Purchase_Name"];
								$contact=$row["Purchase_Contact"];
								$address=$row["Purchase_Address"];
								$email=$row["Purchase_Email"];
									
								}
							 	 
	}
				 
								
							 
					 
							 if ($name==""){
										echo "<strong>Walkin Customer</strong><br><br><strong>Address:</strong>
										Lane XXX, City XXX.
                                        <br><strong>Contact:</strong>
										03XX-XXXXXXX
                                        <br><strong>Email:</strong>
										XXXXXXXX@gmail.com";
									}
									else{ 
										echo "<strong>".$name."
                                        </strong><br>
                                        <br><strong>Address:</strong>".$address."
                                        <br><strong>Contact:</strong>".$contact."
                                        <br><strong>Email:</strong>".$email;
							 	} 
					}
							  
							 
							 
							 $conn->close();
							?>
                                          
                                      </address>
                        </div>
                        <!-- /.col -->
                     
                        <!-- /.col -->
                      </div>
                      <!-- /.row -->

                      <!-- Table row -->
                      <div class="row">
                        <div class="  table">
                          <table class="table table-striped">
                            <thead>
                              <tr>
                                <th>Quantity</th>
                                <th>Item</th>
                                <th>Price</th>
                                <th>Mass</th>
                                  
                                <th style="width: 40%">Description</th>
                              
								<th>Subtotal</th>
                              </tr>
                            </thead>
                            <tbody>
								
								 <?php
				
	 include_once 'con_file.php';
			  $conn;
                         $Total_P="";
							$conn = new mysqli($servername, $username, $password, $dbname);

							if ($conn->connect_error) {
    						die("Connection failed: " . $conn->connect_error);
							} 
 
$sql = "SELECT Purchase_id, Unit_P,Purchase_P, Item_Name, detail,Discount,Qty, mass, Sub_Total,Purchase_Name,Purchase_Address,Purchase_Contact,Purchase_Email FROM purchase";
$result = $conn->query($sql);
$total=0;
								
								
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		 
        echo "<tr><td>" . $row["Qty"]. "</td>";
		echo "<td>" . $row["Item_Name"]. "</td>";
		$Total_P =$Total_P.", ".$row["Item_Name"];
		echo "<td>Rs. " . $row["Unit_P"]. "</td>";
        echo "<td>" . $row["mass"]. "</td>";
		echo "<td>" . $row["detail"]. "</td>";

		$total=$total+$row["Sub_Total"];
		echo "<td>Rs. " . $row["Sub_Total"]. "</td></tr>";
		$Item=$Item.$row["Item_Name"]." |";
						$I_qty=$I_qty.$row["Qty"]." |";
						$I_price=$I_price.$row["Unit_P"]." |";
                        $I_mass=$I_mass.$row["mass"]." |";
						$I_detail=$I_detail.$row["detail"]." |";
						$I_discount=$I_discount.$row["Discount"]." |";
						$I_total=$I_total.$row["Sub_Total"]." |";
		 }
} else {
    echo "0 results";
}
$conn->close();
								?>
		
                             
                            </tbody>
                          </table>
                        </div>
                        <!-- /.col -->
                      </div>
                      <!-- /.row -->

                      <div class="row">
                        <!-- accepted payments column -->
                          <?php
							
	 include_once 'con_file.php';
			  $conn;
                         
							$conn = new mysqli($servername, $username, $password, $dbname);

							if ($conn->connect_error) {
    						die("Connection failed: " . $conn->connect_error);
							} 
						
 

						  	$sql = "SELECT Purchase_id, Unit_P,Purchase_P, mass, Item_Name, detail,Discount,Qty,Sub_Total FROM purchase";	
						    $result = $conn->query($sql);
						    $total=0;
						  $Net_A=0;
						  $Net_D=0;
						  $Net_T=0;
						  	if ($result->num_rows > 0) {
    // output data of each row
								while($row = $result->fetch_assoc()) {
								 
									$updater = "UPDATE items SET Remain_Qty='".$row["Qty"]."'+Remain_Qty, mass='".$row["mass"]."', Total_Purchase='".$row["Qty"]."'+Total_Purchase WHERE Name='".$row["Item_Name"]."' AND detail='".$row["detail"]."' ";
									$exequery = $conn->query($updater);
									if($exequery){
  										if(mysqli_affected_rows($conn) > 0){
										}
										else{
											$sql = "INSERT INTO items (Name, detail, P_Price, S_Price, Remain_Qty, mass, Total_Purchase)
VALUES ('".$row["Item_Name"]."','".$row["detail"]."','".$row["Unit_P"]."','".$row["Purchase_P"]."','".$row["Qty"]."','".$row["mass"]."','".$row["Qty"]."')";

if ($conn->query($sql) === TRUE) {} else {}
										}
									}
									
									$sql = "INSERT INTO purchase_item (invoiceNo, Name, detail, U_Price, S_Price, P_Qty, mass,P_Date, supplier, address, email, contact, seller)
VALUES ('".$last_id."','".$row["Item_Name"]."','".$row["detail"]."','".$row["Unit_P"]."','".$row["Purchase_P"]."','".$row["Qty"]."','".$row["mass"]."','".date("Y-m-d")."','".$name."','".$address."','".$email."','".$contact."','".$_SESSION['username']."')";
if ($conn->query($sql) === TRUE) {
  
} else {

}
									 
							    $Net_A+=$row["Qty"]*$row["Unit_P"];
							 
									$Net_T+=$row["Sub_Total"];
					 
									 
									  
									  }
									
									
									$sql = "INSERT INTO supplier (name, address, email, contact, inoviceNo, Date, Net , Amount,Paid, Due, exp, seller )
VALUES ('".$name."','".$address."','".$email."','".$contact."','".$last_id."','".date("Y-m-d")."','".$Net_A."','".$Net_T."','".$_POST["paid"]."','".$_POST["remain"]."','".$expense."','".$_SESSION['username']."')";
if ($conn->query($sql) === TRUE) {
    
} else {

}
	 
								 
							}
?>
						  
						   
						  
						  
						  
                       
                        <div class="col-md-6">
                          <p class="lead">Date <?php echo date("Y-m-d"); ?></p>
                          <div class="table-responsive">
                            <table class="table">
                              <tbody>
								  <tr>
                                  <th style="width:50%">Expenses:</th>
                                  <td><?php echo "Rs. ".$expense;?></td>
                                </tr>
                                <tr>
                                  <th style="width:50%">Net Amount:</th>
                                  <td><?php echo "Rs. ".$Net_A;?></td>
                                </tr>
                                 
								  <tr>
                                  <th>Paid Amount:</th>
                                    <td><?php echo "Rs. ".$_POST["paid"];?></td>
                                </tr>
                                <tr>
                                  <th>Due: </th>
                                  <td><?php echo "Rs. ".$_POST["remain"];?></td>
                                </tr>
                              </tbody>
                            </table>
                          </div>
                        </div>
                        <!-- /.col -->
                      </div>
                      <!-- /.row -->
						<?php
						 include_once 'con_file.php';
			  $conn;
                         
							$conn = new mysqli($servername, $username, $password, $dbname);

							if ($conn->connect_error) {
    						die("Connection failed: " . $conn->connect_error);
							} 
						
						$Netdiscount=0;
						$Nettotal=0;
						if(isset($_POST['submit'])){
						 if ($name==""){
							$name="Walkin";
							$contact="03XXXX";
							$email="XXXX";
								$address="XXXX";
						}
							 		
							$sql = "INSERT INTO purchase_seller (invoiceNo, date, items,I_Qty,I_mass, I_Price,I_Detail,I_Discount, I_Stotal, exp, Discount, total, Qty,Paid, S_Name, S_Contact, S_Email, S_Address, S_Due, seller)
							VALUES ('".$last_id."','".date("Y-m-d") ."','".$Item."','".$I_qty."','".$I_mass."','".$I_price."','".$I_detail."','".$I_discount."','".$I_total."','".$expense."','".$Net_D."','".$Net_T."','".$row["Qty"]."','".$_POST["paid"]."','".$name."','".$contact."','".$email."','".$address."','".$_POST["remain"]."','".$_SESSION['username']."')";
							 

							if ($conn->query($sql) === TRUE) {
							} else {
    						echo "Error: " . $sql . "<br>" . $conn->error;
							}
							if ($expense!="0"){
										  $sql = "INSERT INTO expense (Date, detail, Cost,behaviour, seller)
VALUES ('".date("Y-m-d")."', 'Purchase Item invoice: ".$last_id."', '".$expense."','Purchase','".$_SESSION['username']."')";

if ($conn->query($sql) === TRUE) {
     
} else {
    
}
							}
							$sql = "delete from purchase";
							 

							if ($conn->query($sql) === TRUE) {
							} else {
    						echo "Error: " . $sql . "<br>" . $conn->error;
							}

						
							
			  				  
						 }
						
						
$conn->close();
						
						
								
?>
                        <img src="images/temp.jpg" width="20%" height="48px" style="float:right;margin-right:20px;margin-bottom:5px;">
                      <!-- this row will not appear when printing -->
                    </section>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
           <footer>
          <div class="pull-right">
             <h6>Developed By Centromonics</h6>
          </div>
          <div class="clearfix"></div>
        </footer>
             <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
   <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>
  </body>
</html>