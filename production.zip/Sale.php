<?php
 session_start();
 
if(empty($_SESSION['username']) || $_SESSION['username'] == ''){
    header("Location: login.php");
    die();
}
header("Expires: Thu, 19 Nov 1981 08:52:00 GMT"); //Date in the past
header("Cache-Control: no-store, no-cache, must-revalidate"); //HTTP/1.1

?>

<!DOCTYPE html>
<html lang="en">
  <head>
	  <style>
		  
		   
    .search-box input[type="text"], .result{
        width: 100%;
        box-sizing: border-box;
    }
    /* Formatting result items */
    .result p{
        margin: 0;
        padding: 7px 10px;
        border: 1px solid #CCCCCC;
        border-top: none;
        cursor: pointer;
    }
    .result p:hover{
        background: blue;
        color: white;
    }
    .search-box-detail input[type="text"], .result{
        width: 100%;
        box-sizing: border-box;
    }
    /* Formatting result items */
    .result-detail p{
        margin: 0;
        padding: 7px 10px;
        border: 1px solid #CCCCCC;
        border-top: none;
        cursor: pointer;
    }
    .result-detail p:hover{
        background: #f2f2f2;
    }
	
    
	      
    .search-box-Customer input[type="text"], .result{
        width: 100%;
        box-sizing: border-box;
    }
    /* Formatting result items */
    .result-Customer p{
        margin: 0;
        padding: 7px 10px;
        border: 1px solid #CCCCCC;
        border-top: none;
        cursor: pointer;
    }
    .result-Customer p:hover{
        background: #f2f2f2;
    }
	  
	  </style>
	  
	  <script src="jquery-1.12.4.min.js"></script>
<script type="text/javascript">
	
	function showHint(str) {
    if (str.length == 0) { 
        document.getElementById("txtHint").innerHTML = "";
        return;
    } else {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
				var txt =xmlhttp.responseText;
				var str = txt;
			 
				var arr = str.split("|");
				
                
				document.getElementById("Price").value = arr[4];
                document.getElementById("remainqty").value = arr[7];
			 
				document.getElementById("U_Price").value = arr[3];
               
		 
            }
        };
		
		 
	  
        xmlhttp.open("GET", "gethintproduct.php?q=" + str, true);
        xmlhttp.send();
    }
		
}
	function CB_Change(){
		if (document.getElementById("checkbox1").checked==true){
		 
		}
		else{
			 
		}
	}
    function checkqty(){
      var qty=parseInt(document.getElementById("Qty").value);
       var remain_qty=parseInt(document.getElementById("remainqty").value);
        if ( qty>remain_qty ){
            
          alert("Quantity is out of Stock");
            document.getElementById("Qty").value="";
        }
    }
    
    	function showbarcode() {
	  var str=  document.getElementById("barcode").value;
            
    if (str.length == 0) { 
        document.getElementById("txtHint").innerHTML = "";
        return;
    } else {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
			 
			 var txt =xmlhttp.responseText;
				var new_text = txt;
				var arr = new_text.split("|");
                
				//	arr[0] product 
                //	arr[1] barcode
                //	arr[2] detail
                //	arr[3] unit price
                //	arr[4] sale price
                //	arr[5] discount
                //	arr[6] product_id
                //	arr[7] stock
                
                if (arr[8]=="11"){
			     document.getElementById("ItemName").value = arr[6]+"- "+arr[0]+" ("+arr[2]+")";
				document.getElementById("Price").value = arr[4];
                document.getElementById("remainqty").value = arr[7];
			 
				document.getElementById("U_Price").value = arr[3];
                    }
                else{
                      document.getElementById("ItemName").value = "";
				document.getElementById("Price").value =  "";
                document.getElementById("remainqty").value =  "";
			 
				document.getElementById("U_Price").value =  "";
                }
				
            }
        };
		
		
	    
        xmlhttp.open("GET", "getbarcode.php?q=" + str, true);
        xmlhttp.send();
    }
  
		
}
	function showName(str) {
		
    if (str.length == 0) { 
        document.getElementById("txtHint").innerHTML = "";
        return;
    } else {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
				var txt =xmlhttp.responseText;
				var str = txt;
				var arr = str.split("|");
		
                	document.getElementById("customer_id").value = arr[3];
				
            }
        };
		
		
	    
        xmlhttp.open("GET", "gethintName.php?q=" + str, true);
        xmlhttp.send();
    }
		
}
$(document).ready(function(){
	
    $('.search-box input[type="text"]').on("keyup input", function(){
        /* Get input value on change */
        var inputVal = $(this).val();
        var resultDropdown = $(this).siblings(".result");
        if(inputVal.length){
            $.get("backend-search-sale.php", {term: inputVal}).done(function(data){
                // Display the returned data in browser
                resultDropdown.html(data);
            });
        } else{
            resultDropdown.empty();
        }
    });
   
	 $('.search-box-detail input[type="text"]').on("keyup input", function(){
        /* Get input value on change */
        var inputVal = $(this).val();
        var resultDropdown = $(this).siblings(".result-detail");
        if(inputVal.length){
            $.get("backend-search-d.php", {term: inputVal+"|"+document.getElementById("ItemName").value}).done(function(data){
                // Display the returned data in browser
                resultDropdown.html(data);
				
            });
        } else{
            resultDropdown.empty();
        }
    });
    
	 	 
    
	
	  $('.search-box-Customer input[type="text"]').on("keyup input", function(){
        /* Get input value on change */
        var inputVal = $(this).val();
        var resultDropdown = $(this).siblings(".result-Customer");
        if(inputVal.length){
            $.get("backend-search-c.php", {term: inputVal}).done(function(data){
                // Display the returned data in browser
                resultDropdown.html(data);
            });
        } else{
            resultDropdown.empty();
        }
    });
   
	 
	
    // Set search input value on click of result item
    $(document).on("click", ".result p", function(){
        $(this).parents(".search-box").find('input[type="text"]').val($(this).text());
		 var x=document.getElementById("ItemName").value;
        $(this).parent(".result").empty();
			showHint(x);
    });
	
  
	 $(document).on("click", ".result-detail p", function(){
		 
       $(this).parents(".search-box-detail").find('input[type="text"]').val($(this).text());
		
        $(this).parent(".result-detail").empty();
		//showHint(x);
    });
	
	 $(document).on("click", ".result-Customer p", function(){
        $(this).parents(".search-box-Customer").find('input[type="text"]').val($(this).text());
		var x=document.getElementById("FName").value
        $(this).parent(".result-Customer").empty();
		 showName(x);
    });
});
</script>
      <script src="store.js" async></script>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Sale | C-POS </title>

    <!-- Bootstrap -->
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- bootstrap-wysiwyg -->
    <link href="../vendors/google-code-prettify/bin/prettify.min.css" rel="stylesheet">
    <!-- Select2 -->
    <link href="../vendors/select2/dist/css/select2.min.css" rel="stylesheet">
    <!-- Switchery -->
    <link href="../vendors/switchery/dist/switchery.min.css" rel="stylesheet">
    <!-- starrr -->
    <link href="../vendors/starrr/dist/starrr.css" rel="stylesheet">
    <!-- bootstrap-daterangepicker -->
    <link href="../vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
           <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
          <?php include_once 'menu.php';?>         <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
            <div class="sidebar-footer hidden-small">
              <a data-toggle="tooltip" data-placement="top" title="Settings">
                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="FullScreen">
                <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Lock">
                <span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Logout" href="login.php">
                <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
              </a>
            </div>
            <!-- /menu footer buttons -->
          </div>
        </div>

        <!-- top navigation -->
       <div class="top_nav">
          <div class="nav_menu">
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>
              <nav class="nav navbar-nav">
              <ul class=" navbar-right">
                <li class="nav-item dropdown open" style="padding-left: 15px;">
                  <a href="javascript:;" class="user-profile dropdown-toggle" aria-haspopup="true" id="navbarDropdown" data-toggle="dropdown" aria-expanded="false">
                    <?php echo $_SESSION["username"]; ?>
                  </a>
                  <div class="dropdown-menu dropdown-usermenu pull-right" aria-labelledby="navbarDropdown">
					  <?php
					  include_once 'con_file.php';
			  $conn;

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
					  $sql = "SELECT username, access FROM users";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		if ($_SESSION["username"]==$row["username"])
		{
			
			$access=$row["access"];
			if ($access=="admin"){
				echo "<a class='dropdown-item'  href='setting.php'><i class='fa fa-gear pull-right'></i> Settings</a>";
			}
			
			
					 
		}
       
    }
} else {
    
}
$conn->close();
?> 
					  
                    
                    <a class="dropdown-item"  href="login.php"><i class="fa fa-sign-out pull-right"></i> Log Out</a>
                  </div>
                </li>

              </ul>
            </nav>
          </div>
        </div>
         <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
       

            <div class="clearfix"></div>
			  <?php
			  $T_Items=0;
			 include_once 'con_file.php';
			  $conn;
                         
							$conn = new mysqli($servername, $username, $password, $dbname);

							if ($conn->connect_error) {
    						die("Connection failed: " . $conn->connect_error);
							} 
						
			  $sql = "SELECT SUM(unit_in_stock) FROM tblproduct";
$result = $conn->query($sql);
		  if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $T_Items+=$row["SUM(unit_in_stock)"];
		 
	 	
    }
} else {
    
}

			  if ($T_Items<=0){
				 echo "<h5 style='color:Red;'>No item in Stock</h5>";
			  }

          
        ?>

			  <form method="post" action="">
            <div class="row">
 
            
				

        <div class="col-md-12 ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>POS Screen</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                     
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />
                 
                        <table  style="width:100%">
                      <tr>
                            <td style="width:50%;padding:20px;">
                              <div class="form-group row ">
                        <label class="control-label col-md-3 col-sm-3 ">Barcode</label>
                        <div class="col-md-9 col-sm-9 ">
				          <input type="text" id="barcode" onkeyup="showbarcode()"  class="form-control" placeholder="" name="barcode" required> 
							 </div>
                      </div>
                                <div class="form-group row ">
                        <label class="control-label col-md-3 col-sm-3 ">Product</label>
                        <div class="col-md-9 col-sm-9 ">
							<div class="search-box">
                          <input type="text" id="ItemName" autocomplete="off"  class="form-control" placeholder="Search Product" name="ItemName" required><div class="result"></div>
								  </div>
  
                        </div>
                      </div>
                      <div class="form-group row">
                        <label class="control-label col-md-3 col-sm-3 ">Quantity</label>
                        <div class="col-md-9 col-sm-9 ">
                         <input type="text" id="Qty" onkeyup="" value=1 onchange="checkqty()" class="form-control" placeholder="0" name="Qty" required><br>
                             <input type="button" name="" onclick="addqty()" value="+" class="btn btn-primary">
                            <input type="button" name="" onclick="subqty()" value="-" class="btn btn-primary">
                           
                        </div>
                      </div>
					 
                  
                          </td>
                          <td style="padding:20px;">
                              <div class="form-group row">
                        <label class="col-form-label col-md-3 col-sm-3 "></label>
                                  
                        <div class="col-md-4 col-sm-9; ">
                            <label>Price</label>
                          <input style="height:200px;width:200px; font-size:40px;text-align:center;color:green" type="text" id="Price" class="form-control" placeholder="0"  name="Price" required>
							<input type="hidden" id="U_Price"  name="U_Price">
                        </div>
                      </div>
                      
                          </td>
                            </tr>
                            <tr>
                               <td>
                                    <input type="hidden" id="remainqty" name="remainqty" >
                          <input type="hidden" id="Price" class="form-control" placeholder="0" value="0" name="Per_Price" >
							 
                        
					  
					  
					  
					  
                      
                          <input type="hidden" class="form-control"  name="Discount" value="0" required>
                        <input type="hidden" class="form-control"   name="DC" value="per" required>
                 
                
<audio id="sound1" src="audio/click.wav" preload="auto"></audio>
                      <audio id="sound2" src="audio/remove.wav" preload="auto"></audio>
                      <div  class="ln_solid"></div>
                       
							<div  class="col-md-12 col-sm-9  offset-md-6">
						  <input  type="button"  onclick="addtocart()" class="btn btn-success" value="Add to Cart">
                                
						 
                         <br><br>
                        </div>
                                </td>
                            </tr>
                         
                      </table>
                      
			
			
                   
				 
					  
                  
                  </div>
					
                </div>
              </div>

  <div  class="col-md-12 col-sm-6;width:100%">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Order List </h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                     
                      
                    </ul>
                    <div class="clearfix"></div>
                  </div>

                  <div class="x_content">

                    <div class="table-responsive">
                      <table id="table" class="table table-striped jambo_table bulk_action">
                
                          <tr >
                            
                            <th class="column-title">Item Name </th>
                              <th class="column-title">Quantity </th>
                              <th class="column-title">Price </th>
                      
                              <th class="column-title">Sub total </th>
                              <th class="column-title">Action </th>
                           
                          </tr>
                        
                            
        

                        <tbody>
 
                          
                        
                        </tbody>
                      </table>
                             <script>
               function cart(){
              
                
                  
                    }
            
        </script>
                    </div>
							
						
                  </div>
                </div>
              </div>
          
            </div>
			  </form>
			
						
 

        	  
          </div>
			  <div class="clearfix"></div>
            
<form method="post" action="sale_script.php">
            <div class="row">
              <div class="col-md-12 col-sm-12  ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Check Out	</h2>
                    <ul class="nav navbar-right panel_toolbox">
						
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                       
                       
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                   
                    <input type="hidden" id="table_array"  name="table_array" >
                       
                      <div class="form-group row">
                        <label class="control-label col-md-2 col-sm-3 ">Customer </label>
                        <div class="col-md-10 col-sm-9 ">
                            <div class="search-box-Customer">
                           <input type="text" class="form-control" id="FName" autocomplete="off" placeholder="Walk In" name="FName" required>
                                <div class="result-Customer"></div>
                            </div>
                        </div>
                      </div>
                            
                        <input type="hidden" id="customer_id" name="customer_id" >
                       
					   
                        <input type="hidden" class="form-control has-feedback-left" placeholder="Expense"  name="exp" >
                            
                            
                     <div class="form-group row">
                  
                        <div class="col-md-9 col-sm-9 ">
                          <input type="hidden" id="Net_Amount" style="color:green;"  class="form-control" disabled="disabled" placeholder="0">
                            <input type="hidden" id="username" value="<?php echo $_SESSION['username']; ?>" name="username">
                        </div>
                      </div>
                     
                    <input type="hidden" id="discount" style="color:green;" onchange="DiscountPrice(this.value);" class="form-control"  placeholder="0">
                      
                             <div class="form-group row">
                        <label class="control-label col-md-2 col-sm-3 ">Discount</label>
                                    <label style="font-size:14px" class="control-label col-md-1 col-sm-3 ">Per (%)</label>
                        <div class="col-md-4 col-sm-9 ">
                          <input type="number" onkeyup="updatePer()" name="dis_per"  id="dis_per" class="form-control" value="0">
                          
                        </div>
                              
                                  <label style="font-size:14px" class="control-label col-md-1 col-sm-3 ">Rs</label>
                            <div class="col-md-4 col-sm-9 ">
                            <input onkeyup="updateRs()" type="number" name="dis_rs" id="dis_rs" class="form-control"  value="0">
                        </div>
                      </div>     
                      <div class="form-group row">
                        <label class="control-label col-md-2 col-sm-3 ">Total Amount</label>
                        <div class="col-md-10 col-sm-9 ">
                          <input type="text" name="Total_Amount" style="color:green;" id="Total_Amount" class="form-control" readonly="readonly" placeholder="0">
                          
                        </div>
                      </div>
               
					    <div class="form-group row ">
                        <label class="control-label col-md-2 col-sm-3 ">Paid Amount</label>
                        <div class="col-md-10 col-sm-9 ">
                          <input type="number" style="color:black;" name="Paid_Amount"  onkeyup="updatePrice()" id="Paid_Amount" class="form-control"   value="0" required>
                        </div>
                      </div>
              <div class="form-group row">
					
                        <label class="control-label col-md-2 col-sm-3 ">Amount Paid</label>
                        <div class="col-md-2 col-sm-9 ">
                          <input type="text" style="color:green;" name="amount_paid"  id="amount_paid" class="form-control" value=""  readonly="readonly"   placeholder="0">
                        </div>
                   <label class="control-label col-md-2 col-sm-3 ">Change Amount</label>
                        <div class="col-md-2 col-sm-9 ">
                          <input type="text" style="color:green;"  id="change_Amount" class="form-control" value=""  readonly="readonly"   placeholder="0">
                        </div>
                   <label class="control-label col-md-2 col-sm-3 ">Due Amount</label>
                        <div class="col-md-2 col-sm-9 ">
                            <input type="text" style="color:red;"  id="Remain_Amount" class="form-control" value="" name="Remain_Amount"  readonly="readonly"   placeholder="0">
                        </div>
                      </div>
               
                      <div class="ln_solid"></div>
                      <div class="item form-group">
                        <div class="col-md-6 col-sm-6 offset-md-3">
							
                            <input type='submit' value="Check out" name="submit" class='btn btn-success' data-toggle='modal' data-target='.bs-example-modal-lg'> 
							
                        </div>
						 						  <script>
                     function updateRs(){
                       var per,rs,total_amount,paid_amount;
                          total_amount=parseInt(document.getElementById("Net_Amount").value);
                          //  per=parseInt(document.getElementById("dis_per").value);
                       
                         if (document.getElementById("dis_rs").value==""){
                             rs=0;
                         }
                         else{
                             rs=parseInt(document.getElementById("dis_rs").value);
                         }
                         if (rs>total_amount){
                           document.getElementById("dis_rs").value=total_amount.toString();
                             rs=total_amount;
                         }
                       total_amount=parseInt(document.getElementById("Net_Amount").value);
                       paid_amount=total_amount-rs;
                         per=parseInt(rs*100/total_amount);
                            document.getElementById("dis_per").value=per.toString();
                       document.getElementById("Total_Amount").value=paid_amount.toString(); 
                         document.getElementById("Paid_Amount").value=paid_amount.toString(); 
                         document.getElementById("amount_paid").value=paid_amount.toString(); 
                     }
                 function updatePer(){
                       var per,rs,total_amount,paid_amount,discount_per;
                          total_amount=parseInt(document.getElementById("Net_Amount").value);
                           
                       
                         if (document.getElementById("dis_per").value==""){
                           
                            per=0;
                         }
                         else{
                              per=parseInt(document.getElementById("dis_per").value);
                         }
                     
                       total_amount=parseInt(document.getElementById("Net_Amount").value);
                       discount_per=parseInt(per*total_amount/100);
                      document.getElementById("dis_rs").value=discount_per.toString();
                      if (per>100){
                           document.getElementById("dis_per").value="100";
                             discount_per=total_amount;
                         }
                        paid_amount=parseInt(total_amount-discount_per);
                      document.getElementById("Total_Amount").value=paid_amount.toString(); 
                         document.getElementById("Paid_Amount").value=paid_amount.toString(); 
                         document.getElementById("amount_paid").value=paid_amount.toString();
                   
                     }
					function updatePrice() {
                    var total_amount,paid_amount,remain,change,p1;
                        p1=parseInt(document.getElementById("Paid_Amount").value);
                        total_amount=parseInt(document.getElementById("Total_Amount").value);
                        paid_amount=p1;
                         
						remain = total_amount - paid_amount;
  						document.getElementById("Remain_Amount").value = remain;
                      
						if (remain>0){
                           document.getElementById("Remain_Amount").style.color="red";
                             document.getElementById("change_Amount").value=0;
						}
                        else{
					   document.getElementById("Remain_Amount").style.color="green";
                            document.getElementById("Remain_Amount").value=0;
                        }
				 		if (paid_amount>total_amount){
                           
                            change=paid_amount-total_amount;
                            document.getElementById("amount_paid").value=total_amount;
                            document.getElementById("change_Amount").value=change;
                            document.getElementById("Remain_Amount").style.color="green";
                             document.getElementById("Remain_Amount").value=0;
                            
                        }
                        else{
                         
                              document.getElementById("amount_paid").value=p1;
                              document.getElementById("change_Amount").value=0;
                        }
				
                    }
                                                      function DiscountPrice(val){
                           
                            p2 = document.getElementById("Total_Amount").value;
						
  						newp = p2 - val;
  						document.getElementById("Total_Amount").value = newp;
                                                          	document.getElementById("Paid_Amount").value=newp;
						 
                        }
						
					</script>
                      </div>
<?php
						 
$conn->close();
								
?>
                    
                  </div>
                </div>
              </div>
            </div>
			  </form>
        </div>
        <!-- /page content -->
		  

        <!-- footer content -->
      <footer>
          <div class="pull-right">
             <a href="https://centromonics.com">Centromonics - Point of Sale</a>
          </div>
          <div class="clearfix"></div>
        </footer>
          <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
   <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    
    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>
  </body>
</html>
    <script>
                      var qty;
                      var item_name;
                      var detail;
                      var item_qty;
                      var price;
                      var p_price;
                      var remainqty;
                      var sub_total;
                     var index=0;
                     var total_amount=0;
                     var discount=0;
                     var array = [];
                     function addtocart(){
                           document.getElementById('sound1').play();
                      item_name=document.getElementById("ItemName").value;
                         
                      const myArray = item_name.split("(");
                      item_name = myArray[0];
                      detail=myArray[1].slice(0, -1);
                      item_qty=document.getElementById("Qty").value;
                    
                      price=document.getElementById("Price").value;
                      p_price=document.getElementById("U_Price").value;
                      sub_total=item_qty*price;
                      remainqty=document.getElementById("remainqty").value-item_qty;
                      array.push([item_name, detail, item_qty, price, p_price,sub_total,remainqty,"|"]);
                      index=index+1;
                         document.getElementById("ItemName").value="";
     document.getElementById("Qty").value=1;
                     tableUpdate();
                     }
                     
                      function addqty(){
                          qty=parseInt(document.getElementById("Qty").value);
                          qty=qty+1;
                          document.getElementById("Qty").value=qty.toString();
                      }
                     function subqty(){
                           qty=parseInt(document.getElementById("Qty").value);
                         if (qty>0){
                          qty=qty-1;
                          document.getElementById("Qty").value=qty.toString();
                             }
                     }
        function tableUpdate(){
             table = document.getElementById("table");
            for(var i = index-1; i < index; i++)
            {
               // create a new row
                                  
               var newRow = table.insertRow(table.length);
               for(var j = 0; j < array[i].length-3; j++)
               {

                   // create a new cell
             
                   var cell = newRow.insertCell(j);
            
                   // add value to the cell
                  
                   if (j==0){
                        cell.innerHTML = array[i][j]+"("+array[i][j+1]+")";
                   }
                   else if (j==1){
                        //  array.push([item_name, detail, item_qty, price, p_price,remainqty]);
                    
                 cell.innerHTML = array[i][j+1];
                   }
                   else if (j==2){
                        //  array.push([item_name, detail, item_qty, price, p_price,remainqty]);
                    
                 cell.innerHTML = array[i][j+1];
                   }
                   else if (j==3){
                  
                       
                       var mul=parseInt(array[i][j])*parseInt(array[i][j-1]);
                       
                       total_amount+=mul;
                        cell.innerHTML =mul;
                   }
                   else if (j==4){
                    
                        cell.innerHTML ='<input type="button" class="btn btn-danger" onclick="removelist('+i+')" value="Remove">';
                   }
               
                   document.getElementById("Total_Amount").value=total_amount;
                   document.getElementById("amount_paid").value=total_amount;
                   document.getElementById("Paid_Amount").value=total_amount;
                    document.getElementById("Net_Amount").value=total_amount;
                   document.getElementById("dis_per").value="";
                   document.getElementById("dis_rs").value="";
                   
               }
           }
            document.getElementById("table_array").value=array;
        }
    
     
        
        function removelist(val){
   
            document.getElementById('sound2').play();
            var table = document.getElementById("table");
 
for(var i = table.rows.length - 1; i > 0; i--)
{
  table.deleteRow(i);
}
        array.splice(val, 1);
            index=index-1;
   total_amount=0;
             table = document.getElementById("table");
            for(var i = 0; i < index; i++)
            {
               // create a new row
                                    
               var newRow = table.insertRow(table.length);
             for(var j = 0; j < array[i].length-3; j++)
               {

                   // create a new cell
             
                   var cell = newRow.insertCell(j);
            
                   // add value to the cell
                  
                   if (j==0){
                        cell.innerHTML = array[i][j]+"("+array[i][j+1]+")";
                   }
                   else if (j==1){
                        //  array.push([item_name, detail, item_qty, price, p_price,remainqty]);
                    
                 cell.innerHTML = array[i][j+1];
                   }
                   else if (j==2){
                        //  array.push([item_name, detail, item_qty, price, p_price,remainqty]);
                    
                 cell.innerHTML = array[i][j+1];
                   }
                   else if (j==3){
                  
                       
                       var mul=parseInt(array[i][j])*parseInt(array[i][j-1]);
                       
                       total_amount+=mul;
                        cell.innerHTML =mul;
                   }
                   else if (j==4){
                    
                        cell.innerHTML ='<input type="button" class="btn btn-danger" onclick="removelist('+i+')" value="Remove">';
                   }
                  
                   document.getElementById("Total_Amount").value=total_amount;
                   document.getElementById("amount_paid").value=total_amount;
                   document.getElementById("Paid_Amount").value=total_amount;
                    document.getElementById("Net_Amount").value=total_amount;
                    document.getElementById("dis_per").value="";
                   document.getElementById("dis_rs").value="";
                   
               }
           }
                document.getElementById("table_array").value=array;
 
  } 
                  
        
                  
                     
                      </script>
