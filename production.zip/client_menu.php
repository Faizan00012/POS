<div class="navbar nav_title" style="border: 0;">
              <a href="dashboard.php" class="site_title"><i class="fa fa-laptop"></i> <span>C-POS</span></a>
            </div>

            <div class="clearfix"></div>

             

            <br /> 
<div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
 <div class="menu_section">    
 <h3>General</h3>     
 <ul class="nav side-menu">
 <li><a href="client_dashboard.php"><i class="fa fa-home"></i> Home </a></li>
 <li><a href="cart.php"><i class="fa fa-shopping-cart"></i> Cart </a></li>
   <li><a href="client_Reports.php"><i class="fa fa-bar-chart"></i> Reports </a></li>
 
  </ul>
 </div>
 </div>
 
 