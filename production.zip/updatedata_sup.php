<?php
$s_id = $_POST['s_id'];
$s_name = $_POST['s_name'];
$s_address = $_POST['s_address'];
$s_phone = $_POST['s_phone'];
$s_email = $_POST['s_email'];

   include_once 'con_file.php';
			  $conn;

$sql = "UPDATE tblsupplier SET supplier_name = '{$s_name}', supplier_address = '{$s_address}', supplier_contact = '{$s_phone}',supplier_email = '{$s_email}' WHERE supplier_id = {$s_id}";
 
$result = mysqli_query($conn, $sql) or die("Query Unsuccessful.");
 

header("Location: supplierview.php");

mysqli_close($conn);

?>
