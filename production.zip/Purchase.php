<?php
header("Expires: Thu, 19 Nov 1981 08:52:00 GMT"); //Date in the past
header("Cache-Control: no-store, no-cache, must-revalidate"); //HTTP/1.1
?>
<?php
 session_start();
 
if(empty($_SESSION['username']) || $_SESSION['username'] == ''){
    header("Location: login.php");
    die();
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
	  <style>
	   .search-box-Customer input[type="text"], .result{
        width: 100%;
        box-sizing: border-box;
    }
    /* Formatting result items */
    .result-Customer p{
        margin: 0;
        padding: 7px 10px;
        border: 1px solid #CCCCCC;
        border-top: none;
        cursor: pointer;
    }
    .result-Customer p:hover{
        background: #f2f2f2;
    }
             .search-box input[type="text"], .result{
        width: 100%;
        box-sizing: border-box;
    }
    /* Formatting result items */
    .result p{
        margin: 0;
        padding: 7px 10px;
        border: 1px solid #CCCCCC;
        border-top: none;
        cursor: pointer;
    }
    .result p:hover{
        background: #f2f2f2;
    }
    .search-box-detail input[type="text"], .result{
        width: 100%;
        box-sizing: border-box;
    }
    /* Formatting result items */
    .result-detail p{
        margin: 0;
        padding: 7px 10px;
        border: 1px solid #CCCCCC;
        border-top: none;
        cursor: pointer;
    }
    .result-detail p:hover{
        background: #f2f2f2;
    }
	  
	  </style>
	   <script src="jquery-1.12.4.min.js"></script>
	  <script type="text/javascript">
          	function showHint(str) {
    if (str.length == 0) { 
        document.getElementById("txtHint").innerHTML = "";
        return;
    } else {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
				var txt =xmlhttp.responseText;
				var str = txt;
			 
				var arr = str.split("|");
	 
				document.getElementById("product").value = arr[0];	
                document.getElementById("qty").value = "1";	
                document.getElementById("barcode").value = arr[1];	
				document.getElementById("detail").value = arr[2];
               document.getElementById("unit_price").value = arr[3];
               document.getElementById("sale_price").value = arr[4];
               document.getElementById("discount").value = arr[5];
                document.getElementById("product_id").value = arr[6];
               
               
                
             
		 
            }
        };
		
		 
	  
        xmlhttp.open("GET", "gethint.php?q=" + str, true);
        xmlhttp.send();
    }
		
}
	  function showName(str) {
    if (str.length == 0) { 
        document.getElementById("txtHint").innerHTML = "";
        return;
    } else {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
				var txt =xmlhttp.responseText;
				var str = txt;
				 
                var arr = str.split("|");
				
		
				document.getElementById("Address").value = arr[0];
				document.getElementById("Email").value = arr[1];
				document.getElementById("Phone").value = arr[2];
                	document.getElementById("supplier_id").value = arr[3];
			 
				
            }
        };
		
		
	
        xmlhttp.open("GET", "gethintNameP.php?q=" + str, true);
        xmlhttp.send();
    }
		
}
	$(document).ready(function(){
	  
	 $('.search-box-Customer input[type="text"]').on("keyup input", function(){
        /* Get input value on change */
        var inputVal = $(this).val();
        var resultDropdown = $(this).siblings(".result-Customer");
        if(inputVal.length){
            $.get("backend-search-P.php", {term: inputVal}).done(function(data){
                // Display the returned data in browser
                resultDropdown.html(data);
            });
        } else{
            resultDropdown.empty();
        }
    });
           $('.search-box input[type="text"]').on("keyup input", function(){
        /* Get input value on change */
        var inputVal = $(this).val();
        var resultDropdown = $(this).siblings(".result");
        if(inputVal.length){
            $.get("backend-search.php", {term: inputVal}).done(function(data){
                // Display the returned data in browser
                resultDropdown.html(data);
            });
        } else{
            resultDropdown.empty();
        }
    });
   
	 $('.search-box-detail input[type="text"]').on("keyup input", function(){
        /* Get input value on change */
        var inputVal = $(this).val();
        var resultDropdown = $(this).siblings(".result-detail");
        if(inputVal.length){
            $.get("backend-search-d.php", {term: inputVal+"|"+document.getElementById("ItemName").value}).done(function(data){
                // Display the returned data in browser
                resultDropdown.html(data);
				
            });
        } else{
            resultDropdown.empty();
        }
    });
           $('.search-box input[type="text"]').on("keyup input", function(){
        /* Get input value on change */
        var inputVal = $(this).val();
        var resultDropdown = $(this).siblings(".result");
        if(inputVal.length){
            $.get("backend-search.php", {term: inputVal}).done(function(data){
                // Display the returned data in browser
                resultDropdown.html(data);
            });
        } else{
            resultDropdown.empty();
        }
    });
   
	 $('.search-box-detail input[type="text"]').on("keyup input", function(){
        /* Get input value on change */
        var inputVal = $(this).val();
        var resultDropdown = $(this).siblings(".result-detail");
        if(inputVal.length){
            $.get("backend-search-d.php", {term: inputVal+"|"+document.getElementById("ItemName").value}).done(function(data){
                // Display the returned data in browser
                resultDropdown.html(data);
				
            });
        } else{
            resultDropdown.empty();
        }
    });
		  
		   $(document).on("click", ".result-Customer p", function(){
        $(this).parents(".search-box-Customer").find('input[type="text"]').val($(this).text());
		var x=document.getElementById("FName").value
        $(this).parent(".result-Customer").empty();
		 showName(x);
    });
            // Set search input value on click of result item
    $(document).on("click", ".result p", function(){
        $(this).parents(".search-box").find('input[type="text"]').val($(this).text());
		 var x=document.getElementById("ItemName").value;
        $(this).parent(".result").empty();
			showHint(x);
    });
	
	
	 $(document).on("click", ".result-detail p", function(){
		 
       $(this).parents(".search-box-detail").find('input[type="text"]').val($(this).text());
		
        $(this).parent(".result-detail").empty();
		//showHint(x);
    });
	
});
          
          
	  
	  </script>
	  
	  
	  
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Purchase | C-POS </title>

    <!-- Bootstrap -->
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
            <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
           <?php include_once 'menu.php';?>         <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
            <div class="sidebar-footer hidden-small">
              <a data-toggle="tooltip" data-placement="top" title="Settings">
                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="FullScreen">
                <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Lock">
                <span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Logout" href="login.php">
                <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
              </a>
            </div>
            <!-- /menu footer buttons -->
          </div>
        </div>

        <!-- top navigation -->
         <div class="top_nav">
          <div class="nav_menu">
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>
              <nav class="nav navbar-nav">
              <ul class=" navbar-right">
                <li class="nav-item dropdown open" style="padding-left: 15px;">
                  <a href="javascript:;" class="user-profile dropdown-toggle" aria-haspopup="true" id="navbarDropdown" data-toggle="dropdown" aria-expanded="false">
                    <?php echo $_SESSION["username"]; ?>
                  </a>
                  <div class="dropdown-menu dropdown-usermenu pull-right" aria-labelledby="navbarDropdown">
					  <?php
					  include_once 'con_file.php';
			  $conn;

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
					  $sql = "SELECT username, access FROM users";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		if ($_SESSION["username"]==$row["username"])
		{
			
			$access=$row["access"];
			if ($access=="admin"){
				echo "<a class='dropdown-item'  href='setting.php'><i class='fa fa-gear pull-right'></i> Settings</a>";
			}
			
			
					 
		}
       
    }
} else {
    
}
 
?> 
					  
                    
                    <a class="dropdown-item"  href="login.php"><i class="fa fa-sign-out pull-right"></i> Log Out</a>
                  </div>
                </li>

              </ul>
            </nav>
          </div>
        </div>
       <!-- /top navigation -->
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Purchase Screen</h3>
              </div>

           
            </div>

            <div class="clearfix"></div>

          
        

			 
            <div class="row">
 
              
			
           
                
			 
           <div class="col-md-12">
                <div class="x_panel">
                  
                  <div class="x_content">
                    <br />
                   
                      <div class="form-group row ">
                        <label class="control-label col-md-12 col-sm-12 ">Search Product Name</label>
                        
                      </div>
                       <div class="form-group row ">
                       <div class="col-md-12 col-sm-12 ">
							<div class="search-box">
                          <input type="text" id="ItemName" autocomplete="off"  class="form-control" placeholder="Search..." name="ItemName"><div class="result"></div>
								  </div>
  
                        </div>
                      </div>
                      <br>
                      <hr style="border-width:2px;">
                      <br>
                      <div class="form-group row ">
                        <label class="control-label col-md-3 col-sm-3 ">BarCode</label>
                        <div class="col-md-9 col-sm-9 ">
                             <input type="hidden" id="product_id" name="product_id">
                          <input type="text" class="form-control" id="barcode" name="barcode" disabled>
                        </div>
                      </div>
                      <div class="form-group row ">
                        <label class="control-label col-md-3 col-sm-3 ">Product</label>
                        <div class="col-md-9 col-sm-9 ">
                          <input type="text" class="form-control" id="product" name="product" disabled>
                        </div>
                      </div>
                      
                      <div class="form-group row">
                        <label class="control-label col-md-3 col-sm-3 ">Product Details </label>
                        <div class="col-md-9 col-sm-9 ">
                          <input type="text" class="form-control" id="detail" name="detail" disabled>
                        </div>
                      </div>
                     
					  <div class="form-group row"> 
                        <label class="control-label col-md-3 col-sm-3 ">Unit Price</label>
                        <div class="col-md-9 col-sm-9 ">
                          <input type="number" class="form-control" name="unit_price" id="unit_price" disabled>
                          <input type="hidden" id="sale_price" name="sale_price">
                        </div>
                      </div>  
                     
                       <div class="form-group row">
                        <label class="control-label col-md-3 col-sm-3 ">Quantity</label>
                        <div class="col-md-9 col-sm-9 ">
                         <input type="number" class="form-control" id="qty" name="qty" required>
                        </div>
                      </div>
                       
                          <input type="hidden" class="form-control" id="discount" name="discount" required>
                        
<audio id="sound1" src="audio/click.wav" preload="auto"></audio>
                      <audio id="sound2" src="audio/remove.wav" preload="auto"></audio>
                      <div class="ln_solid"></div>
                       <div class="col-md-9 col-sm-9  offset-md-3">
						  <button onclick="addtocart()" class="btn btn-success">Add To Cart</button>
                         </div>
                  
                  </div>
                </div>
              </div>


           
            </div>
			
			
						
			 <div class='clearfix'></div>

            <div class='row'>
              <div class='col-md-12 col-sm-12'>
                <div class='x_panel'>
                  <div class='x_title'>
                    <h2>Cart List</h2>
                    <ul class='nav navbar-right panel_toolbox'>
                     
                      <li><a class='collapse-link'><i class='fa fa-chevron-up'></i></a>
                      </li>
                    </ul>
                    <div class='clearfix'></div>
                  </div>
                  <div class='x_content'>
                      <div class='row'>
                          <div class='col-sm-12'>
                            <div class='card-box table-responsive'>
                     
					
						
						
						
								
					
								
                   <table id='table' class='table table-striped table-bordered' style='width:100%'>
                      <thead>
                        <tr>
                          <th style="width:5%;background-color:#2f5163;color:white">S-No</th>
                            <th style="width:35%;background-color:#2f5163;color:white">Product</th>
                          <th style="width:5%;background-color:#2f5163;color:white">Qty</th>
                             <th style="width:10%;background-color:#2f5163;color:white">Unit Price</th>
                          
                        <th style="width:10%;background-color:#2f5163;color:white">Discount</th>
                            <th style="width:15%;background-color:#2f5163;color:white">Sub Total</th>
								<th style="width:10%;background-color:#2f5163;color:white">Delete</th>
                        </tr>
                      </thead>


                      <tbody>
                          
                       </tbody>
                                </table>
                  </div>
                  </div>
              </div>
            </div>
                </div>
              </div>

    
         

    

              
            </div> 
              
          </div>
			  <div class="clearfix"></div>
<form method="post" action="purchase_script.php">
            <div class="row">
              <div class="col-md-12 col-sm-12  ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Check Out	</h2>
                    <ul class="nav navbar-right panel_toolbox">
						
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                       
                       
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                        <form id="demo-form2" data-parsley-validate class="form-horizontal form-label-left">
  
                               <div class="form-group row">
                        <label class="control-label col-md-3 col-sm-3 ">Supplier</label>
                        <div class="col-md-9 col-sm-9 ">
                            <div class="search-box-Customer">
                          <input type="text" class="form-control" id="FName" autocomplete="off"  placeholder="Supplier Name" name="_name" required>
                                <div class="result-Customer"></div>
                        </div>
                        </div>
                      </div>
            <input type="hidden" class="form-control" id="supplier_id" name="supplier_id" >
            <input type="hidden" class="form-control" id="Address" name="address">
            <input type="hidden" class="form-control" id="Email"   name="email">
            <input type="hidden" class="form-control" id="Phone" name="phone" >
            <input type="hidden" value="<?php echo $_SESSION['username']; ?>" id="user_name" name="user_name" >                
            <input type="hidden" class="form-control" id="cart_product_id" name="cart_product_id[]" >
            <input type="hidden" class="form-control" id="cart_barcode" name="cart_barcode[]" >
            <input type="hidden" class="form-control" id="cart_product" name="cart_product[]" >
            <input type="hidden" class="form-control" id="cart_detail" name="cart_detail[]" >
            <input type="hidden" class="form-control" id="cart_qty" name="cart_qty[]" >
            <input type="hidden" class="form-control" id="cart_unit_price" name="cart_unit_price[]" >
            <input type="hidden" class="form-control" id="cart_sale_price" name="cart_sale_price[]" >
            <input type="hidden" class="form-control" id="cart_discount" name="cart_discount[]" >
            <input type="hidden" class="form-control" id="cart_sub_total" name="cart_sub_total[]" >
        
                     <div class="form-group row">
                        <label class="control-label col-md-3 col-sm-3 ">Net Amount </label>
                        <div class="col-md-9 col-sm-9 ">
                          <input type="text" style="color:green;" name="net_amount" id="net_amount" class="form-control" disabled="disabled" placeholder="0">
                        </div>
                      </div>
                      <div class="form-group row">
                        <label class="control-label col-md-3 col-sm-3 ">Discount</label>
                        <div class="col-md-9 col-sm-9 ">
                          <input type="text" style="color:green;" name="discount_amount" id="discount_amount" class="form-control" readonly="readonly" placeholder="0">
                        </div>
                      </div>
                           <div class="form-group row">
                        <label class="control-label col-md-3 col-sm-3 ">Total Amount</label>
                        <div class="col-md-9 col-sm-9 ">
                          <input type="text" style="color:green;" name="total_amount" id="total_amount" class="form-control"  readonly="readonly" placeholder="0">
                        </div>
                      </div>
					    <div class="form-group row ">
                        <label class="control-label col-md-3 col-sm-3 ">Paid Amount</label>
                        <div class="col-md-9 col-sm-9 ">
                          <input type="number" style="color:black;" name="paid_amount" value=""  onkeyup="updatePrice(this.value);" id="paid_amount" class="form-control" placeholder="0" required>
                        </div>
                      </div>
             
                <div class="form-group row">
					
                        <label class="control-label col-md-3 col-sm-3 ">Remaining Amount</label>
                        <div class="col-md-9 col-sm-9 ">
                          <input type="text" style="color:red;" id="Remain_Amount" class="form-control" name="Remain_Amount"  readonly="readonly"   placeholder="0">
                        </div>
                      </div>
                      <div class="ln_solid"></div>
                      <div class="item form-group">
                        <div class="col-md-6 col-sm-6 offset-md-3">
							
                            <input type='submit' value="Check out" name="submit" class='btn btn-success' data-toggle='modal' data-target='.bs-example-modal-lg'> 
							
                        </div>
						  <script>
			 
						
					</script>
                      </div>
<?php
						 
$conn->close();
								
?>
                    </form>
                  </div>
                </div>
              </div>
            </div>
			  </form>
        </div>
        <!-- /page content -->
		  

        <!-- footer content -->
      <footer>
          <div class="pull-right">
             <a href="https://centromonics.com">Centromonics - Point of Sale</a>
          </div>
          <div class="clearfix"></div>
        </footer>
          <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
   <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    
    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>
      </div>  
  </body>
</html>
 <script>
                      var qty;
                      var item_name;
                      var detail;
                      var barcode;
                      var product_id;
                      var item_qty;
                      var price;
                      var p_price;
                      var qty;
                      var sub_total;
                     var index=0;
                     var total_amount=0;
                     var total_discount=0;
                     var discount=0;
                     var paid_amount=0;
                     var array = [];
                      var arr_product_id=[];
                     var arr_barcode=[];
                     var arr_product=[];
                     var arr_detail=[];
                     var arr_qty=[];
                     var arr_unit_price=[];
                     var arr_sale_price=[];
                     var arr_discount=[];
                     var arr_sub_total=[];
                     function addtocart(){
                         document.getElementById('sound1').play();
                      product_id=document.getElementById("product_id").value;   
                      item_name=document.getElementById("product").value;
                      barcode=document.getElementById("barcode").value;
                         detail=document.getElementById("detail").value;
                      item_qty=document.getElementById("qty").value;
                    
                      price=document.getElementById("sale_price").value;
                      p_price=document.getElementById("unit_price").value;
                      discount=document.getElementById("discount").value;
                         
                      sub_total=item_qty*(p_price-discount);
                 
                      array.push([(index+1),item_name, detail, item_qty, p_price,price,discount,sub_total,"|"]);
                      arr_product_id.push([product_id]);
                      arr_barcode.push([barcode]);
                      arr_product.push([item_name]);
                      arr_detail.push([detail]);
                      arr_qty.push([item_qty]);
                      arr_unit_price.push([p_price]);
                      arr_sale_price.push([price]);
                      arr_discount.push([discount]);
                      arr_sub_total.push([sub_total]);
                    document.getElementById("cart_product_id").value=arr_product_id;
                         document.getElementById("cart_barcode").value=arr_barcode;
                         document.getElementById("cart_product").value=arr_product;
                         document.getElementById("cart_detail").value=arr_detail;
                         document.getElementById("cart_qty").value=arr_qty;
                         document.getElementById("cart_unit_price").value=arr_unit_price;
                         document.getElementById("cart_sale_price").value=arr_sale_price;
                         document.getElementById("cart_discount").value=arr_discount;
                         document.getElementById("cart_sub_total").value=arr_sub_total;
                      
                         index=index+1;
                       
                       
                        document.getElementById("ItemName").value="";
                        document.getElementById("product").value="";
                        document.getElementById("barcode").value="";
                        document.getElementById("detail").value="";
                        document.getElementById("qty").value="";
                    
                        document.getElementById("sale_price").value="";
                        document.getElementById("unit_price").value="";
                        document.getElementById("discount").value=""; 
                      
                        
                    tableUpdate();
                     }
                     
                   
        function tableUpdate(){
             table = document.getElementById("table");
            for(var i = index-1; i < index; i++)
            {
               
                                  
               var newRow = table.insertRow(table.length);
               for(var j = 0; j < array[i].length-2; j++)
               {

                   // create a new cell
             
                   var cell = newRow.insertCell(j);
            
                   // add value to the cell
                  
                    if (j==0){
                        cell.innerHTML = array[i][j];
                   }
                    if (j==1){
                         cell.innerHTML = "<b>"+array[i][j]+"</b> ( "+array[i][j+1]+" )";
                   }
                    if (j==2){
                 cell.innerHTML = array[i][j+1];
                   }
                   if (j==3){
                 cell.innerHTML = array[i][j+1];
                   }
                   if (j==4){
                cell.innerHTML = array[i][j+2];
                   }
                   if (j==5){
                   
                   var mul=((parseInt(array[i][j-1])-parseInt(array[i][j+1]))*parseInt(array[i][j-2]));
                    total_discount+=parseInt(array[i][j+1])*parseInt(array[i][j-2]);
                       total_amount+=mul;
                        cell.innerHTML =mul;
                   }
               else if (j==6){
                  
                         cell.innerHTML ='<input type="button" class="btn btn-danger" onclick="removelist('+i+')" value="Remove">';
                   }
                  
                  
                  document.getElementById("net_amount").value=total_amount+total_discount;
                     document.getElementById("discount_amount").value=total_discount;
                     document.getElementById("total_amount").value=total_amount;
                   
                   
               }
           }
            }
    
       
        
        function removelist(val){
   document.getElementById('sound2').play();
              var table = document.getElementById("table");
            for(var k = table.rows.length - 1; k > 0; k--)
            {
                table.deleteRow(k);
            }
            
            array.splice(val, 1);
            arr_product_id.splice(val, 1);
            arr_barcode.splice(val, 1);
            arr_product.splice(val, 1);
            arr_detail.splice(val, 1);
            arr_qty.splice(val, 1);
            arr_unit_price.splice(val, 1);
            arr_sale_price.splice(val, 1);
            arr_discount.splice(val, 1);
            arr_sub_total.splice(val, 1);
         document.getElementById("cart_product_id").value=arr_product_id;
         document.getElementById("cart_barcode").value=arr_barcode;
         document.getElementById("cart_product").value=arr_product;
         document.getElementById("cart_detail").value=arr_detail;
         document.getElementById("cart_qty").value=arr_qty;
         document.getElementById("cart_unit_price").value=arr_unit_price;
         document.getElementById("cart_sale_price").value=arr_sale_price;
         document.getElementById("cart_discount").value=arr_discount;
         document.getElementById("cart_sub_total").value=arr_sub_total;
            index=index-1;
            total_amount=0;
            total_discount=0;
           
           table = document.getElementById("table");
            
            for(var i = 0; i < index; i++)
            {
               
                               
                var newRow = table.insertRow(table.length);
               for(var j = 0; j < array[i].length-2 ; j++)
                  {

                   // create a new cell
             
                   var cell = newRow.insertCell(j);
            
                   // add value to the cell
                  
                    if (j==0){
                        cell.innerHTML = array[i][j];
                   }
                    if (j==1){
                         cell.innerHTML = "<b>"+array[i][j]+"</b> ( "+array[i][j+1]+" )";
                   }
                    if (j==2){
                 cell.innerHTML = array[i][j+1];
                   }
                   if (j==3){
                 cell.innerHTML = array[i][j+1];
                   }
                   if (j==4){
                cell.innerHTML = array[i][j+2];
                   }
                   if (j==5){
                   
                   var mul=((parseInt(array[i][j-1])-parseInt(array[i][j+1]))*parseInt(array[i][j-2]));
                    total_discount+=parseInt(array[i][j+1])*parseInt(array[i][j-2]);
                       total_amount+=mul;
                        cell.innerHTML =mul;
                   }
               else if (j==6){
                  
                         cell.innerHTML ='<input type="button" class="btn btn-danger" onclick="removelist('+i+')" value="Remove">';
                   }
                  
                  
                  document.getElementById("net_amount").value=total_amount+total_discount;
                     document.getElementById("discount_amount").value=total_discount;
                     document.getElementById("total_amount").value=total_amount;
                   
                   
               }
              
           }
        } 
       
     function updatePrice(val){
         var amount=document.getElementById("paid_amount").value;
         if (amount<=total_amount){
         paid_amount=total_amount-val;
           document.getElementById("Remain_Amount").value=paid_amount;
             }
         else{
             document.getElementById("paid_amount").value=total_amount;
              document.getElementById("Remain_Amount").value="0";
         }
     }
        
                  
                     
                      </script>