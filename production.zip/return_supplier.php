
<?php 
 
if(isset($_GET['id'])) {
 
    $invoice_id=$_GET['id'];	
} else {
   $invoice_id=$_POST["InNo"];	
    
}

$item="";
$qty="";
$detail="";
$price="";
$U_price="";
$dc="";
$sub="";
$IN="";
$date="";
$T_DC="";
$total="";
$paid="";
$name="";
$contact="";
$email="";
$address="";
$due="";
 

include_once 'con_file.php';
			  $conn;

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
		?>

<!DOCTYPE html>

<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Return | C-POS </title>

    <!-- Bootstrap -->
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    
    <!-- Custom styling plus plugins -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
         <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
          <?php include_once 'menu.php';?>  
            <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
            <div class="sidebar-footer hidden-small">
              <a data-toggle="tooltip" data-placement="top" title="Settings">
                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="FullScreen">
                <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Lock">
                <span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Logout" href="login.php">
                <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
              </a>
            </div>
            <!-- /menu footer buttons -->
          </div>
        </div>

        <!-- top navigation -->
        <div class="top_nav">
          <div class="nav_menu">
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>
              <nav class="nav navbar-nav">
              <ul class=" navbar-right">
                <li class="nav-item dropdown open" style="padding-left: 15px;">
                  <a href="javascript:;" class="user-profile dropdown-toggle" aria-haspopup="true" id="navbarDropdown" data-toggle="dropdown" aria-expanded="false">
                    User
                  </a>
                  <div class="dropdown-menu dropdown-usermenu pull-right" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item"  href="setting.php"><i class="fa fa-gear pull-right"></i> Settings</a>  
                    <a class="dropdown-item"  href="login.php"><i class="fa fa-sign-out pull-right"></i> Log Out</a>
                  </div>
                </li>

              </ul>
            </nav>
          </div>
        </div>
     
        <!-- top navigation -->
    
        <!-- page content -->
        <div class="right_col" role="main">
          <div>
            <div  style="padding:10px;" class="page-title">
              <div>
               
              </div>

       
            </div>

     

            <div  style="padding:10px;" class="row">
              <div class="col-md-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Purchase Order: <?php echo $invoice_id;?>
							</h2>
           
							
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <section class="content invoice">
                     

                      <div class="row">
                        <div class="  table">
							
                          <table class="table table-striped">
                            <thead>
                              <tr>
                                <th>Quantity</th>
                                <th style="width: 29%">Item</th>
                                <th>Description</th>
								  <th>Purchased Price</th>
                          
								<th>Sub Total</th>
								<th><center>Action</center></th>
								  
                              </tr>
                            </thead>
							  
                            <tbody>
                     
								
								<?php
						
$sql = "SELECT * FROM tblpruchase pruchase INNER JOIN tblproduct products ON pruchase.product_id=products.product_id INNER JOIN tblpurchaseorder purchaseorder ON pruchase.purchase_order_id=purchaseorder.purchase_order_id where pruchase.purchase_order_id='".$invoice_id."'";
$sql;                            
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        

$product_id=$row["product_id"];	
$purchase_id=$row["purchase_id"];	
$date=$row["order_date"];
$item=$row["product_name"];
$qty=$row["quantity"];
$detail=$row["product_detail"];
$price=$row["sale_price"];
$U_price=$row["unit_price"];
$dc=$row["discount_percentage"];
$sub=$row["sub_total"];
$T_DC=$row["discount"];
$total=$row["total_amount"];
$paid=$row["paid_amount"];
$due=$row["due_amount"];
						?>  
             <tr>
                    
                 
				  <input type="hidden"  name="U_price" value="<?php echo $U_price; ?>">
				  <input type="hidden" name="due" value="<?php echo $due; ?>">
				  <input type="hidden" name="paid" value="<?php echo $paid; ?>">
                    <input type="hidden" name="invoice" value="<?php echo $invoice_id; ?>">
					<input type="hidden" name="status" value="<?php echo $_POST["IU"]; ?>">
                  <input type="hidden" name="discount" value="<?php echo $dc; ?>">
        <td><input type="hidden" name="qty" value="<?php echo $qty; ?>"><?php echo $qty; ?></td>
        <td><input type="hidden" name="item" value="<?php echo $item; ?>"><?php echo $item; ?></td>
        <td><input type="hidden" name="detail" value="<?php echo $detail; ?>"><?php echo $detail; ?></td>
        <td><input type="hidden" name="price" value="<?php echo $price; ?>"><?php echo $price; ?></td>
        <td><input type="hidden" name="sub" value="<?php echo $sub; ?>"><?php echo $sub; ?></td>
         <td> <a style="text-decoration:none;color:white" href="edit_sup_return.php?id=<?php echo $purchase_id.'-'.$invoice_id.'-'.$product_id; ?>"><button class='btn btn-success'>Edit</button></a> | <a style="text-decoration:none;color:white"  href='delete_returnsup.php?id=<?php echo $purchase_id.'-'.$invoice_id.'-'.$product_id; ?>'><button class='btn btn-danger'>Delete</button></a></td>      
                   
                   
                      
                   
             </tr>
                                    <?php
            
							 
                                   
								}
}
							
								
									
									?>
                                
							  </tbody>
                          </table>
						 

                        </div>
                        <!-- /.col -->
                      </div>
                      <!-- /.row -->
			 
                      <div class="row">
                        
                        
                       
                        <!-- /.col -->
                      </div>
                      <!-- /.row -->
					
                      <!-- this row will not appear when printing -->
                    </section>
					  
                  </div>
                </div>
				  <div style="float:right">
					  
              
		 
					  </div>
				</div>
            </div>
			 
          </div>
			
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
   <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>
  </body>
</html>