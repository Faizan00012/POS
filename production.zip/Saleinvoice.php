<?php
 session_start();
 
if(empty($_SESSION['username']) || $_SESSION['username'] == ''){
    header("Location: login.php");
    die();
}
?>
<!DOCTYPE html>

<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Sale Invoice | C-POS</title>

    <!-- Bootstrap -->
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    
    <!-- Custom styling plus plugins -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
  </head>

   <body class="nav-md">
    <div class="container body">
      <div class="main_container">
         <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
          <?php include_once 'menu.php';?>        <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
            <div class="sidebar-footer hidden-small">
              <a data-toggle="tooltip" data-placement="top" title="Settings">
                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="FullScreen">
                <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Lock">
                <span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Logout" href="login.php">
                <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
              </a>
            </div>
            <!-- /menu footer buttons -->
          </div>
        </div>

        <!-- top navigation -->
          <div class="top_nav">
          <div class="nav_menu">
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>
              <nav class="nav navbar-nav">
              <ul class=" navbar-right">
                <li class="nav-item dropdown open" style="padding-left: 15px;">
                  <a href="javascript:;" class="user-profile dropdown-toggle" aria-haspopup="true" id="navbarDropdown" data-toggle="dropdown" aria-expanded="false">
                    <?php echo $_SESSION["username"]; ?>
                  </a>
                  <div class="dropdown-menu dropdown-usermenu pull-right" aria-labelledby="navbarDropdown">
					  <?php
					  include_once 'con_file.php';
			  $conn;

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
					  $sql = "SELECT username, access FROM users";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		if ($_SESSION["username"]==$row["username"])
		{
			
			$access=$row["access"];
			if ($access=="admin"){
				echo "<a class='dropdown-item'  href='setting.php'><i class='fa fa-gear pull-right'></i> Settings</a>";
			}
			
			
					 
		}
       
    }
} else {
    
}
$conn->close();
?> 
					  
                    
                    <a class="dropdown-item"  href="login.php"><i class="fa fa-sign-out pull-right"></i> Log Out</a>
                  </div>
                </li>

              </ul>
            </nav>
          </div>
        </div>
        <!-- top navigation -->
    
        <!-- page content -->
        <div class="right_col" role="main">
          <div>
            <div  style="padding:10px;" class="page-title">
              <div>
                 
              </div>

       
            </div>

     

            <div  style="padding:10px;" class="row">
              <div class="col-md-12">
                <div class="x_panel">
                  <div class="x_title">
                      <img >
                    <h2>Invoice No.00
						<?php
                        $l_invoice=array();
                        $in_index=0;
						$last_id=1;
						$Item="";
						$I_qty="";
                        $I_mass="";
						$I_price="";
						$U_price="";
					 			$exp=0;
						$I_detail="";
						$I_discount="";
						$I_total="";
						$UN_Price=0;
						$Profit=0;
						 
					
						include_once 'con_file.php';
			  $conn;
                         
							$conn = new mysqli($servername, $username, $password, $dbname);

							if ($conn->connect_error) {
    						die("Connection failed: " . $conn->connect_error);
							} 
						 $sql = "SELECT invoiceNo  FROM sale_client;";
						
						
						$result = $conn->query($sql);
if ($result->num_rows > 0) {
	
    // output data of each row
    while($row = $result->fetch_assoc()) {
						
						   if ($row["invoiceNo"]!=""){
                             $l_invoice[$in_index]=number_format($row["invoiceNo"]);
                        $in_index=$in_index+1;
						  //  $last_id=$row["invoiceNo"];
							   }
		else{
			$last_id=1;
		}
	
		
	}
  $last_id = max($l_invoice);
	$last_id+=1;
						    echo($last_id);
}
							
							?>
							</h2>
           
							
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
<img  >
                    <section class="content invoice">
                      <!-- title row -->
                      <div class="row">
                        <div class="  invoice-header">
                          <h1>
                                           
                                      </h1>
                        </div>
                        <!-- /.col -->
                      </div>
                      <!-- info row -->
                      <div class="row invoice-info">
                          <div class="col-sm-4 invoice-col">
                              <address>
                                          <p><strong>Naseeb Shopping Mall</strong><br><br>
											  <strong>Address : </strong>G.T Road, Kamra Cantt.<br><br>
											  
											  <strong>Contact 1: </strong>0345-5807152<br>
                                              <strong>Contact 2: </strong>0313-1141555<br><br>
							  				  <strong> </strong><br></p>
							  
                                           
                                      </address>
                        </div>
                        
                        <!-- /.col -->
                        <div class="col-sm-4 invoice-col">
                          To
                          <address>
                                          
							  <?php
							  $trig=true;
							include_once 'con_file.php';
			  $conn;
							  	$name="";
								$contact="";
								$address="";
								$email="";
								$dup=0;
								 $name_check=false;
							  
                         
							$conn = new mysqli($servername, $username, $password, $dbname);

							
						
						   $sql = "SELECT Sale_id, Item_Name, Price,U_Price, detail, Discount, exp, Qty, C_Name,C_Contact,C_Email, C_Address, Sub_Total FROM Sale";
$result = $conn->query($sql);
$total=0;
							  $qty=0;
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		
		
		$qty=$qty+$row["Qty"];
								   
                                     $name=$name.$row["C_Name"];
								$contact=$contact.$row["C_Contact"];
								$address=$address.$row["C_Address"];
								$email=$email.$row["C_Email"];
                             
                                    
						 
							 	 
							
				}
								
					
					}
							 if ($name==""){
										echo "<stro ng>Walkin Customer</strong><br><br><strong>Address:</strong>
										Lane XXX, City XXX.<br><br>
                                        <strong>Contact:</strong>
										03XX-XXXXXXX<br>
                                        <strong>Email:</strong>
										abc123@gmail.com";
									}
									else{ 
										echo "<strong>".$name."
                                        </strong><br><br><strong>Address:</strong>".$address."<br>
                                        <br><strong>Contact:</strong>".$contact."
                                        <br><strong>Email ID:</strong>".$email;
							 	} 
							 
							 
							 $conn->close();
							?>
                                          
                                      </address>
                        </div>
                        <!-- /.col -->
                     
                        <!-- /.col -->
                      </div>
                      <!-- /.row -->

                      <!-- Table row -->
                      <div class="row">
                        <div class="  table">
                          <table class="table table-striped">
                            <thead>
                              <tr>
                                <th>Quantity</th>
                                   <th>Mass</th>
                                <th>Item</th>
                                <th>Price</th>
                                <th style="width: 49%">Description</th>
                               
								<th>Subtotal</th>
                              </tr>
                            </thead>
                            <tbody>
								
								 <?php
				
	include_once 'con_file.php';
			  $conn;
                         $Total_P="";
							$conn = new mysqli($servername, $username, $password, $dbname);

							if ($conn->connect_error) {
    						die("Connection failed: " . $conn->connect_error);
							} 
			
 
 
$sql = "SELECT Sale_id, Price,mass, U_Price, Item_Name, detail,Discount,Qty,Sub_Total,C_Name,C_Address,C_Contact,C_Email FROM sale";
$result = $conn->query($sql);
$total=0;
								
							
if ($result->num_rows > 0) {
	
    // output data of each row
    while($row = $result->fetch_assoc()) {
		
	                 
			
		$UN_Price=$UN_Price+($row["U_Price"]*$row["Qty"]);
		 
		 
        echo "<tr><td>" . $row["Qty"]. "</td>";
           echo "<td>" . $row["mass"]. "</td>";
		echo "<td>" . $row["Item_Name"]. "</td>";
		//$Total_P =$Total_P.", ".$row["Item_Name"];
		echo "<td>Rs. " . $row["Price"]. "</td>";
		echo "<td>" . $row["detail"]. "</td>";
		
		$total=$total+$row["Sub_Total"];
		echo "<td>Rs. " . $row["Sub_Total"]. "</td></tr>";
			$Item=$Item.$row["Item_Name"]." |";
						$I_qty=$I_qty.$row["Qty"]." |";
                        $I_mass=$I_mass.$row["mass"]." |";
		                $U_price=$U_price.$row["U_Price"]." |";
						$I_price=$I_price.$row["Price"]." |";
						$I_detail=$I_detail.$row["detail"]." |";
						$I_discount=$I_discount.$row["Discount"]." |";
						$I_total=$I_total.$row["Sub_Total"]." |";
						
		 }
	 
 
	$profit=$total-$UN_Price;
 	 
} else {
    
}
$conn->close();
								?>
		
                             
                            </tbody>
                          </table>
                        </div>
                        <!-- /.col -->
                      </div>
                      <!-- /.row -->

                      <div class="row">
                        <!-- accepted payments column -->
                          <?php
						  $n=1;
							
	include_once 'con_file.php';
			  $conn;
                         
							$conn = new mysqli($servername, $username, $password, $dbname);

							if ($conn->connect_error) {
    						die("Connection failed: " . $conn->connect_error);
							} 
						
 
 			
						  	$sql = "SELECT Sale_id, Price, Item_Name, detail,Discount, exp, DC_Mode,Qty,Sub_Total FROM sale";	
						    $result = $conn->query($sql);
						    $total=0;
						  $Net_A=0;
						  $Net_D=0;
						  $Net_T=0;
						  	if ($result->num_rows > 0) {
    // output data of each row
								while($row = $result->fetch_assoc()) {
									if ($row["exp"]>0){
										$exp=$row["exp"];
									}
									 
									
									$sql = "UPDATE items SET Remain_Qty=Remain_Qty-'".$row["Qty"]."', Sale_Qty=Sale_Qty+'".$row["Qty"]."', Sale_Product=Sale_Product+'".$row["Qty"]."'  WHERE Name='".$row["Item_Name"]."' AND detail='".$row["detail"]."' ";

									if ($conn->query($sql) === TRUE) {
  
									} else {

									}	 

									 
										$sql = "INSERT INTO sale_item (invoiceNo, Name, detail, Price,	P_Qty,P_Date, customer, seller)
VALUES ('".$last_id."','".$row["Item_Name"]."','".$row["detail"]."','".$row["Price"]."','".$row["Qty"]."','".date("Y-m-d")."','".$name."','".$_SESSION['username']."')";
if ($conn->query($sql) === TRUE) {
  
} else {

} 
							
										
									
		
				
									
									
									if ($row["DC_Mode"]=="net"){
										$Net_D+=$row["Discount"]*$row["Qty"];
									}
									else{
										$Net_D+=($row["Qty"]*$row["Price"])*$row["Discount"]/100;
									}
							    $Net_A+=$row["Qty"]*$row["Price"];
							 
									$Net_T+=$row["Sub_Total"];
									
									
									
									
								}
								
								$sql = "INSERT INTO customer (name, address, email, contact, inoviceNo, Date, Net , Amount,Paid, Due, exp, seller)
VALUES ('".$name."','".$contact."','".$email."','".$address."','".$last_id."','".date("Y-m-d")."','".$Net_A."','".$Net_T."','".$_POST["paid"]."','".$_POST["remain"]."','".$exp."','".$_SESSION['username']."')";
if ($conn->query($sql) === TRUE) {
    
} else {

}		
							}
?>
                       
                        <div class="col-md-6">
                          <p class="lead">Date <?php echo date("Y-m-d"); ?></p>
                          <div class="table-responsive">
                            <table class="table">
                              <tbody>
                               
								  <tr>
                                  <th style="width:50%">Net Amount:</th>
                                  <td><?php echo "Rs. ".$Net_A;?></td>
                                </tr>
                                  <tr>
                                  <th>Paid Amount: </th>
                                  <td><?php echo "Rs. ".$_POST["paid"];?></td>
                                </tr>
                                <tr>
                                  <th>Due: </th>
                                  <td><?php echo "Rs. ".$_POST["remain"];?></td>
                                </tr>
                              </tbody>
                            </table>
                          </div>
                        </div>
                        <!-- /.col -->
                      </div>
                      <!-- /.row -->
						<?php
						include_once 'con_file.php';
			  $conn;
                         
							$conn = new mysqli($servername, $username, $password, $dbname);

							if ($conn->connect_error) {
    						die("Connection failed: " . $conn->connect_error);
							} 
						
						$Netdiscount=0;
						$Nettotal=0;
						if(isset($_POST['submit'])){
						
						if ($name==""){
							$name="Walkin";
							$contact="03XXXX";
							$email="XXXX";
								$address="XXXX";
						}

							$sql = "INSERT INTO sale_client (invoiceNo, date, items,I_Qty, I_mass, I_Price, I_UPrice, I_Detail, I_Discount, I_Stotal, Discount, total, profit,Unit_Price, Qty,Paid, C_Name, C_Contact, C_Email, C_Address, C_Due, exp, seller)
							VALUES ('".$last_id."','".date("Y-m-d") ."','".$Item."','".$I_qty."','".$I_mass."','".$I_price."','".$U_price."','".$I_detail."','".$I_discount."','".$I_total."','".$Net_D."','".$Net_T."','".$profit."','".$UN_Price."','".$row["Qty"]."','".$_POST["paid"]."','".$name."','".$contact."','".$email."','".$address."','".$_POST["remain"]."','".$exp."','".$_SESSION['username']."')";
						
							 

							if ($conn->query($sql) === TRUE) {
							} else {
    						echo "Error: " . $sql . "<br>" . $conn->error;
							}
								if ($exp!="0"){
										  $sql = "INSERT INTO expense (Date, detail, Cost,behaviour, seller)
VALUES ('".date("Y-m-d")."', 'Sale Item invoice: ".$last_id."', '".$exp."', 'Sale','".$_SESSION['username']."')";

if ($conn->query($sql) === TRUE) {
     
} else {
    
}
							}
							
							$sql = "delete from sale";
							 

							if ($conn->query($sql) === TRUE) {
							} else {
    						echo "Error: " . $sql . "<br>" . $conn->error;
							}

						
							
			  				  
						 }
						
						
$conn->close();
						
						
								
?>
                        <img src="images/temp.jpg" width="20%" height="48px" style="float:right;margin-right:20px;margin-bottom:5px;">
                      <!-- this row will not appear when printing -->
                      <div class="row no-print">
                      </div>
                    </section>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
		   <footer>
          <div class="pull-right">
             <a href="https://centromonics.com">Centromonics - Point of Sale</a>
          </div>
          <div class="clearfix"></div>
        </footer> 
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
   <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>
  </body>
</html>