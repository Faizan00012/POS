<?php
$conn = mysqli_connect("147.135.49.177","wwwcentromonics_root","pakistan0012","wwwcentromonics_pos") or   die("Connection failed: " . mysqli_connect_error());
$conn = new mysqli($servername, $username, $password, $dbname);
?>