<?php

$ps_id = $_GET['id'];

include_once 'con_file.php';
			  $conn;


$sql = "DELETE FROM tblcustomer WHERE customer_id = {$ps_id}";
$result = mysqli_query($conn, $sql) or die("Query Unsuccessful.");

header("Location: CustomerView.php");

mysqli_close($conn);

?>
