<?php
						
	include_once 'con_file.php';
			  $conn;
                         
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection

 
// sql to delete a record
$sql = "DELETE FROM sale";

if ($conn->query($sql) === TRUE) {
	 header("location: Sale.php");
} else {
   header("location: Sale.php");
}

$conn->close();
?> 