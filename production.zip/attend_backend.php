<?php
session_start();
?>
<?php
  include_once 'con_file.php';
			  $conn;

$var_index=0;

$sql="";
$insertTrig=true;
$Dupl=false;
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

  				
						
if(isset($_POST["submit"])) {
     $var_Date= $_POST["Dateinput"];
 
    $sql_Date="SELECT * FROM `staff_attend` WHERE Date='".$var_Date."';";
    $result = $conn->query($sql_Date);

if ($result->num_rows > 0) {
    $Dupl=true;
    
}
    


    $var_index= $_SESSION["index"];
    
		/*
                    <td><input type="hidden" name="Reg'.$reg.'"value="'.$reg.'">'.$reg.'</td>
                    
                    <td><input type="hidden" name="Name'.$reg.'" value="'.$row["name"].'">'.$field1name.'</td>
					<td><input type="hidden" name="Address'.$reg.'" value="'.$row["name"].'">'.$field2name.'</td>
					<td><input type="hidden" name="Contact'.$reg.'" value="'.$row["name"].'">'.$field3name.'</td>
           
                    <td><input type="hidden" name="Date'.$reg.'" value="'. date("Y-m-d").'">'. date("Y-m-d").'</td>
                    <td><input name="a'.$reg.'" type="checkbox" checked/> Present</td>
                    <td><input name="R'.$reg.'" type="text" /></td>
					*/
 
    for ($i = 1; $i <= $var_index-1; $i++) {
        $x1= $_POST["Name".$i];
         $x2= $_POST["Reg".$i];
         $x3= $_POST["Dateinput"];
        
          $x5= $_POST["R".$i];
        
        if ($Dupl==true){
            
         $sql = "DELETE FROM `staff_attend` WHERE   name='".$x1."' And date='".$x3."'"; //Delete Duplicate Values
         if ($conn->query($sql) === TRUE) {
           
         }
        }
    
        
     if (isset($_POST["a".$i])) {
        $sql = "INSERT INTO staff_attend (name, date, attend,status)
VALUES ('".$x1."', '".$x3."','Present','".$x5."')";
         
         if ($conn->query($sql) === TRUE) {
     
} else {
   echo "Error: " . $sql . "<br>" . $conn->error;
}
        }
        else
        {
                     $sql = "INSERT INTO staff_attend (name, date, attend,status)
VALUES ('".$x1."', '".$x3."','Absent','".$x5."')";
         
         if ($conn->query($sql) === TRUE) {
     
} else {
   echo "Error: " . $sql . "<br>" . $conn->error;
}

        }
        
       
    }
    
      header("location: attendance.php");



//$conn->close();
    
}
   
    
   
 
    
    

 

        
        






?> 