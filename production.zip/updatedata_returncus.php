<?php
$product_id=$_POST["product_id"];
$sale_id=$_POST["sale_id"];
$invoice_id=$_POST["invoice_id"];
$old_quantity=$_POST["old_quantity"];
$quantity=$_POST["quantity"];
$sale_price=$_POST["sale_price"];
$invoice_date="";
$sub=$quantity*$sale_price;
$total_amount=0;
$paid_amount=0;
$sub_old=$_POST["sub_total"];
include_once 'con_file.php';
$conn;
$sql = "SELECT invoice_date,total_amount, paid_amount FROM tblinvoice WHERE invoice_id = {$invoice_id}";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
       $invoice_date=$row["invoice_date"];
    }
} 

 $sql = "UPDATE tblsale SET quantity = '{$quantity}', sub_total='{$sub}' WHERE sale_id = {$sale_id}";
 
  $result = mysqli_query($conn, $sql) or die("Query Unsuccessful.");

$sql = "UPDATE tblproduct SET unit_in_stock = (unit_in_stock-{$old_quantity})+{$quantity}  WHERE product_id = {$product_id}";
 
$result = mysqli_query($conn, $sql) or die("Query Unsuccessful.");
 
$sql = "UPDATE tblinvoice SET invoice_date = '".date("Y-m-d") ."', revise='".$invoice_date."', total_amount = (total_amount-{$sub_old})+{$sub} , paid_amount = (paid_amount-{$sub_old})+{$sub}  WHERE invoice_id = {$invoice_id}";

$result = mysqli_query($conn, $sql) or die("Query Unsuccessful.");
 

header("Location: return.php?id=".$invoice_id);

mysqli_close($conn);

?>
