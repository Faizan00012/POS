  <?php
				
include_once 'con_file.php';
if(isset($_POST['submit'])){
    $pro_arr=array();
    $index=0;
    $table_array=$_POST['table_array'];
    $customer_id = $_POST['customer_id'];
    $total_amount = $_POST['Total_Amount'];
    $paid_amount = $_POST['amount_paid'];
    $remain_amount = $_POST['Remain_Amount'];
    $discount_per = $_POST['dis_per'];
    $discount_rs = $_POST['dis_rs'];
    $username = $_POST['username'];
    $data=explode("|",$_POST["table_array"]);
    $invoice_id=0;
    $pay_amount=0;
    $sql = "SELECT amount FROM payments where customer_id='".$customer_id."'";
        
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {
                $pay_amount=$pay_amount+(int)$row["amount"];
              }
        } else {
                
        }
    
  /*  $sql = "UPDATE payments SET amount='amount-".$paid_amount."'  where customer_id='".$customer_id."'";
 
    if ($conn->query($sql) === TRUE) {
        
    } else {
        
    }
    */
     $sql = "INSERT INTO tblinvoice (customer_id, total_amount, paid_amount, discount_cash, discount_per, due_amount, invoice_date, user_id)
        VALUES ('".$customer_id."','".$total_amount."','".$paid_amount."','".$discount_rs."','".$discount_per."','".$remain_amount."','".date("Y-m-d")."', '".$username."' )";
   
 
        if ($conn->query($sql) === TRUE) {
        } 
        else {
          
        }
    
 
    
     $sql = "SELECT invoice_id FROM tblinvoice ORDER BY invoice_id";
        
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {
                $invoice_id=(int)$row["invoice_id"];
              }
        } else {
                
        }
    
 
     $sql = "INSERT INTO customer_accounts (customer_id, invoice_id,title, amount, paid, due, acc_date)
        VALUES ('".$customer_id."', '".$invoice_id."','Sale on invoice: ".$invoice_id."','".$total_amount."', '".$paid_amount."', '".$remain_amount."', '".date("Y-m-d")."' )";
   
 
        if ($conn->query($sql) === TRUE) {
        } 
        else {
          
        }
    
     $sql = "INSERT INTO payments (amount , Type, customer_id, supplier_id, party)
        VALUES ('".$paid_amount."','Sale','".$customer_id."','0','Customer' )";
   
 
        if ($conn->query($sql) === TRUE) {
        } 
        else {
          
        }
    
    
    
    for ($i=0;$i<count($data)-1;$i++){
        if ($i!=0){
            $data[$i] = substr($data[$i], 1);
        }
    $field=explode(",",$data[$i]);
    $pro=explode("-",$field[0]);
 
            $pro_arr[$index]=$pro[0];
        $index=$index+1;
           $sql = "INSERT INTO tblsale (product_id, quantity, unit_price, sale_price , discount, sub_total, invoice_id)
     VALUES ('".$pro[0]."','".$field[2]."','".$field[4]."','".$field[3]."','0','".$field[5]."','".$invoice_id."')";
 
      if ($conn->query($sql) === TRUE) {
        } 
        else {
       
        }
  
        $sql = "UPDATE tblproduct SET unit_in_stock= unit_in_stock-'".$field[2]."' WHERE product_id='".$pro[0]."'";
 
       if ($conn->query($sql) === TRUE) {
        
        } else {
    
        }      
       
 
  }
    }
			  				  
					
 
    	?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="style.css">
        <title>Receipt example</title>
        <style>
        @media print
        { .button { display: none; }
            }
        </style>
    </head>
    <body>
        <div class="ticket">
           
            <p class="centered">Business Name<br>
            <b>Invoice#: <?php echo $invoice_id; ?></b><br>
            Date: <?php echo date("Y-m-d"); ?><br>
            </p>
            <table>
                <thead>
                    <tr>
                        <td class="quantity"><b>Qty</b></td>
                        <td class="description"><b>Item</b></td>
                        <td class="price"><b>PKR</b></td>
                         <td class="price"><b>SUB</b></td>
                    </tr>
                </thead>
                <tbody>
                    
                        <?php
                       $product_name="";
                                   $product_qty="";
                               for ($i=0;$i<count($data)-1;$i++){
                                 if ($i!=0){
                                 $data[$i] = substr($data[$i], 1);
                               }
                                $field=explode(",",$data[$i]);
                       
                                $sql = "SELECT product_name, product_detail FROM tblproduct where product_id='".$pro_arr[$i]."'";
                                  
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) {
                                while($row = $result->fetch_assoc()) {
                                    $product_name=$row["product_name"];
                                   $product_detail=$row["product_detail"];
                                    }
                                } 
                                echo "<tr>";
                                    echo '<td class="quantity">'.$field[2].'</td>';
                                    echo '<td class="description">'.$product_name.'-'.$product_detail.'</td>';
                                    echo '<td class="price">'.$field[3].'</td>';
                                    echo '<td class="price">'.$field[5].'</td>';
                                echo "</tr>";
                         }   
                      
                            ?>
                   
                    <tr>
                         
                        <td colspan="2" class="description">TOTAL</td>
                        <td colspan="2" class="price"><?php echo "Rs. ".$total_amount; ?></td>
                    </tr>
                      <tr>
                         
                        <td colspan="2" class="description">Paid</td>
                        <td colspan="2" class="price"><?php echo "Rs. ".$paid_amount; ?></td>
                    </tr>
                      <tr>
                         
                        <td colspan="2" class="description">Due</td>
                        <td colspan="2" class="price"><?php echo "Rs. ".$remain_amount; ?></td>
                    </tr>
                </tbody>
            </table>
            <p class="centered">Thanks for your purchase!
                <br><small style="font-size:8px">System Developed By Centromonics IT Solutions</small></p>
        </div>
        <button><a style="text-decoration:none;" href="Sale.php">C POS</a> </button>
        <script>
        
    window.print();
 
        </script>
        <script src="script.js"></script>
        
    </body>
</html>
                   
