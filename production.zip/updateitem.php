
			<?php
			include_once 'con_file.php';
			  $conn;

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

if(isset($_POST['submit'])){
	$str = $_POST['ItemName'];
$arr = array();
$arr=explode("(",$str);
     $arr[0]= substr($arr[0], 0, -1) ;
  $arr[1]= substr($arr[1], 0, -1) ;	
	
	
	
$sql = "UPDATE tblproduct SET product_detail='".$_POST["n_detail"]."', unit_price='".$_POST["n_price"]."', sale_price='".$_POST["n_sale_price"]."', unit_in_stock='".$_POST["n_stock"]."' WHERE product_id='".$_POST["product_id"]."' ";

if ($conn->query($sql) === TRUE) {
      header('location: changeItem.php');
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
	}
	 
			  
