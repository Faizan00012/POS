<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>CRUD</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div id="wrapper">
        <div id="header">
            <h1>Update Customer</h1>
        </div>
        <div id="menu">
            <ul>
                <li>
                    <a href="CustomerView.php">Back</a>
                </li>
                
            </ul>
        </div>


<div id="main-content">
    <h2>Update Record</h2>
    <?php
    include_once 'con_file.php';
			  $conn;

    $sc_id = $_GET['id'];

    $sql = "SELECT * FROM tblcustomer WHERE customer_id = {$sc_id}";
    $result = mysqli_query($conn, $sql) or die("Query Unsuccessful.");

    if(mysqli_num_rows($result) > 0)  {
      while($row = mysqli_fetch_assoc($result)){
    ?>
    <form class="post-form" action="updatedata_cus.php" method="post">
      <div class="form-group">
          <label>Name</label>
          <input type="hidden" name="c_id" value="<?php echo $row['customer_id']; ?>"/>
          <input type="text" name="c_name" value="<?php echo $row['customer_name']; ?>"/>
      </div>
      <div class="form-group">
          <label>Address</label>
          <input type="text" name="c_address" value="<?php echo $row['customer_address']; ?>"/>
      </div>
      
      <div class="form-group">
          <label>Phone</label>
          <input type="text" name="c_phone" value="<?php echo $row['customer_contact']; ?>"/>
      </div>
        <div class="form-group">
          <label>Email</label>
          <input type="text" name="c_email" value="<?php echo $row['customer_email']; ?>"/>
      </div>
      <input class="submit" type="submit" value="Update"/>
    </form>
    <?php
      }
    }
    ?>
</div>
</div>
</body>
</html>
