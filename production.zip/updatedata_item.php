<?php
   include_once 'con_file.php';
			  $conn;

$sql = "UPDATE tblproduct SET product_name = '{$_POST['product_name']}', produce_code = '{$_POST['produce_code']}', product_detail = '{$_POST['product_detail']}', sale_price = '{$_POST['sale_price']}' , unit_price = '{$_POST['unit_price']}' , unit_in_stock = '{$_POST['unit_in_stock']}' WHERE product_id = {$_POST['product_id']}";
 
$result = mysqli_query($conn, $sql) or die("Query Unsuccessful.");
 

header("Location: items.php");

mysqli_close($conn);

?>
