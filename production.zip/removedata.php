<?php
$conn = mysqli_connect("localhost","root","","faizan_db") or   die("Connection failed: " . mysqli_connect_error()); 
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

// sql to delete a record
$sql = "DELETE FROM tblsale";

if ($conn->query($sql) === TRUE) {
    
} else {
    
}

$sql = "DELETE FROM payments";

if ($conn->query($sql) === TRUE) {
    
} else {
    
}

$sql = "DELETE FROM customer_accounts";

if ($conn->query($sql) === TRUE) {
    
} else {
    
}


$sql = "DELETE FROM tblcustomer";

if ($conn->query($sql) === TRUE) {
   
} else {
    
}

 $sql = "DELETE FROM tblpruchase";

if ($conn->query($sql) === TRUE) {
     
} else {
    
}



$sql = "DELETE FROM supplier_accounts";

if ($conn->query($sql) === TRUE) {
    
} else {
    
}
$sql = "DELETE FROM tblpurchaseorder";

if ($conn->query($sql) === TRUE) {
    
} else {
     
}
$sql = "DELETE FROM tblproduct";

if ($conn->query($sql) === TRUE) {
     
} else {
    
}

$sql = "DELETE FROM tblsupplier";

if ($conn->query($sql) === TRUE) {
   
} else {
     
}
$sql = "DELETE FROM tblcustomer";

if ($conn->query($sql) === TRUE) {
   
} else {
     
}
$sql = "DELETE FROM tblinvoice";

if ($conn->query($sql) === TRUE) {
   
} else {
     
}
$sql = "DELETE FROM tblexpense";

if ($conn->query($sql) === TRUE) {
   
} else {
     
}
$sql = "DELETE FROM staff";

if ($conn->query($sql) === TRUE) {
   
} else {
     
}

$sql = "DELETE FROM staff_exp";

if ($conn->query($sql) === TRUE) {
   
} else {
     
}
	$sql = "DELETE FROM staff_attend";

if ($conn->query($sql) === TRUE) {
   
} else {
     
}
$sql = "DELETE FROM dashboard";

if ($conn->query($sql) === TRUE) {
   
} else {
     
}

 header("location: dashboard.php");

$conn->close();
?> 