<?php
 session_start();
 
if(empty($_SESSION['username']) || $_SESSION['username'] == ''){
    header("Location: login.php");
    die();
}

include_once 'con_file.php';
$conn;

$conn = new mysqli($servername, $username, $password, $dbname);
$I_Item="";
$I_qty=0;
$I_price=0;
$I_detail="";
$I_total=0;
$total=0;
$bill_no=0;
$name="";
$sql = "SELECT * FROM client_sale where sale_id='".$_POST["user_id"]."'";
$result = $conn->query($sql);
								
							
if ($result->num_rows > 0) {
	
    // output data of each row
    while($row = $result->fetch_assoc()) {
	$name=$row["c_name"];
    $I_Item=$I_Item.$row["item_name"]." |";
    $I_qty=$I_qty.$row["item_qty"]." |";
	$I_price=$I_price.$row["item_price"]." |";
    $I_detail=$I_detail.$row["item_detail"]." |";
    $I_total=$I_total.$row["sub_total"]." |";
	$total=$total+$row["sub_total"];
			
		 }
	 
  	 
} else {
    
}
$sql = "INSERT INTO client_bill (user_id, I_item,I_detail,I_price,I_qty,I_subtotal,total,date) VALUES ('".$_POST["user_id"]."','".$I_Item."','".$I_detail."','".$I_price."','".$I_qty."','".$I_total."','".$total."','".$name."')";
						
							 

							if ($conn->query($sql) === TRUE) {
							} else {
    						echo "Error: " . $sql . "<br>" . $conn->error;
							}

?>
<!DOCTYPE html>

<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Sale Invoice | C-POS</title>

    <!-- Bootstrap -->
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    
    <!-- Custom styling plus plugins -->
    <link href="../build/css/custom.min.css" rel="stylesheet">
  </head>

   <body class="nav-md">
    <div class="container body">
      <div class="main_container">
         <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
          <?php include_once 'menu.php';?>        <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
            <div class="sidebar-footer hidden-small">
              <a data-toggle="tooltip" data-placement="top" title="Settings">
                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="FullScreen">
                <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Lock">
                <span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Logout" href="login.php">
                <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
              </a>
            </div>
            <!-- /menu footer buttons -->
          </div>
        </div>

        <!-- top navigation -->
          <div class="top_nav">
          <div class="nav_menu">
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>
              <nav class="nav navbar-nav">
              <ul class=" navbar-right">
                <li class="nav-item dropdown open" style="padding-left: 15px;">
                  <a href="javascript:;" class="user-profile dropdown-toggle" aria-haspopup="true" id="navbarDropdown" data-toggle="dropdown" aria-expanded="false">
                    <?php echo $_SESSION["username"]; ?>
                  </a>
                  <div class="dropdown-menu dropdown-usermenu pull-right" aria-labelledby="navbarDropdown">
					  <?php
					  include_once 'con_file.php';
			  $conn;

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
					  $sql = "SELECT username, access FROM users";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		if ($_SESSION["username"]==$row["username"])
		{
			
			$access=$row["access"];
			if ($access=="admin"){
				echo "<a class='dropdown-item'  href='setting.php'><i class='fa fa-gear pull-right'></i> Settings</a>";
			}
			
			
					 
		}
       
    }
} else {
    
}
$conn->close();
?> 
					  
                    
                    <a class="dropdown-item"  href="login.php"><i class="fa fa-sign-out pull-right"></i> Log Out</a>
                  </div>
                </li>

              </ul>
            </nav>
          </div>
        </div>
        <!-- top navigation -->
    
        <!-- page content -->
        <div class="right_col" role="main">
          <div>
            <div  style="padding:10px;" class="page-title">
              <div>
                 
              </div>

       
            </div>

     

            <div  style="padding:10px;" class="row">
              <div class="col-md-12">
                <div class="x_panel">
                  <div class="x_title">
                      <img >
                    <h2>Bill No.
						<?php
                         
						 $sql = "SELECT B_id  FROM client_bill;";
						
						
						$result = $conn->query($sql);
if ($result->num_rows > 0) {
	
    // output data of each row
    while($row = $result->fetch_assoc()) {
						$bill_no=$row["B_id"];
      echo($bill_no);
						  }
						    
}
							
							?>
							</h2>
           
							
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
<img  >
                    <section class="content invoice">
                      <!-- title row -->
                      <div class="row">
                        <div class="  invoice-header">
                          <h1>
                                           
                                      </h1>
                        </div>
                        <!-- /.col -->
                      </div>
                      <!-- info row -->
                      <div class="row invoice-info">
                         
                        
                        <!-- /.col -->
                        <div class="col-sm-4 invoice-col">
                          To
                          <address> <?php echo "<strong>".$name."</strong><br><br>"; ?> </address>
                        </div>
                        <!-- /.col -->
                     
                        <!-- /.col -->
                      </div>
                      <!-- /.row -->

                      <!-- Table row -->
                      <div class="row">
                        <div class="  table">
                          <table class="table table-striped">
                            <thead>
                              <tr>
                                <th>Quantity</th>
                                <th>Item</th>
                                <th>Price</th>
                                <th style="width: 49%">Description</th>
                               
								<th>Subtotal</th>
                              </tr>
                            </thead>
                            <tbody>
								
								 <?php
				
	include_once 'con_file.php';
			  $conn;
                         $Total_P="";
							$conn = new mysqli($servername, $username, $password, $dbname);

							if ($conn->connect_error) {
    						die("Connection failed: " . $conn->connect_error);
							} 
 
 
$sql = "SELECT * FROM client_bill where B_id='".$bill_no."'";
$result = $conn->query($sql);
$total=0;
								
							
if ($result->num_rows > 0) {
	
    // output data of each row
    while($row = $result->fetch_assoc()) {
		 
        echo "<tr><td>" . $row["item_qty"]. "</td>";
		echo "<td>" . $row["item_name"]. "</td>";
		//$Total_P =$Total_P.", ".$row["Item_Name"];
		echo "<td>Rs. " . $row["item_price"]. "</td>";
		echo "<td>" . $row["item_detail"]. "</td>";
		
		$total=$total+$row["sub_total"];
		echo "<td>Rs. " . $row["sub_total"]. "</td></tr>";
			$I_Item=$I_Item.$row["Item_Name"]." |";
						$I_qty=$I_qty.$row["item_qty"]." |";
		                
						$I_price=$I_price.$row["item_price"]." |";
						$I_detail=$I_detail.$row["item_detail"]." |";
						 $I_total=$I_total.$row["sub_total"]." |";
						
		 }
	 
  	 
} else {
    
}
$conn->close();
								?>
		
                             
                            </tbody>
                          </table>
                        </div>
                        <!-- /.col -->
                      </div>
                      <!-- /.row -->

                      <div class="row">
                        <!-- accepted payments column -->
                  
                       
                        <div class="col-md-6">
                          <p class="lead">Date <?php echo date("Y-m-d"); ?></p>
                          <div class="table-responsive">
                            <table class="table">
                              <tbody>
                               
								  <tr>
                                  <th style="width:50%">Net Amount:</th>
                                  <td><?php echo "Rs. ".$total;?></td>
                                </tr>
                                   
                                 
                              </tbody>
                            </table>
                          </div>
                        </div>
                        <!-- /.col -->
                      </div>
                      <!-- /.row -->
						<?php
						include_once 'con_file.php';
			  $conn;
                         
							$conn = new mysqli($servername, $username, $password, $dbname);

							if ($conn->connect_error) {
    						die("Connection failed: " . $conn->connect_error);
							} 
						
						 
							$sql = "INSERT INTO sale_client (I_item,I_detail,I_price,I_qty,I_subtotal,total,date)
							VALUES ('".$I_Item."','".$I_qty."','".$I_price."','".$U_price."','".$I_detail."','".$I_discount."','".$I_total."','".$Net_D."','".$Net_T."','".$profit."','".$UN_Price."','".$row["Qty"]."','".$_POST["paid"]."','".$name."','".$contact."','".$email."','".$address."','".$_POST["remain"]."','".$exp."','".$_SESSION['username']."')";
						
							 

							if ($conn->query($sql) === TRUE) {
							} else {
    						echo "Error: " . $sql . "<br>" . $conn->error;
							}
								if ($exp!="0"){
										  $sql = "INSERT INTO expense (Date, detail, Cost,behaviour, seller)
VALUES ('".date("Y-m-d")."', 'Sale Item invoice: ".$last_id."', '".$exp."', 'Sale','".$_SESSION['username']."')";

if ($conn->query($sql) === TRUE) {
     
} else {
    
}
							}
							
							$sql = "delete from sale";
							 

							if ($conn->query($sql) === TRUE) {
							} else {
    						echo "Error: " . $sql . "<br>" . $conn->error;
							}

						
							
			  				  
						 }
						
						
$conn->close();
						
						
								
?>
                        <img src="images/temp.jpg" width="20%" height="48px" style="float:right;margin-right:20px;margin-bottom:5px;">
                      <!-- this row will not appear when printing -->
                      <div class="row no-print">
                      </div>
                    </section>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
		   <footer>
          <div class="pull-right">
             <a href="https://centromonics.com">Centromonics - Point of Sale</a>
          </div>
          <div class="clearfix"></div>
        </footer> 
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
   <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>
  </body>
</html>